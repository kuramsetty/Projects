"""CDK App for deploying resources to other accounts."""

import os

from aws_cdk import App

from data_lake.data_lake_stack import DataLakeStack

app = App()

environment = app.node.try_get_context("environment")
codebuild_initiator = os.environ.get("CODEBUILD_INITIATOR")
if codebuild_initiator:
    environment = codebuild_initiator.split("/")[1].split("-")[0]
else:
    environment = os.environ.get("ENVIRONMENT")

branch = "master" if environment == "prod" else "qa"

s3_source = f"s3://cap-infra-git2s3-sc/covestro-analytics-platform/platform/data-lake/{branch}/covestro-analytics-platform_platform_data-lake.zip"


DataLakeStack(
    scope=app,
    construct_id=f"{environment}-DataLake",
    env={
        "region": app.node.try_get_context("region"),
        "account": app.node.try_get_context("account"),
    },
    pipeline_name=f"{environment}-data-lake-pipeline",
    source_zip=s3_source,
    environment=environment,
    termination_protection=False,
    description="Provisions data lake related resources via CodePipeline and Git - CDK Pipeline",
)

app.synth()
