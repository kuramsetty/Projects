"""Pipeline stack skeleton."""

from parser import parse_jobs_filenames

from aws_cdk import Stack
from aws_cdk import Stage as Stage
from aws_cdk import aws_codepipeline_actions as codepipeline_actions
from aws_cdk import aws_events as events
from aws_cdk import aws_events_targets as targets
from aws_cdk import aws_s3 as s3
from aws_cdk import pipelines as pipelines
from aws_cdk.pipelines import CodePipeline, CodePipelineSource, ShellStep
from constructs import Construct

from data_lake.data_lake_bucket_stack import DataLakeBucketStack
from data_lake.data_lake_etl_stack import DataLakeETLStack
from data_lake.data_lake_monitoring_stack import DataLakeMonitoringStack
from data_lake.data_lake_utils_stack import DataLakeUtilsStack


class DataLakeStage(Stage):
    def __init__(self, scope: Construct, id: str, environment: str, **kwargs):
        super().__init__(scope, id, **kwargs)

        bucket_stack = DataLakeBucketStack(scope=self, id="Bucket", environment=environment)

        filenames = parse_jobs_filenames(
            dirname="jobs/"
        )  # self.node.try_get_context("part_numbers")

        # Adding index value to ETL Stacks due to resource limits
        # index_map = {
        #     "c4c-jobs": 3,
        #     "c4c-cdc-jobs": 2,
        #     "kapost-jobs": 5,
        #     "adobe-marketo-jobs": 1,
        #     "supply-chain-gsp-jobs": 9,
        #     "qualtrics-jobs": 7,
        #     "opportunity-jobs": 10,
        #     "c4c-jobs2": 4,
        #     "job-runs-jobs": 8,
        #     "khoros-jobs":6,
        # }

        for part_index, filename in enumerate(filenames):
            # filename = part_number
            jobname = filename.split("/")[-1].split(".")[0].replace("\\", "-")
            etl_stack = DataLakeETLStack(
                scope=self,
                id=f"ETL-{jobname.replace('_','-')}",
                filename=filename,
                environment=environment,
                bucket_stack=bucket_stack,
            )

            etl_stack.add_dependency(bucket_stack)

        monitoring_stack = DataLakeMonitoringStack(
            scope=self, id="Monitoring", environment=environment
        )


class DataLakeUtilsStage(Stage):
    def __init__(self, scope: Construct, id: str, environment: str, **kwargs):
        super().__init__(scope, id, **kwargs)
        DataLakeUtilsStack(scope=self, id="Utils", environment=environment)


class DataLakeStack(Stack):
    """CDK pipeline class capable of taking multiple stages based on input."""

    def __init__(  # noqa: PLR0913
        self,
        scope: Construct,
        construct_id: str,
        source_zip: str,
        pipeline_name: str,
        environment: str,
        **kwargs,
    ) -> None:
        """CDK pipeline constructor.

        Args:
            scope (Construct): Parent construct.
            construct_id (str): Construct ID.
            source_zip (str): S3 source zip file.
            pipeline_name (str): Name of the pipeline.
            environment (str): Environment qa/prod.
            **kwargs: Additional keyword arguments.
        """
        super().__init__(scope, construct_id, **kwargs)

        bucket_name = self.node.try_get_context(environment)["bucket"]
        deploy_account = self.node.try_get_context(environment)["deploy_account"]
        region = self.node.try_get_context("region")

        bucket_name = source_zip.split("/")[2]
        object_key = "/".join(source_zip.split("/")[3:])

        pipeline = CodePipeline(
            self,
            "Pipeline",
            pipeline_name=f"{environment}-data-lake-pipeline",
            cross_account_keys=True,
            synth=ShellStep(
                "Synth",
                input=CodePipelineSource.s3(
                    bucket=s3.Bucket.from_bucket_name(
                        self,
                        id=bucket_name,
                        bucket_name=bucket_name,
                    ),
                    object_key=object_key,
                    # Trigger deactivated and uses Event Bridge instead
                    trigger=codepipeline_actions.S3Trigger.NONE,
                ),
                commands=[
                    "npm install -g aws-cdk",
                    "curl -sSL https://install.python-poetry.org | python3 -",
                    "/root/.local/bin/poetry install",
                    'cdk synth --app "/root/.local/bin/poetry run python app.py"',
                ],
            ),
        )

        bucket_name = source_zip.split("/")[2]
        object_key = "/".join(source_zip.split("/")[3:])

        pipeline.add_stage(
            DataLakeUtilsStage(
                scope=self,
                id="DataLakeUtils",
                env={"region": region, "account": deploy_account},
                environment=environment,
            )
        )

        pipeline.add_stage(
            DataLakeStage(
                scope=self,
                id="DataLake",
                env={"region": region, "account": deploy_account},
                environment=environment,
            )
        )

        # # Iterate over all input stages and create a pipeline stage for each
        # for stage in stages:
        #     pipeline.add_stage(stage)

        # Build pipeline to get the pipeline ARN
        pipeline.build_pipeline()

        s3_event = events.Rule(
            self,
            "S3Event",
            event_pattern=events.EventPattern(
                source=["aws.s3"],
                detail_type=["Object Created"],
                detail={
                    "bucket": {
                        "name": [bucket_name],
                    },
                    "object": {"key": [object_key]},
                },
            ),
        )

        s3_event.add_target(targets.CodePipeline(pipeline.pipeline))
