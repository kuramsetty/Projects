"""Const."""

TAGS = {
    "cov:project": "cap"
}
