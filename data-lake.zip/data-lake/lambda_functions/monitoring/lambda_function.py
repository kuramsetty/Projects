"""Monitoring."""

import json
import os

import boto3

client = boto3.client("sts")
account = client.get_caller_identity()["Account"]
region = os.environ["AWS_REGION"]

sns = boto3.client("sns")
s3 = boto3.client("s3")
s3_resource = boto3.resource("s3")
topic_arn = f"arn:aws:sns:{region}:{account}:data-lake-etl"


def lambda_handler(event, context):
    """Main handler."""
    job_run_state = event["detail"]["state"]
    job_name = event["detail"]["jobName"]
    response = ""

    if job_name.startswith("data-lake"):
        if job_run_state in ["FAILED", "TIMEOUT"]:
            # SNS mail to "old" topic (humans)  
            topic_arn = f"arn:aws:sns:{region}:{account}:data-lake-etl"
            message = (
                f"\nYour job {job_name} is in state {job_run_state}.\n\n"
                f"Check the job details at https://eu-central-1.console.aws.amazon.com/glue/home\
                    ?region=eu-central-1#etl:tab=jobs \n\n"
                f'{event["detail"]["message"]}\n'
            )
            subject = f"Glue job {job_name} in state {job_run_state}"
            response = sns.publish(TargetArn=topic_arn, Message=message, Subject=subject)

            # send SNS mail to create ServiceNow Incident
            topic_arn = "arn:aws:sns:eu-central-1:011840291019:servicenow-sns-prod"
            client = boto3.client('sns', region_name="eu-central-1")
            incident_detail = f'''
Glue job {job_name} is in state {job_run_state}.
Check the job details at https://eu-central-1.console.aws.amazon.com/glue/home?region=eu-central-1#etl:tab=jobs\n
Error Message was: {event["detail"]["message"]}
            '''
            payload = { "AccountId": "824519788521",
                        "ShortDescription": f"Glue job {job_name} {job_run_state}",
                        "Description": incident_detail,
                        "Urgency": "Low",
                        "Impact": "Low",
                        "Category": "APPLICATION",
                        "Subcategory": "COVESTRO_APPLICATION",
                        "ConfigurationItem": "Tableau"
            }
            print("\n", payload)
            response = client.publish( TopicArn=topic_arn,
                                       Subject="CREATE INCIDENT",
                                       Message=str(json.dumps(payload)),
                                       MessageStructure='string')
            print(json.dumps(response))
            #print(json.dumps(response, indent=2))

    return {"statusCode": 200, "body": json.dumps(response)}

