"""Module that provides functions for SAP C4C."""

import xml.etree.ElementTree as ET
from collections import Counter
from urllib.parse import urlparse

import boto3
from pyspark.sql import functions as F
from pyspark.sql.types import NullType, StructType
from utils import camel_to_snake

s3 = boto3.client("s3")


# Map from C4C data types to Spark data types. See https://spark.apache.org/docs/latest/sql-ref-datatypes.html
C4C_TYPE_MAPPING = {
    "Edm.String": "string",
    "Edm.Boolean": "boolean",
    "Edm.DateTimeOffset": "timestamp",
    "Edm.DateTime": "timestamp",
    "Edm.Int16": "integer",
    "Edm.Int32": "integer",
    "Edm.Decimal": "decimal",
}


def get_c4c_metadata(metadata_path, collection_name):
    """
    Parses the data types from the metadata XML downloaded in another Glue Workflow.

    Args:
        metadata_path: Path in S3 to the metadata xml
        collection_name: The C4C collection for which to determine the data types for

    Returns: A dictionary where the key corresponds to the column name and the value
    corresponds to the spark data type

    """
    xml = (
        boto3.resource("s3")
        .Object(urlparse(metadata_path).netloc, urlparse(metadata_path).path[1:])
        .get()["Body"]
        .read()
    )
    root = ET.fromstring(xml)  # noqa: S314

    try:
        # For some collections, we need to look up their entity type first
        collection_name = (
            (
                root.find(".//{http://schemas.microsoft.com/ado/2008/09/edm}EntityContainer").find(
                    ".//{http://schemas.microsoft.com/ado/2008/09/edm}EntitySet[@Name='"
                    + collection_name
                    + "']"
                )
            )
            .attrib["EntityType"]
            .replace("c4codata.", "")
        )
        print(f"Using schema for {collection_name} instead.")
    except AttributeError:
        pass

    entity_type = root.find(
        ".//{http://schemas.microsoft.com/ado/2008/09/edm}EntityType[@Name='"
        + collection_name
        + "']"
    )
    entity_properties = entity_type.findall(
        ".//{http://schemas.microsoft.com/ado/2008/09/edm}Property"
    )
    meta = {"dtypes": {}, "names": {}}

    for entity_property in entity_properties:
        meta["dtypes"][entity_property.attrib["Name"]] = C4C_TYPE_MAPPING.get(
            entity_property.attrib["Type"], "string"
        )
        meta["names"][entity_property.attrib["Name"]] = entity_property.attrib.get(
            "{http://www.sap.com/Protocols/SAPData}label", entity_property.attrib["Name"]
        )

    return meta


def get_c4c_tobedeleted_metadata(metadata_path, collection_name):
    """
    Parses the data types from the metadata XML downloaded in another Glue Workflow.

    Args:
        metadata_path: Path in S3 to the metadata xml
        collection_name: The C4C collection for which to determine the data types for

    Returns: A dictionary where the key corresponds to the column name and the value
    corresponds to the spark data type

    """
    xml = (
        boto3.resource("s3")
        .Object(urlparse(metadata_path).netloc, urlparse(metadata_path).path[1:])
        .get()["Body"]
        .read()
    )
    root = ET.fromstring(xml)  # noqa: S314

    try:
        # For some collections, we need to look up their entity type first
        collection_name = (
            (
                root.find(".//{http://schemas.microsoft.com/ado/2008/09/edm}EntityContainer").find(
                    ".//{http://schemas.microsoft.com/ado/2008/09/edm}EntitySet[@Name='"
                    + collection_name
                    + "']"
                )
            )
            .attrib["EntityType"]
            .replace("tobedeleted.", "")
        )
        print(f"Using schema for {collection_name} instead.")
    except AttributeError:
        pass

    entity_type = root.find(
        ".//{http://schemas.microsoft.com/ado/2008/09/edm}EntityType[@Name='"
        + collection_name
        + "']"
    )
    entity_properties = entity_type.findall(
        ".//{http://schemas.microsoft.com/ado/2008/09/edm}Property"
    )
    meta = {"dtypes": {}, "names": {}}

    for entity_property in entity_properties:
        meta["dtypes"][entity_property.attrib["Name"]] = C4C_TYPE_MAPPING.get(
            entity_property.attrib["Type"], "string"
        )
        meta["names"][entity_property.attrib["Name"]] = entity_property.attrib.get(
            "{http://www.sap.com/Protocols/SAPData}label", entity_property.attrib["Name"]
        )

    return meta


def get_c4c_servicerequest_metadata(metadata_path, collection_name):
    """
    Parses the data types from the metadata XML downloaded in another Glue Workflow.

    Args:
        metadata_path: Path in S3 to the metadata xml
        collection_name: The C4C collection for which to determine the data types for

    Returns: A dictionary where the key corresponds to the column name and the
    value corresponds to the spark data type

    """
    xml = (
        boto3.resource("s3")
        .Object(urlparse(metadata_path).netloc, urlparse(metadata_path).path[1:])
        .get()["Body"]
        .read()
    )
    root = ET.fromstring(xml)  # noqa: S314

    try:
        # For some collections, we need to look up their entity type first
        collection_name = (
            (
                root.find(".//{http://schemas.microsoft.com/ado/2008/09/edm}EntityContainer").find(
                    ".//{http://schemas.microsoft.com/ado/2008/09/edm}EntitySet[@Name='"
                    + collection_name
                    + "']"
                )
            )
            .attrib["EntityType"]
            .replace("servicerequest.", "")
        )
        print(f"Using schema for {collection_name} instead.")
    except AttributeError:
        pass

    entity_type = root.find(
        ".//{http://schemas.microsoft.com/ado/2008/09/edm}EntityType[@Name='"
        + collection_name
        + "']"
    )
    entity_properties = entity_type.findall(
        ".//{http://schemas.microsoft.com/ado/2008/09/edm}Property"
    )
    meta = {"dtypes": {}, "names": {}}

    for entity_property in entity_properties:
        meta["dtypes"][entity_property.attrib["Name"]] = C4C_TYPE_MAPPING.get(
            entity_property.attrib["Type"], "string"
        )
        meta["names"][entity_property.attrib["Name"]] = entity_property.attrib.get(
            "{http://www.sap.com/Protocols/SAPData}label", entity_property.attrib["Name"]
        )

    return meta


def get_c4c_Codsrqml_metadata(metadata_path, collection_name):
    """
    Parses the data types from the metadata XML downloaded in another Glue Workflow.

    Args:
        metadata_path: Path in S3 to the metadata xml
        collection_name: The C4C collection for which to determine the data types for

    Returns: A dictionary where the key corresponds to the column name and the value
    corresponds to the spark data type

    """
    xml = (
        boto3.resource("s3")
        .Object(urlparse(metadata_path).netloc, urlparse(metadata_path).path[1:])
        .get()["Body"]
        .read()
    )
    root = ET.fromstring(xml)  # noqa: S314

    try:
        # For some collections, we need to look up their entity type first
        collection_name = (
            (
                root.find(".//{http://schemas.microsoft.com/ado/2008/09/edm}EntityContainer").find(
                    ".//{http://schemas.microsoft.com/ado/2008/09/edm}EntitySet[@Name='"
                    + collection_name
                    + "']"
                )
            )
            .attrib["EntityType"]
            .replace("CodsrqmlSvc.", "")
        )
        print(f"Using schema for {collection_name} instead.")
    except AttributeError:
        pass

    entity_type = root.find(
        ".//{http://schemas.microsoft.com/ado/2008/09/edm}EntityType[@Name='"
        + collection_name
        + "']"
    )
    entity_properties = entity_type.findall(
        ".//{http://schemas.microsoft.com/ado/2008/09/edm}Property"
    )
    meta = {"dtypes": {}, "names": {}}

    for entity_property in entity_properties:
        meta["dtypes"][entity_property.attrib["Name"]] = C4C_TYPE_MAPPING.get(
            entity_property.attrib["Type"], "string"
        )
        meta["names"][entity_property.attrib["Name"]] = entity_property.attrib.get(
            "{http://www.sap.com/Protocols/SAPData}label", entity_property.attrib["Name"]
        )

    return meta


def get_c4c_CodRespTimeAna_metadata(metadata_path, collection_name):
    """
    Parses the data types from the metadata XML downloaded in another Glue Workflow.

    Args:
        metadata_path: Path in S3 to the metadata xml
        collection_name: The C4C collection for which to determine the data types for

    Returns: A dictionary where the key corresponds to the column name and the value
    corresponds to the spark data type

    """
    xml = (
        boto3.resource("s3")
        .Object(urlparse(metadata_path).netloc, urlparse(metadata_path).path[1:])
        .get()["Body"]
        .read()
    )
    root = ET.fromstring(xml)  # noqa: S314

    try:
        # For some collections, we need to look up their entity type first
        collection_name = (
            (
                root.find(".//{http://schemas.microsoft.com/ado/2008/09/edm}EntityContainer").find(
                    ".//{http://schemas.microsoft.com/ado/2008/09/edm}EntitySet[@Name='"
                    + collection_name
                    + "']"
                )
            )
            .attrib["EntityType"]
            .replace("CodRespTimeAnaSvc.", "")
        )
        print(f"Using schema for {collection_name} instead.")
    except AttributeError:
        pass

    entity_type = root.find(
        ".//{http://schemas.microsoft.com/ado/2008/09/edm}EntityType[@Name='"
        + collection_name
        + "']"
    )
    entity_properties = entity_type.findall(
        ".//{http://schemas.microsoft.com/ado/2008/09/edm}Property"
    )
    meta = {"dtypes": {}, "names": {}}

    for entity_property in entity_properties:
        meta["dtypes"][entity_property.attrib["Name"]] = C4C_TYPE_MAPPING.get(
            entity_property.attrib["Type"], "string"
        )
        meta["names"][entity_property.attrib["Name"]] = entity_property.attrib.get(
            "{http://www.sap.com/Protocols/SAPData}label", entity_property.attrib["Name"]
        )

    return meta


def transform_c4c_df(df, meta):
    """
    Casts a Spark data frame built from C4C data to the types specified in dtypes.

    Contains C4C specific logic to convert e.g. C4C timestamps renames columns according to the SAP label.

    Args:
        df: a PySpark DataFrame
        meta (dict of dicts): {"dtypes": dictionary mapping from C4C dtype to Spark
            dtype, "names": dictionary of name mappings"}

    Returns:
        PySpark DataFrame with types casted according to `dtypes`
    """
    cols = []
    dtypes = meta["dtypes"]

    translate_col_name = lambda name: camel_to_snake(meta["names"].get(name, name))  # noqa: E731

    counter = Counter()
    counter.update([translate_col_name(col.name) for col in df.schema.fields])

    for col in df.schema.fields:
        dtype = dtypes.get(col.name, "string")
        col_name2 = translate_col_name(col.name)

        # If two different columns map to the same column name, keep the existing
        # one to avoid duplicate col names
        if counter[col_name2] > 1:
            print(f"Not renaming column {col.name} due to duplicate column names")
            col_name2 = col.name
        else:
            print(f"Renaming column {col.name} -> {col_name2}")

        if dtype == "timestamp":
            cols.append(
                (F.regexp_extract(F.col(col.name), "/Date\((\d+)\)/", 1) / 1000)
                .cast("timestamp")
                .alias(col_name2)
            )
        elif isinstance(col.dataType, StructType):
            # drop __deferred
            pass
        elif isinstance(col.dataType, NullType):
            # Parquet doesn't support NULL columns -- need to cast to double
            cols.append(F.col(col.name).cast("double").alias(col_name2))
        else:
            # Add it as is
            cols.append(F.col(col.name).cast(dtype).alias(col_name2))

    return df.select(cols)
