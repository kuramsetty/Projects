"""Utils script."""

import json
import re
import uuid
from collections import defaultdict
from datetime import datetime
from time import sleep
from typing import Any, Dict, List, Tuple
from urllib.parse import urlparse

import boto3
import pandas as pd
import requests
from botocore.exceptions import ClientError
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.window import Window

s3 = boto3.client("s3")


def remove_null_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Removes all columns from a Spark Data Frame where all elements are NULL.

    Args:
        df: PySpark DataFrame

    Returns: PySpark DataFrame with NULL columns removed

    """
    nulls_per_column = (
        df.select([F.count(F.when(F.isnull(c), c)).alias(c) for c in df.columns])
        .toPandas()
        .transpose()
    )
    nulls_per_column.columns = ["n_nulls"]
    df_count = df.count()
    all_null_columns = nulls_per_column[nulls_per_column.n_nulls == df_count].index.tolist()

    for col in all_null_columns:
        print(f"Removing all NULL column {col}")

    filtered_columns = [c for c in df.columns if c not in set(all_null_columns)]

    return df.select([F.col(c) for c in filtered_columns])


def remove_empty_array_columns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Removes columns containing empty arrays from the Spark DataFrame `df`.

    Args:
        df: Spark DataFrame

    Returns:
        Spark DataFrame with columns containing only empty arrays removed.
    """
    array_columns = [f.name for f in df.schema.fields if isinstance(f.dataType, T.ArrayType)]
    empty_arrays_per_column = (
        df.select([F.count(F.when(F.size(c) == 0, c)).alias(c) for c in array_columns])
        .toPandas()
        .transpose()
    )

    all_empty_array_columns = []
    if len(empty_arrays_per_column) > 0:
        empty_arrays_per_column.columns = ["n_nulls"]
        df_count = df.count()
        all_empty_array_columns = empty_arrays_per_column[
            empty_arrays_per_column.n_nulls == df_count
        ].index.tolist()

        for col in all_empty_array_columns:
            print(f"Removing empty array column {col}")

    filtered_columns = [c for c in df.columns if c not in set(all_empty_array_columns)]

    return df.select([F.col(c) for c in filtered_columns])


def keep_only_most_recent_per_group(df: pd.DataFrame, date_col: str, group: str) -> pd.DataFrame:
    """
    Removes all rows for each `group` column except the most recent one according to `date_col`.

    Args:
        df: PySpark DataFrame
        date_col: timestamp column used for ordering
        group: group column

    Returns: PySpark DataFrames with old rows removed

    """
    return (
        df.withColumn(
            "row_number",
            F.row_number().over(Window.partitionBy(F.col(group)).orderBy(F.col(date_col).desc())),
        )
        .filter(F.col("row_number") == 1)
        .drop("row_number")
    )


def parse_s3_uri(s: str) -> Tuple[str, str]:
    """
    Parses an S3 URI into bucket name and object key.

    Args:
        s: string to parse

    Returns: 2-tuple with (bucket, key)

    """
    bucket = urlparse(s).netloc
    key = urlparse(s).path[1:]

    return bucket, key


def get_all_s3_objects(s3: boto3.client, **base_kwargs: Any) -> List[Dict[str, Any]]:  # noqa: D103
    objects = []
    continuation_token = None
    while True:
        list_kwargs = dict(MaxKeys=1000, **base_kwargs)
        if continuation_token:
            list_kwargs["ContinuationToken"] = continuation_token
        response = s3.list_objects_v2(**list_kwargs)
        if response.get("Contents", []):
            objects.extend(response["Contents"])
        # yield from response.get('Contents', [])
        if not response.get("IsTruncated"):  # At the end of the list?
            break
        continuation_token = response.get("NextContinuationToken")
    return objects


def recursive_s3_delete(bucket: str, prefix: str) -> List[Dict[str, str]]:
    """
    Recursively deletes a directory/prefix from S3.

    Args:
        bucket: bucket name
        prefix: prefix to delete

    Returns: deleted objects

    """
    existing_objects = get_all_s3_objects(s3=s3, Bucket=bucket, Prefix=prefix)

    if not existing_objects:
        return

    for existing_object in existing_objects:
        existing_key = existing_object["Key"]
        print(f"Deleting s3://{bucket}/{existing_key}.")
        s3.delete_object(Bucket=bucket, Key=existing_key)

    return existing_objects


def camel_to_snake(s: str) -> str:
    """
    Converts CamelCase to snake_case.

    Args:
        s: string to convert

    Returns: new string in snake_case

    """
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    s = re.sub(r"([a-z\d])([A-Z])", r"\1_\2", s)
    s = s.replace("-", "_").replace(" ", "_")
    s = s.lower()
    s = re.sub(r"_([a-z])_", r"\1_", s)
    s = "".join(c for c in s if c.isalpha() or c.isnumeric() or c == "_")
    if s[0] == "_":
        s = s[1:]
    if s[-1] == "_":
        s = s[:-1]

    return s


def flatten(schema, prefix: str = ""):  # noqa: D103
    # return a list of sub-items to select, within a given field
    def field_items(field):
        name = f"{prefix}.{field.name}" if prefix else field.name
        if type(field.dataType) == T.StructType:
            return flatten(field.dataType, name)
        else:
            return [F.col(name).alias(name.replace(".", "_"))]

    return [item for field in schema.fields for item in field_items(field)]


def retrieve_odata(
    url: str,
    auth: Tuple[str, str],
    session: requests.Session(),
    language: str = "en",
    max_attempts: int = 3,
) -> dict:
    """
    Retrieve data from an OData endpoint.

    Args:
        url (str): The URL of the OData endpoint.
        auth (Tuple[str, str]): Tuple containing the username and password for authentication.
        session (requests.Session): A session object for making HTTP requests.
        language (str): The language for the request. Defaults to "en".
        max_attempts (int): The maximum number of retry attempts. Defaults to 3.

    Returns:
        dict: The JSON response from the OData endpoint.
    """
    headers = {"Accept-Language": language}
    for attempt in range(max_attempts):
        try:
            result = session.get(url, auth=auth, headers=headers)
            result.raise_for_status()
            try:
                result_json = result.json()
            except json.JSONDecodeError:
                raise ValueError(f"Response is invalid JSON: {result.text}")
            try:
                result_json["d"]["results"]
            except KeyError:
                raise ValueError(f"Response does not contain ['d']['results']: {result.text}")
            return result_json
        except requests.HTTPError as e:
            if attempt < max_attempts - 1:
                sleep_time = 2**attempt  # exponential backoff
                print(
                    f"Request failed with {result.status_code}. Retrying in {sleep_time} seconds."
                )
                sleep(sleep_time)
                continue
            else:
                raise ValueError(
                    f"Status code {result.status_code} returned. Message was: {result.text}"
                ) from e


def extract_odata_full(batch_generator: List[dict], destination: str, cleanup: bool = True) -> int:
    """
    Extracts the full data set from an OData endpoint and writes it to `destination`.

    Args:
        batch_generator: generator instance that yields individual batches
        destination: S3 location to write results
        cleanup: clean previous files created

    Returns: Number of records written
    """
    # Generate a unique identifier for this execution
    execution_id = str(uuid.uuid4())

    bucket, key_prefix = parse_s3_uri(destination)
    keys_written = set()

    records_received = 0

    for i, batch in enumerate(batch_generator):
        records_received += len(batch)
        zfilled_i = str(i).zfill(10)

        # Generate a unique key using execution_id and current timestamp
        timestamp = datetime.utcnow().strftime("%Y%m%d%H%M%S%f")[:-3]
        key = key_prefix + f"/part_{execution_id}_{timestamp}_{zfilled_i}.jsonl"

        print(f"Storing to s3://{bucket}/{key}")

        s3.put_object(
            Body="\n".join(json.dumps(record) for record in batch).encode("utf-8"),
            Bucket=bucket,
            Key=key,
        )
        keys_written.add(key)

    if cleanup:
        print("")
        try:
            existing_objects = get_all_s3_objects(s3=s3, Bucket=bucket, Prefix=f"{key_prefix}/")
        except KeyError:
            existing_objects = []

        for existing_object in existing_objects:
            existing_key = existing_object["Key"]
            if existing_key not in keys_written:
                print(
                    f"WARNING: s3://{bucket}/{existing_key} exists, but was not written by this job; deleting."
                )
                s3.delete_object(Bucket=bucket, Key=existing_key)

    return records_received


def extract_odata_delta(batch_generator: List[dict], destination: str, partition_func=None):
    """
    Extracts a delta from an OData endpoint and writes it to `destination.

    Args:
        batch_generator: generator instance that yields individual batches
        destination: S3 location to write results to
        partition_func: A function to partition the delta data

    Returns: Number of records written

    """
    partitioned_records = defaultdict(list)
    records_received = 0

    for batch in batch_generator:
        for record in batch:
            partitions = partition_func(record)
            partitioned_records[partitions].append(record)

    for partition, records in partitioned_records.items():
        final_destination = f"{destination}"
        for key, value in partition:
            final_destination += f"/{key}={value}"

        final_destination += "/data.jsonl"
        bucket, key = parse_s3_uri(final_destination)

        try:
            new_records = (
                boto3.client("s3")
                .get_object(Bucket=bucket, Key=key)["Body"]
                .read()
                .decode("utf-8")
                .split("\n")
            )
            print(f"Found {len(new_records)} existing records - appending while deduplicating.")
            records_received += len(new_records)
        except ClientError as ex:
            if ex.response["Error"]["Code"] != "NoSuchKey":
                raise
            new_records = []
            print("Found no existing records - creating.")

        new_records.extend(json.dumps(record) for record in records)

        # Deduplicate while preserving order
        new_records = list(dict.fromkeys(new_records))

        print(f"Writing a total of {len(new_records)} records to s3://{bucket}/{key}.")

        boto3.client("s3").put_object(
            Body="\n".join(record for record in new_records).encode("utf-8"), Bucket=bucket, Key=key
        )

    return records_received


def retrieve_odata_generator(
    url: str, auth: Tuple[str, str], session: requests.Session(), max_errors: int = 4
) -> List[dict]:
    """
    Generator function to retrieve data from an OData endpoint.

    Args:
        url (str): The URL of the OData endpoint.
        auth (Tuple[str, str]): Tuple containing the username and password for authentication.
        session (requests.Session): A session object for making HTTP requests.
        max_errors (int): The maximum number of errors allowed before raising an exception.
                          Defaults to 4.

    Yields:
        List[dict]: A list of dictionaries containing data retrieved from the OData endpoint.
    """
    next_url = url
    i = 0
    errors = 0
    records_received = 0
    total_bytes = 0
    start_time = datetime.now()
    previous_time = datetime.now()
    backoff = 1

    while True:
        now = datetime.now()
        print(
            f"\n---- iteration {i}, trial {errors}, total {total_bytes / 1e6} MB, "
            f"step {(now - previous_time).seconds} seconds, elapsed {now - start_time} ----"
        )

        previous_time = now

        try:
            print(f"Retrieving {next_url}")
            res = retrieve_odata(next_url, auth=auth, session=session)
            errors = 0
            backoff = 1  # Reset backoff on successful request
        except ValueError:
            if errors >= max_errors:
                raise
            errors += 1
            # Wait with exponential backoff, max 64 seconds
            sleep(backoff)
            backoff = min(64, backoff * 2)  # Double backoff, up to a maximum of 64 seconds
            continue

        this_bytes = len(json.dumps(res["d"]["results"]).encode("utf-8"))
        total_bytes += this_bytes
        records_received += len(res["d"]["results"])

        if records_received > 0:
            # print(f"Retrieved {len(res['d']['results'])} records with {this_bytes / 1e6} MB.")
            yield res["d"]["results"]

        else:
            print("No records received.")

        try:
            next_url = res["d"]["__next"]
            i += 1
        except KeyError:
            break

    if records_received > 0:
        print(
            f"Done. Retrieved a total number of {records_received} records in {i + 1} partitions "
            f"with a total size of {total_bytes / 1e6} MB. for url {url}"
        )


def extract_kapost_api(
    url: str, destination: str, endpoint: str, secret: dict, max_errors: int = 3
) -> int:
    """
    Extracts data from the Kapost API and saves it to the specified destination.

    Args:
        url (str): The base URL of the Kapost API.
        destination (str): The destination S3 path to save the extracted data.
        endpoint (str): The specific API endpoint to extract data from.
        secret (dict): A dictionary containing authentication credentials for accessing the Kapost API.
        max_errors (int, optional): The maximum number of errors allowed before raising an exception.
        Defaults to 3.

    Returns:
        int: The total number of records received during the extraction process.
    """
    records_received = 0
    errors = 0
    res = {"pagination": {"next": 1}}
    while res["pagination"]["next"]:
        page = res["pagination"]["next"]
        try:
            print(f"{url}/{endpoint}?detail=full&page={page}&per_page=50")
            res = requests.get(  # noqa: S113
                f"{url}/{endpoint}?detail=full&page={page}&per_page=50",
                auth=(secret["api_key"], "x"),
            )
            print(f"GET Api Response::{res.status_code}")
            if res.status_code == 200:  # noqa: PLR2004
                res = res.json()

                response = res["response"]
                records_received += len(response)

                bucket, key = parse_s3_uri(destination)
                print(f"storing page # {page}.")
                target_key = f"{key}/page_id={page}/data.jsonl"
                s3.put_object(
                    Body="\n".join(json.dumps(elem) for elem in response),
                    Bucket=bucket,
                    Key=target_key,
                )
                print(f"destination path: s3://{bucket}/{target_key}")
            else:
                res["pagination"]["next"] = page
        except ValueError:
            res["pagination"]["next"] = page
            if errors >= max_errors:
                raise
            errors += 1
            sleep(4)
            continue

    return records_received
