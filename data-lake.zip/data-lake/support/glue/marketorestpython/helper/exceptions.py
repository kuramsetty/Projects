"""Marketo exception."""


class MarketoException(Exception):  # noqa: D101
    message = None
    code = None

    def __init__(self, exc={"message": None, "code": None}):  # noqa: D107
        self.message = exc["message"]
        self.code = exc["code"]

    def __str__(self):  # noqa: D105
        return "Marketo API Error Code {}: {}".format(self.code, self.message)
