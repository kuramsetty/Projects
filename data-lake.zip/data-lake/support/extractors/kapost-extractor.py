"""Does extraction from kapost api and write the results into s3."""

import argparse
import json
from datetime import datetime
from time import sleep
from typing import Dict

import boto3
import requests
from utils import parse_s3_uri

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")

parser = argparse.ArgumentParser(description="Ingest data from Kapost")
parser.add_argument("--source", dest="source", help="Source Kapost endpoint")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
parser.add_argument(
    "--force-full-extract", dest="force", help="Force full extract", action="store_true"
)
args = parser.parse_known_args()[0]

s3 = boto3.client("s3")
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="kapost-api-key")["SecretString"]
)

# Used for for delta updates via DynamoDB table
now = datetime.utcnow()
timestamp = now.isoformat().split(".")[0]


def extract_kapost_api(
    url: str, destination: str, endpoint: str, secret: Dict[str, str], max_errors: int = 3
) -> int:
    """
    Extracts data from a Kapost API endpoint and uploads it to an S3 destination.

    Args:
        url (str): The base URL of the Kapost API.
        destination (str): The S3 URI where the extracted data will be uploaded.
        endpoint (str): The specific API endpoint to extract data from.
        secret (Dict[str, str]): A dictionary containing the secret credentials needed for API authentication.
        max_errors (int): The maximum number of errors allowed before raising an exception. Defaults to 3.

    Returns:
        int: The total number of records received and uploaded to S3.
    """
    records_received = 0
    errors = 0
    next_page = 1

    while next_page:
        try:
            api_url = f"{url}/{endpoint}?detail=full&page={next_page}&per_page=50"
            print(api_url)

            # Send the GET request
            res = requests.get(api_url, auth=(secret["api_key"], "x"))  # noqa: S113
            print(f"GET Api Response::{res.status_code}")

            if res.status_code == 200:  # noqa: PLR2004
                # Parse the JSON content
                json_content = res.json()
                response = json_content["response"]

                records_received += len(response)

                # Extract S3 bucket and key from the destination
                bucket, key = parse_s3_uri(destination)

                # Define the S3 target key
                target_key = f"{key}/page_id={next_page}/data.jsonl"

                # Upload the JSON content to S3
                s3.put_object(
                    Body="\n".join(json.dumps(elem) for elem in response),
                    Bucket=bucket,
                    Key=target_key,
                )
                print(f"Destination path: s3://{bucket}/{target_key}")

                # Update the next page for the next iteration
                next_page = json_content["pagination"].get("next")
            else:
                # Handle non-200 status codes
                print(f"Failed to get data from API. Status code: {res.status_code}")
                break

        except Exception as err:
            print(f"An error occurred: {err}")
            if errors >= max_errors:
                raise
            errors += 1
            sleep(4)
            continue

    return records_received


try:
    print("Performing Full Extract")
    records = extract_kapost_api(
        url=secret["url"], destination=args.destination, endpoint=args.source, secret=secret
    )

    table.put_item(
        Item={
            "last_import": timestamp,
            "job_name": args.job_name,
            "records_received": records,
        }
    )
except Exception as e:
    # Handle exceptions
    print(f"An error occurred: {e}")
