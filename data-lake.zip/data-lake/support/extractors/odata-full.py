"""Does a full export (entire collection) from OData endpoint. Results written to S3 in JSON formt."""

import argparse
import json

import boto3
import requests
from utils import extract_odata_full, retrieve_odata_generator

# parsing the job details
parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--source", dest="source", help="Source URI of OData endpoint")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
args = parser.parse_known_args()[0]

s3 = boto3.client("s3")
session = requests.Session()
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="sap-c4c-odata")["SecretString"]
)
auth = (secret["username"], secret["password"])
url = args.source + "/?$format=json"
batches = retrieve_odata_generator(url, auth, session)
records_received = extract_odata_full(batch_generator=batches, destination=args.destination)
print("Data written successfully")
