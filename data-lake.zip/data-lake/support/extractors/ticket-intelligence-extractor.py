"""Does a CDC extract (incremental) from OData endpoint. Results are written to S3 in JSON format."""

import argparse
import json
from datetime import datetime
import boto3

import re
from time import sleep
from datetime import datetime
from urllib.parse import urlparse
from collections import defaultdict
from botocore.exceptions import ClientError
import json
import requests
import datetime as dt
from dateutil.relativedelta import relativedelta as rd
import concurrent.futures

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")
                            

secret123 = json.loads(boto3.client("secretsmanager").get_secret_value(SecretId="sap-c4c/TicketIntelligence_Performance")["SecretString"])
auth123=(secret123['username'], secret123['password'])

def fetch_data(object_id, auth, headers):
    """
    Fetches data from a child collection of a specified object in the OData API.

    Args:
        object_id (str): The ID of the parent object.
        auth (Tuple[str, str]): A tuple containing the username and password for authentication.
        headers (Dict[str, str]): A dictionary containing HTTP headers.
        child_collection (str): The name of the child collection.

    Returns:
        List[dict]: A list of dictionaries containing the fetched data.
    """
    url = f"https://my343420.crm.ondemand.com/sap/c4c/odata/analytics/ds/Codsrqml.svc/Codsrqml?$select=C_CauseservissuecategClassVal,C_IncidensrvissuecategClassVal,C_ObjectservissuecategClassVal,C_ServiceissuecategoryClassVal,C_TicketUuid,C_MlSrvReqPriorityText,C_TicketIncCategoryId,C_TicketIncCategoryUuid,C_MlIncCategoryId,C_MlIncCategoryName,K_CauseCatConfidence,K_IncidentCatConfidence,K_ObjCatConfidence,K_ServiceCatConfidence,K_ServPrioConfidence,Count&$filter=(C_TicketUuid eq guid'{object_id}')&$format=json"
    print("URL:", url)
    #data = retrieve_odata(url=url,auth=auth)
    result = requests.get(url, auth=auth, headers=headers)
    data = result.json()
    return data.get('d', {}).get('results', [])


def parse_s3_uri(s):
    """
    Parses an S3 URI into bucket name and object key
    Args:
        s: string to parse
    Returns: 2-tuple with (bucket, key)
    """
    bucket = urlparse(s).netloc
    key = urlparse(s).path[1:]
    return bucket, key


def retrieve_odata_count(url, auth):
    """
    Retrieves the expected count from an OData Endpoint.

    Args:
        url: OData Endpoint URL
        auth: 2-tuple of (username, password)

    Returns: the expected count

    """
    result = requests.get(url + "/$count", auth=auth)

    if result.status_code != 200:
        raise ValueError(f"Status code {result.status_code} returned. Message was: {result.text}")

    return int(result.text)


def retrieve_odata_generator1(url, auth,max_errors=4):
    
    next_url = url
    i = 0
    errors = 0
    records_received = 0
    total_bytes = 0
    start_time = datetime.now()
    previous_time = datetime.now()

    if "filter" in url:
        expected_count = -1
    else:
        try:
            expected_count = retrieve_odata_count("/".join(url.split("/")[:-1]), auth)
        except:
            expected_count = -1

    while True:
        
        now = datetime.now()

        percentage_received = records_received / expected_count * 100
        if percentage_received > 100:
            percentage_received = 100

        if expected_count > 0:
            print("")
#             print(
#                 f"\n---- iteration {i}, trial {errors}, total {total_bytes / 1e6} MB, "
#                 f"received {records_received}/{expected_count} ({int(percentage_received)}%) records, "
#                 f"step {(now - previous_time).seconds} seconds, elapsed {now - start_time} ----"
#             )
        else:
            print("")
#             print(
#                 f"\n---- iteration {i}, trial {errors}, total {total_bytes / 1e6} MB, "
#                 f"step {(now - previous_time).seconds} seconds, elapsed {now - start_time} ----"
#             )
        previous_time = now

        print(f"Retrieving {next_url}")
        try:
            res,res123 = retrieve_odata1(next_url, auth=auth)
            errors = 0
        except ValueError:
            if errors >= max_errors:
                raise
            errors += 1
            sleep(4)
            continue

#         this_bytes = len(json.dumps(res).encode("utf-8"))
        this_bytes = len(res)
        total_bytes += this_bytes
        records_received += len(res)
        print("********")
        if records_received > 0:
            print(f"Retrieved {len(res)} records with {this_bytes / 1e6} MB.")
            yield res123

        else:
            print("No records received.")

        try:
            next_url = res["d"]["__next"]
            i += 1
        except KeyError:
            break
    
     
def retrieve_odata1(url, auth, language="en"):
    
    
    headers = {'Accept':'application/json','Content-Type':'application/json',"Accept-Language": "en-US"}
    result = requests.get(url=url, auth=auth, headers=headers)

    if result.status_code != 200:
        raise ValueError(f"Status code {result.status_code} returned. Message was: {result.text}")

    try:
        
        result1 =  result.json()
        result1 = result1['d']['results']
        result_json123 = []
        
        object_ids = [i['ObjectID'] for i in result1]
        
        with concurrent.futures.ThreadPoolExecutor() as executor:
            # Submit tasks to fetch data for each ObjectID
            future_to_object_id = {executor.submit(fetch_data, object_id, auth123, headers): object_id for object_id in object_ids}
    
            # Collect results
            for future in concurrent.futures.as_completed(future_to_object_id):
                object_id = future_to_object_id[future]
                try:
                    data = future.result()
                    if data:
                        result_json123.append(data[0])  # Assuming you want to append the first result
                        print(f"Data for {object_id} added to result_json123 -->{len(result_json123)}")
                    else:
                        result_json123.append({})  # Append empty dictionary if no data found
                except Exception as e:
                    print(f"Error fetching data for {object_id}: {e}")

        result_json = result.json()
    except json.JSONDecodeError:
        raise ValueError(f"Response is invalid JSON: {result.text}")

    try:
        result_json
    except KeyError:
        raise ValueError(f"Response does not contain ['d']['results']: {result.text}")
    
    return result_json,result_json123


def retrieve_odata_generator_parent(url, auth, max_errors=4):
    """
    Iteratively retrieves OData responses by following the `__next` link in each response.

    Args:
        url: OData Endpoint URL
        auth: 2-tuple of (username, password)
        max_errors: maximum number of failed retries

    Returns: Python generator for each OData chunk

    """

    next_url = url
    i = 0
    errors = 0
    records_received = 0
    total_bytes = 0
    start_time = datetime.now()
    previous_time = datetime.now()

    if "filter" in url:
        expected_count = -1
    else:
        try:
            expected_count = retrieve_odata_count("/".join(url.split("/")[:-1]), auth)
        except:
            expected_count = -1

    while True:
        now = datetime.now()

        percentage_received = records_received / expected_count * 100
        if percentage_received > 100:
            percentage_received = 100

        if expected_count > 0:
            # print(
            #     f"\n---- iteration {i}, trial {errors}, total {total_bytes / 1e6} MB, "
            #     f"received {records_received}/{expected_count} ({int(percentage_received)}%) records, "
            #     f"step {(now - previous_time).seconds} seconds, elapsed {now - start_time} ----"
            # )
            print("")
        else:
            # print(
            #     f"\n---- iteration {i}, trial {errors}, total {total_bytes / 1e6} MB, "
            #     f"step {(now - previous_time).seconds} seconds, elapsed {now - start_time} ----"
            # )
            print("")
        previous_time = now

        print(f"Retrieving {next_url}")
        try:
            res = retrieve_odata(next_url, auth=auth)
            errors = 0
        except ValueError:
            if errors >= max_errors:
                raise
            errors += 1
            sleep(4)
            continue

        this_bytes = len(json.dumps(res["d"]["results"]).encode("utf-8"))
        total_bytes += this_bytes
        records_received += len(res["d"]["results"])

        if records_received > 0:
            print(f"Retrieved {len(res['d']['results'])} records with {this_bytes / 1e6} MB.")
            yield res["d"]["results"]

        else:
            print("No records received.")

        try:
            next_url = res["d"]["__next"]
            i += 1
        except KeyError:
            break

    if records_received > 0:
        print("")
        print(f"Done. Retrieved a total number of {records_received} records in {i + 1} partitions "
              f"with a total size of {total_bytes / 1e6} MB.")


def retrieve_odata(url, auth, language="en",max_attempts: int = 5):
    """
    Retrieves a single response from an OData endpoint.

    Args:
        url (str): OData Endpoint URL
        auth (dict): 2-tuple of (username, password)

    Returns: Dictionary containing the OData response
    """
    headers = {"Accept-Language": language}
    retry_interval = 30 * 60  # Retry interval in seconds (30 minutes)
    for attempt in range(max_attempts):
        try:
            result = requests.get(url, auth=auth, headers=headers)
            if result.status_code != 200:
                raise ValueError(f"Status code {result.status_code} returned. Message was: {result.text}")
            
            try:
                result_json = result.json()
            except json.JSONDecodeError:
                raise ValueError(f"Response is invalid JSON: {result.text}")

            try:
                result_json["d"]["results"]
            except KeyError:
                raise ValueError(f"Response does not contain ['d']['results']: {result.text}")

            return result_json
        except requests.HTTPError as e:
            if result.status_code in {500, 501, 502, 503, 504, 505} and attempt < max_attempts - 1:
                # sleep_time = 2**attempt  # exponential backoff
                print(f"Request failed with {result.status_code}. Retrying in {retry_interval} seconds.")
                sleep(retry_interval)
                continue
            else:
                raise ValueError(
                    f"Retired for 5 times and Status code {result.status_code} returned. Message was: {result.text}"
                ) from e
        except (requests.exceptions.ConnectionError, requests.exceptions.Timeout) as e:
            if attempt < max_attempts - 1:
                # sleep_time = 2 ** attempt  # exponential backoff
                print(f"Network error encountered: {e}. Retrying in {retry_interval} seconds.")
                sleep(retry_interval)
                continue
            else:
                raise ValueError(f"Network error encountered. Max attempts reached. Error: {e}") from e
    


def extract_odata_delta(batch_generator,batch_generator_parent, destination, partition_func=None):

    partitioned_records = defaultdict(list)
    records_received = 0
    partitions_list=[]
    
    for batch in batch_generator_parent:
        batch_partitions_list=[]
        for record in batch:
            partitions = partition_func(record)
            batch_partitions_list.append(partitions)
            
        partitions_list.append(batch_partitions_list)
 
    bgs1 = 0
    for batch1 in batch_generator:
        bg= 0
        for record1 in batch1:
            try:
                if  partitions_list[bgs1][bg]:
                    partitions = partitions_list[bgs1][bg]
                    partitioned_records[partitions].append(record1)
            except:
                print("except")
            bg=bg+1
        bgs1 = bgs1 +1

    for partition, records in partitioned_records.items():
        final_destination = f"{destination}"
        for key, value in partition:
            final_destination += f"/{key}={value}"

        final_destination += "/data.jsonl"
        bucket, key = parse_s3_uri(final_destination)
        print("bucket, key",bucket, key)
        try:
            new_records = boto3.client("s3").get_object(
                Bucket=bucket,
                Key=key
            )["Body"].read().decode("utf-8").split("\n")
            print(f"Found {len(new_records)} existing records - appending while deduplicating.")
            records_received += len(new_records)
        except:
            # if ex.response['Error']['Code'] != 'NoSuchKey':
            #     raise
            new_records = []
            print(f"Found no existing records - creating.")
        new_records = []
        new_records.extend(json.dumps(record) for record in records)

        # Deduplicate while preserving order
        new_records = list(dict.fromkeys(new_records))

        print(f"Writing a total of {len(new_records)} records to s3://{bucket}/{key}.")

        boto3.client("s3").put_object(
            Body="\n".join(record for record in new_records).encode("utf-8"),
            Bucket=bucket,
            Key=key
        )

    return records_received
    
def extract_odata_full(batch_generator, destination, cleanup=True):
    """
    Extracts the full data set from an OData endpoint and writes it to `destination`.

    Args:
        batch_generator: generator instance that yields individual batches
        destination: S3 location to write results to
        cleanup: Clean up (delete) parts that were downloaded by a previous run of this job that might still be around

    Returns: Number of records written

    """

    bucket, key_prefix = parse_s3_uri(destination)
    keys_written = set()

    records_received = 0

    for i, batch in enumerate(batch_generator):
        records_received += len(batch)
        zfilled_i = str(i).zfill(10)
        key = key_prefix + f"/part_{zfilled_i}.jsonl"

        print(f"Storing to s3://{bucket}/{key}")

        s3.put_object(
            Body="\n".join(json.dumps(record) for record in batch).encode("utf-8"),
            Bucket=bucket,
            Key=key
        )
        keys_written.add(key)

    # if cleanup:
    #     print("")
    #     try:
    #         existing_objects = get_all_s3_objects(s3=s3, Bucket=bucket, Prefix=f"{key_prefix}/")
    #     except KeyError:
    #         existing_objects = []

    #     for existing_object in existing_objects:
    #         existing_key = existing_object["Key"]
    #         if existing_key not in keys_written:
    #             print(f"WARNING: s3://{bucket}/{existing_key} exists, but was not written by this job; deleting.")
    #             s3.delete_object(Bucket=bucket, Key=existing_key)

    return records_received


parser = argparse.ArgumentParser(description='Ingest data from OData API')
parser.add_argument('--source', dest='source', help="Source URI of OData endpoint")
parser.add_argument('--destination', dest='destination', help="Destination path in S3")
parser.add_argument('--job-name', dest='job_name', help="Name of this job (used for DynamoDB metadata)")
parser.add_argument('--changed-column', dest='changed_column', help="Column containing the `changed on` timestamp")
parser.add_argument('--load', dest='load', help="full load or delta load")
parser.add_argument('--force-full-extract', dest='force', help="Force full extract", action="store_true")
args = parser.parse_known_args()[0]

secret = json.loads(boto3.client("secretsmanager").get_secret_value(SecretId="sap-c4c-odata")["SecretString"])
auth = (secret['username'], secret['password'])

# Used for for delta updates via DynamoDB table
timestamp = datetime.utcnow().isoformat().split(".")[0] + "Z"

last = table.get_item(Key={"job_name": args.job_name}).get("Item", None)

if last and not args.force:
    last_import = last.get("last_import", None)
    last_full_import = last.get("last_full_import", None)
else:
    last_import = timestamp
    last_full_import = timestamp

print(f"Last import: {last_import}, last full import: {last_full_import}.")

records_received = 0


def partition_func(record):
    changed = datetime.utcfromtimestamp(int(record[args.changed_column][6:-2]) / 1000)
    partitions = (
        ("x_etl_changed_year", changed.year),
        ("x_etl_changed_month", changed.month),
        ("x_etl_changed_day", changed.day)
    )
    return partitions


if args.load == 'full':
    print("full load*****")
    main_source = "https://my343420.crm.ondemand.com/sap/c4c/odata/v1/c4codataapi/ServiceRequestCollection"
    url = main_source + f"/?$format=json"
    print("url",url)
    batches = retrieve_odata_generator1(url=url, auth=auth)
    destination = f"{args.destination}/full"

    records_received = extract_odata_full(
        batch_generator=batches,
        destination=destination
             
    )
    
    
elif args.load == 'delta':
    print("Delta load*****")
    main_source = "https://my343420.crm.ondemand.com/sap/c4c/odata/v1/c4codataapi/ServiceRequestCollection"
    url = main_source + f"/?$format=json&$filter={args.changed_column} ge datetimeoffset'{last_import}' or {args.changed_column} eq datetimeoffset'{last_import}'"
    print("url",url)
    batches = retrieve_odata_generator1(url=url, auth=auth)
    batches_parent = retrieve_odata_generator_parent(url=url, auth=auth)
    destination = f"{args.destination}/delta"

    records_received = extract_odata_delta(
        batch_generator=batches,
        batch_generator_parent=batches_parent,
        destination=destination,
        partition_func=partition_func
    )


table.put_item(
    Item={
        'last_import': timestamp,
        'last_full_import': last_full_import,
        'job_name': args.job_name,
        # 'records_received': records_received,
    }
)
