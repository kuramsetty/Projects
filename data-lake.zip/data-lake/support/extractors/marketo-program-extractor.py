"""Marketo program extraction process."""

import argparse
import json
from urllib.parse import urlparse

import boto3
from marketorestpython.client import MarketoClient

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")

parser = argparse.ArgumentParser(description="Ingest data from Marketo Programs")
parser.add_argument("--source", dest="source", help="Source Marketo programs extract")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
args = parser.parse_known_args()[0]

s3 = boto3.client("s3")
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="data-lake-adobe-marketo")[
        "SecretString"
    ]
)
client = MarketoClient(secret["munchkin_id"], secret["client_id"], secret["client_secret"])

res = client.execute(method=args.source)

s3.put_object(
    Body="\n".join(json.dumps(elem) for elem in res),
    Bucket=urlparse(args.destination).netloc,
    Key=urlparse(args.destination).path[1:] + "/data.jsonl",
)
