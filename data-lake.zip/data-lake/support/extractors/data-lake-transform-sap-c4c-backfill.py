import sys
import traceback
import re
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.sql import SQLContext, SparkSession
from pyspark.context import SparkContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
from pyspark.sql.window import Window
from awsglue.context import GlueContext
from awsglue.job import Job
from datetime import datetime, timedelta
import boto3
import json
import requests
from time import sleep

glueContext = GlueContext(SparkContext.getOrCreate())
spark = SparkSession(SparkContext.getOrCreate())
args = getResolvedOptions(sys.argv, ['JOB_NAME'])
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

destination = "s3://cap-prod-data-lake/sap_c4c/raw/ChangeDocumentCollection/full"
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="sap-c4c-odata")["SecretString"]
)
auth = (secret["username"], secret["password"])

# Read Utility Function
def read_data_function(database, table_name):
    df_read = glueContext.create_dynamic_frame.from_catalog(database=database, table_name=table_name).toDF()
    return df_read
 
try:
    org_df = read_data_function("sap_c4c", "changedocumentcollection")
    org_df = org_df.select("objectuuid", "id").dropDuplicates()
    
    org_df = org_df.filter(col("objectuuid") != "0206D92D5B0A1EDD92C7B9F632489DD1")
    print("after id filter")

    # Read UUIDs from the S3 file
    data_df = spark.read.text("s3://tempbucketcdc/missing.txt").withColumnRenamed("value", "objectuuid")
    filtered_df = data_df.filter("objectuuid IS NOT NULL")
    uuids_list = [row['objectuuid'] for row in filtered_df.select('objectuuid').distinct().collect()]
    
    print("len of list", len(uuids_list))

    # Process each UUID
    for uuid in uuids_list:
        print("checking data from objectuuid---", uuid)

        url = f"https://my343420.crm.ondemand.com/sap/c4c/odata/v1/changedoclist/ChangeDocumentCollection?$filter=BusinessObject%20eq%20%27Opportunity%27%20and%20ObjectUUID%20eq%20%27{uuid}%27"
    
        headers = {"Accept-Language": 'en', 'Accept': 'application/json'}
    
        records_received = 0
        errors = 0
        top_result = 1000
        skip_result = 0
        res = {"d": {"results": True}}
        count = 0
        final = []

        while res["d"]["results"]:
            print("count---- ", count, "top_result----", top_result)
            url_paginated = f"{url}&$skip={skip_result}&$top={top_result}&$format=json"
            try:
                result = requests.get(url_paginated, auth=auth, headers=headers)
                res = result.json()
                response = res["d"]["results"]
                if response:
                    records_received += len(response)
                    final.extend(response)
                    skip_result += top_result
                    count += 1
            except Exception as e:
                if errors >= 3:
                    print(f"Not Performing c4c Identity extract dated ")
                    raise
                errors += 1
                sleep(4)
                
        odata_df = spark.createDataFrame(final)
        print("odata_df", odata_df.count())

        # Rename columns in odata_df to match org_df
        odata_df = odata_df.withColumnRenamed("ObjectUUID", "objectuuid").withColumnRenamed("ID", "id")

        # Perform a left anti join to get records in odata_df but not in org_df
        unique_from_df2 = odata_df.join(org_df, on=["objectuuid", "id"], how="left_anti")
        unique_from_df2 = unique_from_df2.withColumnRenamed("objectuuid", "ObjectUUID").withColumnRenamed("id", "ID")

        if unique_from_df2.count() > 0:
            print("unique_from_df2", unique_from_df2.count())
            unique_from_df2.repartition(1).write.mode("append").json(destination + "/Backfill")
            print("The write operation for UUID has been completed.", uuid)
        else:
            print("Data was already loaded")
            
        del unique_from_df2
        
except Exception as err:
    traceback.print_exc()
    print(err)
    raise Exception("Error encountered while executing the job. Check the error stack in Output logs", err)