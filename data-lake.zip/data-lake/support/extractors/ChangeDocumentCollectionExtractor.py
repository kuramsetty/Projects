"""Does a CDC extract (incremental) from OData endpoint. Results are written to S3 in JSON format."""

# The way this works is as follows:
#   1. A full extract is done once and written to a bucket into a full/ subdirectory. The datetime boundary is
#      saved in a DynamoDB table. In the case of a full extract, we filter the data up to the the datetime
#      when the full extract starts.
#   2. A delta extract is done by filtering the OData query such that only records are returned that have been
#      changed since the last time we performed a query. Once the delta extract is done, we write the datetime
#      stamp to a DynamoDB and use it in the next delta extract.

import argparse
import json
import re
from collections import defaultdict
from datetime import datetime
from time import sleep
from typing import Any, Dict, List, Tuple

import boto3
import requests
from botocore.exceptions import ClientError
from utils import parse_s3_uri, recursive_s3_delete


def get_all_s3_objects(s3, **base_kwargs):
    """
    Retrieve a list of all objects in an S3 bucket, handling pagination automatically.

    Args:
        s3 (boto3.client): An initialized boto3 S3 client object.
        **base_kwargs (Any): Additional keyword arguments to passed to the list_objects_v2 method.

    Returns:
        List[Dict[str, Any]]: A list of dictionaries representing the retrieved S3 objects.

    Raises:
        Exception: If any error occurs during the retrieval process.
    """
    objects = []
    continuation_token = None
    while True:
        list_kwargs = dict(MaxKeys=1000, **base_kwargs)
        if continuation_token:
            list_kwargs["ContinuationToken"] = continuation_token
        response = s3.list_objects_v2(**list_kwargs)
        if response.get("Contents", []):
            objects.extend(response["Contents"])
        # yield from response.get('Contents', [])
        if not response.get("IsTruncated"):  # At the end of the list?
            break
        continuation_token = response.get("NextContinuationToken")
    return objects


def camel_to_snake(s: str) -> str:
    """
    Converts CamelCase to snake_case.

    Args:
        s: string to convert

    Returns: new string in snake_case

    """
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    s = re.sub(r"([a-z\d])([A-Z])", r"\1_\2", s)
    s = s.replace("-", "_").replace(" ", "_")
    s = s.lower()
    s = re.sub(r"_([a-z])_", r"\1_", s)
    s = "".join(c for c in s if c.isalpha() or c.isnumeric() or c == "_")
    if s[0] == "_":
        s = s[1:]
    if s[-1] == "_":
        s = s[:-1]

    return s


def retrieve_odata(url, auth, language="en"):
    """
    Retrieves a single response from an OData endpoint.

    Args:
        url (str): OData Endpoint URL
        auth (dict): 2-tuple of (username, password)
        language (str): default en

    Returns: Dictionary containing the OData response

    """
    headers = {"Accept-Language": language}
    result = requests.get(url, auth=auth, headers=headers)  # noqa: S113
    if result.status_code != 200:  # noqa: PLR2004
        raise ValueError(f"Status code {result.status_code} returned. Message was: {result.text}")

    try:
        result_json = result.json()
    except json.JSONDecodeError:
        raise ValueError(f"Response is invalid JSON: {result.text}")

    try:
        result_json["d"]["results"]
    except KeyError:
        raise ValueError(f"Response does not contain ['d']['results']: {result.text}")

    return result_json


def retrieve_odata_count(url, auth):
    """
    Retrieves the expected count from an OData Endpoint.

    Args:
        url: OData Endpoint URL
        auth: 2-tuple of (username, password)

    Returns: the expected count

    """
    result = requests.get(url + "/$count", auth=auth)  # noqa: S113

    if result.status_code != 200:  # noqa: PLR2004
        raise ValueError(f"Status code {result.status_code} returned. Message was: {result.text}")

    return int(result.text)


def extract_odata_delta(batch_generator, destination, partition_func=None):
    """
    Extracts a delta from an OData endpoint and writes it to destination.

    Args:
        batch_generator: generator instance that yields individual batches
        destination: S3 location to write results to
        partition_func: A function to partition the delta data

    Returns: Number of records written

    """
    partitioned_records = defaultdict(list)
    records_received = 0

    for batch in batch_generator:
        for record in batch:
            partitions = partition_func(record)
            partitioned_records[partitions].append(record)

    for partition, records in partitioned_records.items():
        final_destination = f"{destination}"
        for key, value in partition:
            final_destination += f"/{key}={value}"

        final_destination += "/data.jsonl"
        bucket, key = parse_s3_uri(final_destination)

        try:
            new_records = (
                boto3.client("s3")
                .get_object(Bucket=bucket, Key=key)["Body"]
                .read()
                .decode("utf-8")
                .split("\n")
            )
            print(f"Found {len(new_records)} existing records - appending while deduplicating.")
            records_received += len(new_records)
        except ClientError as ex:
            if ex.response["Error"]["Code"] != "NoSuchKey":
                raise
            new_records = []
            print("Found no existing records - creating.")

        new_records.extend(json.dumps(record) for record in records)

        # Deduplicate while preserving order
        new_records = list(dict.fromkeys(new_records))

        print(f"Writing a total of {len(new_records)} records to s3://{bucket}/{key}.")

        boto3.client("s3").put_object(
            Body="\n".join(record for record in new_records).encode("utf-8"), Bucket=bucket, Key=key
        )

    return records_received


def extract_odata_full(batch_generator, destination, cleanup=True):
    """
    Extracts the full data set from an OData endpoint and writes it to `destination`.

    Args:
        batch_generator: generator instance that yields individual batches
        destination: S3 location to write results to
        cleanup: Clean up (delete) parts that were downloaded by a previous run of job

    Returns: Number of records written

    """
    bucket, key_prefix = parse_s3_uri(destination)
    keys_written = set()

    records_received = 0

    for i, batch in enumerate(batch_generator):
        records_received += len(batch)
        zfilled_i = str(i).zfill(10)
        key = key_prefix + f"/part_{zfilled_i}.jsonl"

        print(f"Storing to s3://{bucket}/{key}")

        s3.put_object(
            Body="\n".join(json.dumps(record) for record in batch).encode("utf-8"),
            Bucket=bucket,
            Key=key,
        )
        keys_written.add(key)
        if cleanup:
            print("")
    #     try:
    #         existing_objects = get_all_s3_objects(s3=s3, Bucket=bucket, Prefix=f"{key_prefix}/")
    #     except KeyError:
    #         existing_objects = []

    #     for existing_object in existing_objects:
    #         existing_key = existing_object["Key"]
    #         if existing_key not in keys_written:
    #             print(f"WARNING: s3://{bucket}/{existing_key} exists, but was not written by job; deleting.")
    #             s3.delete_object(Bucket=bucket, Key=existing_key)

    return records_received


def retrieve_odata_generator(url, auth, max_errors=4):
    """
    Iteratively retrieves OData responses by following the `__next` link in each response.

    Args:
        url: OData Endpoint URL
        auth: 2-tuple of (username, password)
        max_errors: maximum number of failed retries

    Returns: Python generator for each OData chunk

    """
    next_url = url
    i = 0
    errors = 0
    records_received = 0
    total_bytes = 0
    start_time = datetime.now()
    previous_time = datetime.now()

    while True:
        now = datetime.now()

        print(
            f"\n---- iteration {i}, trial {errors}, total {total_bytes / 1e6} MB, "
            f"step {(now - previous_time).seconds} seconds, elapsed {now - start_time} ----"
        )
        previous_time = now

        print(f"Retrieving {next_url}")
        try:
            res = retrieve_odata(next_url, auth=auth)
            errors = 0
        except ValueError:
            if errors >= max_errors:
                raise
            errors += 1
            sleep(4)
            continue

        this_bytes = len(json.dumps(res["d"]["results"]).encode("utf-8"))
        total_bytes += this_bytes
        records_received += len(res["d"]["results"])

        if records_received > 0:
            print(f"Retrieved {len(res['d']['results'])} records with {this_bytes / 1e6} MB.")
            yield res["d"]["results"]

        else:
            print("No records received.")

        try:
            next_url = res["d"]["__next"]
            i += 1
        except KeyError:
            break

    if records_received > 0:
        print("")
        print(
            f"Done. Retrieved a total number of {records_received} records in {i + 1} partitions "
            f"with a total size of {total_bytes / 1e6} MB."
        )


s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")

parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--source", dest="source", help="Source URI of OData endpoint")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
parser.add_argument(
    "--changed-column", dest="changed_column", help="Column containing the `changed on` timestamp"
)
parser.add_argument(
    "--discard-history-on-full-extract",
    dest="discard",
    action="store_true",
    help="Deletes all delta extracts when doing another full extract",
)
parser.add_argument(
    "--force-full-extract", dest="force", help="Force full extract", action="store_true"
)
args = parser.parse_known_args()[0]

secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="sap-c4c-odata")["SecretString"]
)
auth = (secret["username"], secret["password"])

# Used for for delta updates via DynamoDB table
# timestamp = datetime.utcnow().isoformat().split(".")[0] + "Z"
timestamp = datetime.utcnow().isoformat().split(".")[0]

last = table.get_item(Key={"job_name": args.job_name}).get("Item", None)

if last and not args.force:
    last_import = last.get("last_import", None)
    last_full_import = last.get("last_full_import", None)
else:
    last_import = timestamp
    last_full_import = timestamp

print(f"Last import: {last_import}, last full import: {last_full_import}.")

records_received = 0


def partition_func(record: Dict[str, Any]) -> List[Tuple[str, Any]]:
    """
    Partition function to extract year, month, and day from record.

    Args:
        record (Dict[str, Any]): A dictionary representing a record.

    Returns:
        List[Tuple[str, Any]]: List of tuples containing partition keys and values.
    """
    changed = datetime.utcfromtimestamp(int(record[args.changed_column][6:-2]) / 1000)
    partitions = (
        ("x_etl_changed_year", changed.year),
        ("x_etl_changed_month", changed.month),
        ("x_etl_changed_day", changed.day),
    )
    return partitions


if last and not args.force:
    print("Performing Delta Extract")
    url = (
        args.source
        + f"/?$format=json&$filter=BusinessObject eq 'Opportunity' and ({args.changed_column} ge \
        datetime'{last_import}' or {args.changed_column} eq datetime'{last_import}')"
    )
    batches = retrieve_odata_generator(url=url, auth=auth)
    destination = f"{args.destination}/delta"

    records_received = extract_odata_delta(
        batch_generator=batches, destination=destination, partition_func=partition_func
    )

else:
    print("Performing Full Extract")
    url = args.source + "/?$format=json&$filter=BusinessObject eq 'Opportunity'"

    batches = retrieve_odata_generator(url=url, auth=auth)
    destination = f"{args.destination}/full"

    records_received = extract_odata_full(batch_generator=batches, destination=destination)

    if args.discard:
        bucket, prefix = parse_s3_uri(args.destination)
        recursive_s3_delete(bucket, prefix + "/delta")


table.put_item(
    Item={
        "last_import": timestamp,
        "last_full_import": last_full_import,
        "job_name": args.job_name,
        "records_received": records_received,
    }
)
