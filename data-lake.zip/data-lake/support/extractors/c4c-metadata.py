"""Retrieves C4C metadata and writes it to S3."""

import argparse
import json
from urllib.parse import urlparse

import boto3
import requests

parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--source", dest="source", help="Source URI of OData endpoint")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
args = parser.parse_known_args()[0]

s3 = boto3.client("s3")
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="sap-c4c-odata")["SecretString"]
)
res = requests.get(  # noqa: S113
    args.source + "/?$metadata&sap-label=true", auth=(secret["username"], secret["password"])
)

s3.put_object(
    Body=res.text,
    Bucket=urlparse(args.destination).netloc,
    Key=urlparse(args.destination).path[1:] + "/metadata.xml",
)
