"""Exctracting full load for customer order collection."""
import argparse
import json
import boto3
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
 
# Setup boto3 S3 client
s3 = boto3.client("s3")
 
# Function to extract data from a given URL and write to S3
def fetch_data_and_write(url, auth, session, bucket, base_key, batch_num):
    try:
        print(f"Fetching the data for url {url}")
        response = session.get(url, auth=auth)
        response.raise_for_status()
        data = response.json()["d"]["results"]  # Adjust to your response structure
        # Write each batch directly to S3 in a separate file
        file_key = f"{base_key}/data_part_{batch_num}.json"
        newline_separated_data = "\n".join([json.dumps(record) for record in data])
        s3.put_object(
            Bucket=bucket,
            Key=file_key,
            Body=newline_separated_data
        )
        print(f"written file into s3 {file_key}")
        return file_key
    except Exception as e:
        print(f"Error fetching {url}: {e}")
        return None
 
# Parallel fetching and writing
def fetch_and_write_parallel(base_url, auth, session, total_count, destination, batch_size=1000):
    bucket = destination.split("/")[2]
    base_key = "/".join(destination.split("/")[3:])
    futures = []
    with ThreadPoolExecutor(max_workers=100) as executor:  # Adjust number of threads as necessary
        for skip in range(0, total_count, batch_size):
            url = f"{base_url}&$skiptoken={skip}%20"
            batch_num = skip // batch_size
            futures.append(executor.submit(fetch_data_and_write, url, auth, session, bucket, base_key, batch_num))
 
    # Collecting results and printing success/failure
    for future in as_completed(futures):
        file_key = future.result()
        if file_key:
            print(f"Data written to {file_key}")
 
# Main execution flow
if __name__ == "__main__":
    # Argument parsing
    parser = argparse.ArgumentParser(description="Ingest data from OData API")
    parser.add_argument("--source", dest="source", help="Source URI of OData endpoint")
    parser.add_argument("--destination", dest="destination", help="Destination path in S3")
    parser.add_argument(
        "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
    )
    args = parser.parse_known_args()[0]
    # Boto3 and Requests session setup
    session = requests.Session()
    secret = json.loads(
        boto3.client("secretsmanager").get_secret_value(SecretId="sap-c4c-odata")["SecretString"]
    )
    auth = (secret["username"], secret["password"])
 
    # Fetch the total count for data partitioning
    count_url = f"{args.source}/$count"
    total_count_response = session.get(count_url, auth=auth)
    total_count_response.raise_for_status()
    total_count = int(total_count_response.text)
    print(f"Total records to process: {total_count}")
 
    # Start parallel fetch and write
    base_url = args.source + "?$format=json"
    fetch_and_write_parallel(base_url, auth, session, total_count, args.destination)
    print("Extraction process is done")