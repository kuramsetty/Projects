"""Glue job-runs paramters."""

import argparse
import time
from io import StringIO
from urllib.parse import urlparse

import boto3
import botocore.exceptions
import pandas as pd

glue = boto3.client("glue")
logs = boto3.client("logs")
s3 = boto3.client("s3")


def get_jobs():
    """
    Method to fetch glue jobs.

    Returns:
        jobs : List of glue jobs
    """
    next_token = ""
    jobs = []

    while True:
        res = glue.list_jobs(NextToken=next_token)
        for job in res["JobNames"]:
            jobs.append(job)

        try:
            next_token = res["NextToken"]
        except KeyError:
            break

    return jobs


# Define maximum number of retries and initial delay
MAX_RETRIES = 5
INITIAL_DELAY = 1


# Define function to handle throttling exceptions with exponential backoff
def handle_throttling_exception(func):
    """
    Defined function to handle throttling exception.

    Args:
        func (_type_): function/method as input
    """

    def wrapper(*args, **kwargs):
        retries = 0
        delay = INITIAL_DELAY
        while retries < MAX_RETRIES:
            try:
                return func(*args, **kwargs)
            except botocore.exceptions.ClientError as e:
                if e.response["Error"]["Code"] == "ThrottlingException":
                    print(f"Throttling exception encountered. Retrying in {delay} seconds...")
                    time.sleep(delay)
                    retries += 1
                    delay *= 2  # Exponential backoff
                else:
                    raise
        raise Exception("Maximum number of retries exceeded.")

    return wrapper


# Decorate the get_triggers function with the throttling exception handler
@handle_throttling_exception
def get_triggers(job_name: str):
    """
    Method to get list triggers associated with the job.

    Args:
        job_name (str): job name

    """
    return glue.get_triggers(DependentJobName=job_name)["Triggers"]


parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
args = parser.parse_known_args()[0]


jobs = [job for job in get_jobs()]


final_list = []
for job in jobs:

    runs = glue.get_job_runs(JobName=job)["JobRuns"]

    if runs == 0:
        continue
    try:
        # trigger = glue.get_triggers(DependentJobName=job)["Triggers"]
        triggerres = get_triggers(job)
    except NameError:
        print("trigger error")

    try:

        for run in runs:
            run_dict = {}
            run_dict["Id"] = run["Id"]
            run_dict["JobName"] = run["JobName"]
            run_dict["StartedOn"] = run["StartedOn"]
            if run["JobRunState"] == "RUNNING":
                run_dict["CompletedOn"] = ""
            else:
                run_dict["CompletedOn"] = run["CompletedOn"]
            run_dict["JobRunState"] = run["JobRunState"]
            try:
                for trigger in triggerres:
                    if trigger["State"] == "ACTIVATED" and trigger["Type"] == "SCHEDULED":
                        run_dict["Schedule"] = trigger["Schedule"]
                    # run_dict["Schedule"] = trigger["Schedule"]
            except NameError:
                run_dict["Schedule"] = ""

            final_list.append(run_dict)

    except IndexError:

        print("error run----", runs)
        print("job---", job)

df = pd.DataFrame(final_list)

csv_buf = StringIO()
df.to_csv(csv_buf, encoding="utf-8", index=False, columns=df.columns, sep=",")

csv_buf.seek(0)
s3 = boto3.client("s3")

filepath = urlparse(args.destination).path[1:] + "/jobs_run_details.csv"
s3.put_object(Body=csv_buf.getvalue(), Bucket=urlparse(args.destination).netloc, Key=filepath)
