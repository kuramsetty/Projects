import requests
import json
import csv
import pandas as pd
from io import StringIO
import argparse
import json
import requests
from urllib.parse import urlparse
import boto3
import re as re
from datetime import datetime

parser = argparse.ArgumentParser(description='Ingest data from OData API')
parser.add_argument('--destination', dest='destination', help="Destination path in S3")
parser.add_argument('--job-name', dest='job_name', help="Name of this job (used for DynamoDB metadata)")
args = parser.parse_known_args()[0]

s3 = boto3.client("s3")
secret = json.loads(boto3.client("secretsmanager").get_secret_value(SecretId="QualtricsCred")["SecretString"])
auth = (secret['ClientID'], secret['Password'])


url = 'https://fra1.qualtrics.com/oauth2/token'
myobj = {'grant_type': 'client_credentials','scope': 'manage:all'}

x = requests.post(url, data = myobj, 
headers = {"Content-Type": "application/x-www-form-urlencoded"}, 
auth=auth)
token=json.loads(x.text)['access_token']

r = requests.get('https://fra1.qualtrics.com/API/v3/surveys', headers = {'Content-Type' : 'application/json', 'Authorization': 'Bearer ' + token})
    
r_response=json.loads(r.text)
print("1-------->", r_response)
survey_id_list= [ ele['id'] for ele in r_response['result']['elements']]

export_id_list = []
for survey_id in survey_id_list:
    z= requests.post('https://fra1.qualtrics.com/API/v3/surveys/'+survey_id+'/export-responses', data = '{"format": "json", "compress":false}', headers = {'Content-Type' : 'application/json', 'Authorization': 'Bearer ' + token})
    temp = json.loads(z.text)
    export_id=temp['result']['progressId']
    export_id_list.append(export_id)

file_id_list = []

percentComplete_result = {}
percentComplete_result_status = {}

for survey_id,export_id in zip(survey_id_list,export_id_list):
    t= requests.get("https://fra1.qualtrics.com/API/v3/surveys/"+survey_id+"/export-responses/"+export_id+'', headers = {'Content-Type' : 'application/json', 'Authorization': 'Bearer ' + token})
    temp = json.loads(t.text)
    percentComplete_result[survey_id] = temp['result']['percentComplete']
    percentComplete_result_status[survey_id] = temp['result']['status']
    if temp['result']['percentComplete'] != 100:
        print(file_id, ' is not fully complete.')
    else:
        file_id = temp['result']['fileId']
        file_id_list.append(file_id)

def aws_translate(textString,sourceLanguage,targetLanguage):
    # sourceLanguage = 'en'
    # targetLanguage = 'fr'
    # textString = 'This is the sixth and final post in a series on the TDWG Standards Documentation Specification (SDS).  The five earlier posts explain the history and model of the SDS, and how to retrieve the machine-readable metadata about TDWG standards.'

    translate = boto3.client(service_name='translate', use_ssl=True)
    try:
        result = translate.translate_text(Text=textString, SourceLanguageCode=sourceLanguage, TargetLanguageCode='en')
    except:
        result = translate.translate_text(Text=textString, SourceLanguageCode='auto', TargetLanguageCode='en')
    # print("result.get('TranslatedText')***",result.get('TranslatedText'))
    return result.get('TranslatedText')

def remove_tags(string):
    result = re.sub('<.*?>','',string)
    result = result.replace("&nbsp;", "")
    result = result.replace("\r\n", "")
    result = result.replace("\n", "")

    return result

li2 = []
cnt=1
for survey_id,export_id,file_id in zip(survey_id_list,export_id_list,file_id_list):
    url='https://fra1.qualtrics.com/API/v3/survey-definitions/'+survey_id+'?format=qsf'
    y= requests.get(url, headers = {'Content-Type' : 'application/json', 'Authorization': 'Bearer ' + token})
    y=json.loads(y.text)
    print(f"Survey number {cnt}************************", survey_id)
    result = y['result']['SurveyEntry']
    result1 = y['result']['SurveyElements']
    #print("92************************", result1)
    v= requests.get("https://fra1.qualtrics.com/API/v3/surveys/"+survey_id+"/export-responses/"+file_id+'/file'+'',  headers = {'Content-Type' : 'application/json', 'Authorization': 'Bearer ' + token})
    v.encoding = 'utf-8'
    v= json.loads(v.text)

    p = v['responses']
    li = []
    
    for i in p:
        values= {}
        
        labels = i['labels']
        values['ResponseId'] =i['responseId']
        values['SurveyId'] = survey_id
        
        for iii, key_iii in result.items():
            values[iii] = key_iii
            
        values['FileId'] = file_id
        values['ExportId'] = export_id
        values['PercentComplete']=percentComplete_result[survey_id]
        values['PercentCompleteStatus']=percentComplete_result_status[survey_id]
        values['Status_text'] = labels['status']
        values['Finished_text'] = labels['finished']
        QID_buck=[]
        
        for vk,vv in i['values'].items():
            
            if vk == "userLanguage":
                userLanguage = vv
                
            if 'Date' in str(vk):
                try:
                    vv_date = datetime.strptime(vv,'%Y-%m-%dT%H:%M:%SZ')
                except:
                    pass
                try:
                    vv_date = datetime.strptime(vv,'%Y-%m-%dT%H:%M:%S.%fZ')
                except:
                    pass
                    
                values[vk] = vv_date
                
            elif 'QID' in str(vk):
                if '_TEXT' in str(vk):
                    new_txt=str(vv)
                    new_txt_x = new_txt.replace('\n', ' ')
                    values[vk] = new_txt_x
                    if new_txt_x.strip() == '':
                        values[vk + "_translated"] = ''
                    else:
                        values[vk+'_translated'] = aws_translate(new_txt_x,userLanguage,'EN')
                elif '_' in str(vk):
                    if isinstance(vv, int) == True:
                        new_dict = {}
                        new_dict[vk] = vv
                        QID_buck.append(new_dict)
                    elif isinstance(vv, list) == True:
                        new_dict = {}
                        new_dict[vk] = vv
                        QID_buck.append(new_dict)
                    elif isinstance(vv, str) == True:
                        new_txt=str(vv)
                        new_txt_x = new_txt.replace('\n', ' ')

                        if 'QID' not in str(vk):
                            values[vk] = new_txt_x
                        else:
                            new_dict = {}
                            new_dict[vk] = new_txt_x
                            QID_buck.append(new_dict)

                    else:
                        values[vk] = vv
                else:
                    new_dict = {}
                    new_dict[vk] = vv
                    QID_buck.append(new_dict)
            else:
                values[vk] = remove_tags(str(vv))

        for re1 in result1:
            if "QID" in str(re1['PrimaryAttribute']):
                QIDText = str(re1['PrimaryAttribute'])
                QuestionText = remove_tags(re1['Payload']['QuestionText'])
                QuestionDescription = remove_tags(re1['Payload']['QuestionDescription'])
                values[QIDText+'_QuestionText']= remove_tags(QuestionText)
                values[QIDText+'_QuestionDescription'] = remove_tags(QuestionDescription)
                values[QIDText + '_Answer'] = '-'
                for  key_labels, val_labels in labels.items():
                    if QIDText == key_labels:
                        values[QIDText + '_Answer'] = val_labels
                        break
            else:
                #all string values
                pass

        for i_QID in QID_buck:
            if len(i_QID)>0:
                for i_key,j_val in i_QID.items():
                    QIDText1 = str(i_key)
                    if '_x' in QIDText1:
                        for re12 in result1:
                            a_split = QIDText1.split("_x")
                            val1 = a_split[0]
                            if str(re12['PrimaryAttribute']) == val1:
                                text1=re12['Payload']['QuestionText']
                                #values[QIDText1+'_QuestionText']= remove_tags(text1)
                                answers = re12['Payload']['Answers']
                                recodeValues = re12['Payload']['RecodeValues']
                                li_recodevalues = list(recodeValues.values())
                                new_recode = [(value, key) for key, value in recodeValues.items()]
                                new_recode_ss={}
                                for im,jm in new_recode:
                                    new_recode_ss[im]=jm

                                for m in li_recodevalues:
                                    if str(m) == str(j_val):
                                        valll = new_recode_ss[m]
                                        temp_ans = re12['Payload']['Answers'][valll]['Display']
                                        values[QIDText1 + '_Answer'] = temp_ans
                                        break
#                             else:
#                                 in else part coming fields would be survey blocks and all.. so it is not nessasary.
                                        
                        
                    elif '_' in QIDText1:
                        a_split = QIDText1.split("_")
                        val1 = a_split[0]
                        val2 = a_split[1]
                        for re12 in result1:
                            if str(re12['PrimaryAttribute']) == val1:
                                    choices = re12['Payload']['Choices']
                                    #print("choices **********",choices)
                                    if len(choices)>0 and type(choices) == dict :
                                        for ch_k,ch_v in choices.items():
                                            if ch_k == str(val2):
                                                text1 = ch_v['Display']
                                                #values[QIDText1+'_QuestionText']= remove_tags(text1)
                                                if 'RecodeValues' in re12['Payload']:
                                                    recodeValues = re12['Payload']['RecodeValues']
                                                    li_recodevalues = list(recodeValues.values())
                                                    new_recode = [(value, key) for key, value in recodeValues.items()]
                                                    new_recode_ss={}
                                                    for im,jm in new_recode:
                                                        new_recode_ss[im]=jm

                                                    for m in li_recodevalues:
                                                        if m == str(j_val):
                                                            valll = new_recode_ss[m]
                                                            if 'Answers'in re12['Payload']:
                                                                temp_ans = re12['Payload']['Answers'][valll]['Display']
                                                                values[QIDText1 + '_Answer'] = temp_ans
                                                                break
                                                            elif 'Choices'in re12['Payload']:
                                                                if re12['SurveyID'] == "SV_7WYwKn6Zg2UhOOG":
                                                                    print(f"if QIDText1 : {QIDText1}")
                                                                    temp_ans = str(j_val)
                                                                    #print(f"{QIDText1}_Answer ---> {temp_ans}")
                                                                    values[QIDText1 +'_Answer'] = temp_ans
                                                                    break
                                                                else:
                                                                    print(f"Else QIDText1 : {QIDText1} ")
                                                                    temp_ans = re12['Payload']['Choices'][valll]['Display']
                                                                    #print(f"{QIDText1}_Answer ---> {temp_ans}")
                                                                    values[QIDText1 + '_Answer'] = temp_ans
                                                                    break
                                                            else:
                                                                print("else6")
#                                                         else:
#                                                               it is matching numbers 1-2,1-1,1-3.. so else is not required.

                                                elif 'Answers' in re12['Payload']:
                                                    if str(j_val) in re12['Payload']['Answers']:
                                                        values[QIDText1 + '_Answer'] = re12['Payload']['Answers'][str(j_val)]['Display']
                                                    else:
                                                        print("else3")
                                                else:
                                                    values[QIDText1 + '_Answer'] = str(j_val)
                                            else:
                                                pass
                                    else:
                                        print("else5")
                    else:
                        pass
#                         else already done
            else:
                print("else10",i_QID)
        li.append(values)
    li2.append(li)
    cnt = cnt + 1

cols = []
for aa_col in li2:
    cols1 = []
    for i_aa_col in aa_col:
        keys = i_aa_col.keys()
        col_i = list(keys)
        for ij in col_i:
            if ij not in cols1:
                cols1.append(ij)
    cols.append(cols1)

final_keys = []
itr = 0
for i in li2:
    val = list(i)
    if len(val) > 0:
        df =pd.DataFrame(val,columns = cols[itr])
        csv_buf = StringIO()
        df.to_csv(csv_buf,encoding="utf-8", index=False,columns = df.columns,sep ='\t')
        csv_buf.seek(0)
        s3 = boto3.client('s3')
        filepath = urlparse(args.destination).path[1:] + '/qualtics_'+str(survey_id_list[itr])+'.csv'

        s3.put_object(
        Body=csv_buf.getvalue(),
        Bucket=urlparse(args.destination).netloc,
        Key=filepath
        )
    itr = itr +1
