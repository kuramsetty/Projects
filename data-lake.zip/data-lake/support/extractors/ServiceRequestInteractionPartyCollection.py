"""Does a CDC extract (incremental) from OData endpoint. Results are written to S3 in JSON format."""


import argparse
import json
from collections import defaultdict
from datetime import datetime
from time import sleep
from typing import Any, Dict, List, Tuple
import concurrent.futures
import boto3
import requests
from utils import parse_s3_uri,retrieve_odata_generator

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")
session = requests.Session()

def fetch_data(object_id, auth, headers):
    """
    Fetches data from a child collection of a specified object in the OData API.

    Args:
        object_id (str): The ID of the parent object.
        auth (Tuple[str, str]): A tuple containing the username and password for authentication.
        headers (Dict[str, str]): A dictionary containing HTTP headers.

    Returns:
        List[dict]: A list of dictionaries containing the fetched data.
    """
    url = f"{args.source}('{object_id}')/ServiceRequestInteractionParty"+"/?$format=json"
    print("URL:", url)
    result = requests.get(url, auth=auth, headers=headers)
    data = result.json()
    return data.get('d', {}).get('results', [])

def retrieve_odata_generator1(url, auth, max_errors=4):
    """
    Iteratively retrieves OData responses by following the `__next` link in each response.

    Args:
        url: OData Endpoint URL
        auth: 2-tuple of (username, password)
        max_errors: maximum number of failed retries
    Returns: Python generator for each OData chunk
    """
    next_url = url
    i = 0
    errors = 0
    records_received = 0
    total_bytes = 0
    while True:
        #         print(f"Retrieving {url}")
        try:
            res, res123 = retrieve_odata1(next_url, auth=auth)
            errors = 0
        except ValueError:
            if errors >= max_errors:
                raise
            errors += 1
            sleep(4)
            continue

        #         this_bytes = len(json.dumps(res).encode("utf-8"))
        this_bytes = len(res)
        total_bytes += this_bytes
        records_received += len(res)
        print("********")
        if records_received > 0:
            print(f"Retrieved {len(res)} records with {this_bytes / 1e6} MB.")
            yield res123

        else:
            print("No records received.")

        try:
            next_url = res["d"]["__next"]
            i += 1
        except KeyError:
            break


def retrieve_odata1(url, auth, language="en"):
    """
    Retrieves a single response from an OData endpoint.

    Args:
        url (str): OData Endpoint URL
        auth (dict): 2-tuple of (username, password)
        language (str): default en

    Returns: Dictionary containing the OData response
    """
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Accept-Language": "en-US",
    }
    result = requests.get(url=url, auth=auth, headers=headers)  # noqa: S113

    if result.status_code != 200:  # noqa: PLR2004
        raise ValueError(f"Status code {result.status_code} returned. Message was: {result.text}")

    try:

        result1 = result.json()
        result1 = result1["d"]["results"]
        result_json123 = []

        object_ids = [i['ObjectID'] for i in result1]
        
        with concurrent.futures.ThreadPoolExecutor() as executor:
            # Submit tasks to fetch data for each ObjectID
            future_to_object_id = {executor.submit(fetch_data, object_id, auth, headers): object_id for object_id in object_ids}
    
            # Collect results
            for future in concurrent.futures.as_completed(future_to_object_id):
                object_id = future_to_object_id[future]
                try:
                    data = future.result()
                    if data:
                        result_json123.append(data[0])  # Assuming you want to append the first result
                        print(f"Data for {object_id} added to result_json123 -->{len(result_json123)}")
                    else:
                        result_json123.append({})  # Append empty dictionary if no data found
                except Exception as e:
                    print(f"Error fetching data for {object_id}: {e}")
        
        result_json = result.json()
    except json.JSONDecodeError:
        raise ValueError(f"Response is invalid JSON: {result.text}")

    try:
        result_json
    except KeyError:
        raise ValueError(f"Response does not contain ['d']['results']: {result.text}")

    return result_json, result_json123

def extract_odata_delta(batch_generator, batch_generator_parent, destination, partition_func=None):
    """
    Extracts data from batch generator, partitions it based on provided function, and writes to S3.

    Args:
        batch_generator (List[dict]): A list of dictionaries containing batches of data.
        batch_generator_parent (List[dict]): Generator yielding sub-batches of records.
        destination (str): The S3 destination path where data will be written.
        partition_func (callable): A function to partition records. Defaults to None.

    Returns:
        int: The total number of records received.
    """
    partitioned_records = defaultdict(list)
    records_received = 0
    partitions_list = []

    for batch in batch_generator_parent:
        batch_partitions_list = []
        for record in batch:
            partitions = partition_func(record)
            batch_partitions_list.append(partitions)

        partitions_list.append(batch_partitions_list)

    bgs1 = 0
    for batch1 in batch_generator:
        bg = 0
        for record1 in batch1:
            try:
                if partitions_list[bgs1][bg]:
                    partitions = partitions_list[bgs1][bg]
                    partitioned_records[partitions].append(record1)
            except:
                print("except")
            bg = bg + 1
        bgs1 = bgs1 + 1

    for partition, records in partitioned_records.items():
        final_destination = f"{destination}"
        for key, value in partition:
            final_destination += f"/{key}={value}"

        final_destination += "/data.jsonl"
        bucket, key = parse_s3_uri(final_destination)
        print("bucket, key", bucket, key)
        try:
            new_records = (
                boto3.client("s3")
                .get_object(Bucket=bucket, Key=key)["Body"]
                .read()
                .decode("utf-8")
                .split("\n")
            )
            print(f"Found {len(new_records)} existing records - appending while deduplicating.")
            records_received += len(new_records)
        except:
            # if ex.response['Error']['Code'] != 'NoSuchKey':
            #     raise
            new_records = []
            print("Found no existing records - creating.")
        new_records = []
        new_records.extend(json.dumps(record) for record in records)

        # Deduplicate while preserving order
        new_records = list(dict.fromkeys(new_records))

        print(f"Writing a total of {len(new_records)} records to s3://{bucket}/{key}.")

        boto3.client("s3").put_object(
            Body="\n".join(record for record in new_records).encode("utf-8"), Bucket=bucket, Key=key
        )

    return records_received


parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--source", dest="source", help="Source URI of OData endpoint")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
parser.add_argument(
    "--changed-column", dest="changed_column", help="Column containing the `changed on` timestamp"
)
args = parser.parse_known_args()[0]

secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="sap-c4c-odata")["SecretString"]
)
auth = (secret["username"], secret["password"])

# Used for for delta updates via DynamoDB table
timestamp = datetime.utcnow().isoformat().split(".")[0] + "Z"

last = table.get_item(Key={"job_name": args.job_name}).get("Item", None)

if last:
    last_import = last.get("last_import", None)
    last_full_import = last.get("last_full_import", None)
else:
    last_import = timestamp
    last_full_import = timestamp

print(f"Last import: {last_import}, last full import: {last_full_import}.")

records_received = 0

def partition_func(record: Dict[str, Any]) -> List[Tuple[str, Any]]:
    """
    Partition function to extract year, month, and day from record.

    Args:
        record (Dict[str, Any]): A dictionary representing a record.

    Returns:
        List[Tuple[str, Any]]: List of tuples containing partition keys and values.
    """
    changed = datetime.utcfromtimestamp(int(record[args.changed_column][6:-2]) / 1000)
    partitions = (
        ("x_etl_changed_year", changed.year),
        ("x_etl_changed_month", changed.month),
        ("x_etl_changed_day", changed.day),
    )
    return partitions


if last:
    print("Performing Delta Extract")
    url = f"{args.source}/?$format=json&$filter={args.changed_column} ge datetimeoffset'{last_import}' or {args.changed_column} eq datetimeoffset'{last_import}'"

    print("url",url)
    batches = retrieve_odata_generator1(url=url, auth=auth)
    batches_parent = retrieve_odata_generator(url, auth, session)
    destination = f"{args.destination}/delta"

    records_received = extract_odata_delta(
        batch_generator=batches,
        batch_generator_parent=batches_parent,
        destination=destination,
        partition_func=partition_func
    )


table.put_item(
    Item={
        'last_import': timestamp,
        'last_full_import': last_full_import,
        'job_name': args.job_name,
        # 'records_received': records_received,
    }
)