#!/usr/bin/env python
"""Transform for the qualtrics load."""
import argparse
import re

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from utils import parse_s3_uri

s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Qualtrics servey data")
parser.add_argument("--source", dest="source", help="extracted data")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]


glueContext = GlueContext(SparkContext.getOrCreate())
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

bucket_full, prefix_full = parse_s3_uri(args.source)
objects_full = s3.list_objects_v2(Bucket=bucket_full, Prefix=prefix_full).get("Contents", None)
# objects_full = s3.list_objects_v2(Bucket=bucket_full, Prefix='qualtrics/raw').get("Contents", None)

paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]


def camel_to_snake(s):
    """
    Converts CamelCase to snake_case.

    Args:
        s: string to convert

    Returns: new string in snake_case

    """
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    s = re.sub(r"([a-z\d])([A-Z])", r"\1_\2", s)
    s = s.replace("-", "_").replace(" ", "_").replace(".", "_")

    s = s.lower()
    s = re.sub(r"_([a-z])_", r"\1_", s)
    s = "".join(c for c in s if c.isalpha() or c.isnumeric() or c == "_")
    if s[0] == "_":
        s = s[1:]
    if s[-1] == "_":
        s = s[:-1]

    return s


for i in paths_full:
    # df = spark.read.format("csv").option("header", "true").load(i)
    df = spark.read.csv(i, sep="\t", header=True)
    for ii in df.schema.fields:
        if ii.name == "Q21.translated":
            df = df.withColumnRenamed("Q21.translated", "Q21_translated")
    df = df.select(*[F.col(f.name).alias(camel_to_snake(f.name)) for f in df.schema.fields])
    survey_name = df.first().survey_name
    survey_name = camel_to_snake(survey_name)
    n_partitions = int(df.rdd.getNumPartitions() / 4)
    if n_partitions <= 1:
        n_partitions = 1
    df = df.coalesce(n_partitions)
    df.write.mode("overwrite").save(args.destination + "/" + str(survey_name))

job.commit()
