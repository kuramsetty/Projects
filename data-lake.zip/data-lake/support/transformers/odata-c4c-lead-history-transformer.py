#!/usr/bin/env python
"""Transform for the lead history."""
import argparse

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from c4c import get_c4c_metadata, transform_c4c_df
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql import types as T
from utils import get_all_s3_objects, parse_s3_uri, remove_null_columns

s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--metadata-path", dest="metadata_path", help="S3 path to metadata xml")
parser.add_argument("--collection-name", dest="collection_name", help="name of the collection")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

bucket_full, prefix_full = parse_s3_uri(args.source)
objects_full = get_all_s3_objects(s3=s3, Bucket=bucket_full, Prefix=prefix_full)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]


# Read JSON from S3
glue_df = glueContext.create_dynamic_frame.from_options(
    format_options={"jsonPath": "", "multiline": True},
    connection_type="s3",
    format="json",
    connection_options={"paths": paths_full},
)

# Convert to Spark DataFrame
df = glue_df.toDF()
df = df.drop("__metadata")
df = remove_null_columns(df)


def change_timezone(df, col_name):
    """Change the time zone of the column."""
    # Clean and format the column
    df = df.withColumn("Region", F.regexp_replace(F.col(col_name), r"[(\d+),\W]", ""))
    df = df.withColumn(col_name, F.regexp_replace(F.col(col_name), "[A-Z]", ""))
    
    # Trim whitespace and ensure the correct format for parsing
    df = df.withColumn(col_name, F.trim(F.col(col_name)))  # Remove leading/trailing whitespaces
    df = df.withColumn(
        col_name, F.unix_timestamp(col_name, "dd.MM.yyyy HH:mm:ss").cast(T.TimestampType())
    )
    df = df.withColumn(col_name, F.to_utc_timestamp(F.col(col_name), F.col("Region")))
    df = df.drop("Region")
    return df


def change_date_format_for_microseconds(df, data_col):
    """Change the date and time format."""
    df = df.withColumn(
        data_col, F.regexp_replace(data_col, "[/,Date,(,)]", "")
    )  # .show(truncate=False)
    df = df.withColumn(data_col, F.from_unixtime(F.col(data_col) / 1000).cast("date"))
    return df


meta = get_c4c_metadata(args.metadata_path, args.collection_name)
df = transform_c4c_df(df, meta)
date_columns_microseconds = ["cdoch_validity_date_end", "cdoch_validity_date_start"]
for each_seconds_value in date_columns_microseconds:
    df = change_date_format_for_microseconds(df, each_seconds_value)
timezone_cols_names = ["cdoch_validity_date_time_end", "cdoch_validity_date_time_start"]
for each_date_col in timezone_cols_names:
    df = change_timezone(df, each_date_col)
df = df.withColumn(
    "kckf_dhv_validstartdt", F.from_unixtime(F.col("kckf_dhv_validstartdt")).cast("date")
)
df = df.withColumn(
    "kckf_dhv_validenddt", F.from_unixtime(F.col("kckf_dhv_validenddt")).cast("date")
)
df = df.withColumn(
    "fckf_dhv_validstartdt", F.to_date("fckf_dhv_validstartdt", "dd.MM.yyyy").cast(T.DateType())
)
df = df.withColumn(
    "fckf_dhv_validenddt", F.to_date("fckf_dhv_validenddt", "dd.MM.yyyy").cast(T.DateType())
)


# Repartition into smaller partitions for performance
n_partitions = int(df.rdd.getNumPartitions() / 4)
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)

df.write.mode("overwrite").save(args.destination)

job.commit()
