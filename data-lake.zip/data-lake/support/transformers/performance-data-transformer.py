#!/usr/bin/env python
"""Transform for the performance data load."""
import argparse
from collections import Counter

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from c4c import get_c4c_CodRespTimeAna_metadata
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql.types import NullType, StructType
from utils import camel_to_snake, get_all_s3_objects, keep_only_most_recent_per_group, parse_s3_uri

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")
s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--metadata-path", dest="metadata_path", help="S3 path to the metadata XML from C4C"
)
parser.add_argument(
    "--collection-name", dest="collection_name", help="Name of the collection (used for metadata)"
)
parser.add_argument(
    "--discard-history-id", dest="discard_id", help="Discard all history based on ID"
)
parser.add_argument(
    "--discard-history-column",
    dest="discard_col",
    help="Discard all history except the max in the given column",
)
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

# Read JSON from S3
# bucket_full, prefix_full = parse_s3_uri(f"{args.source}/full")
# objects_full = get_all_s3_objects(s3=s3, Bucket=bucket_full, Prefix=prefix_full)
# paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]

# glue_full_df = glueContext.create_dynamic_frame.from_options(
#     format_options={"jsonPath": "", "multiline": True},
#     connection_type="s3",
#     format="json",
#     connection_options={"paths": paths_full})
# full_df = glue_full_df.toDF()
# full_df = full_df.withColumn("x_etl_type", F.lit("full"))

bucket_delta, key = parse_s3_uri(f"{args.source}")
# print("bucket_delta, key",bucket_delta, key)
objects_delta = get_all_s3_objects(s3=s3, Bucket=bucket_delta, Prefix=key)
# print("objects_delta***",objects_delta)
if objects_delta:
    print("Yes I am delta ***")
    paths_delta = [f"s3://{bucket_delta}/{o['Key']}" for o in objects_delta]
    glue_delta_df = glueContext.create_dynamic_frame.from_options(
        format_options={"jsonPath": "", "multiline": True},
        connection_type="s3",
        format="json",
        connection_options={"paths": paths_delta},
    )
    delta_df = glue_delta_df.toDF()
    delta_df = delta_df.withColumn("x_etl_type", F.lit("delta"))
    df = delta_df
    # df = full_df.union(delta_df.select(full_df.columns))
# else:
#     df = full_df

n_partitions = int(df.rdd.getNumPartitions() / 10)
df = df.dropDuplicates()

# Get data types from C4C
count_before = df.count()
meta = get_c4c_CodRespTimeAna_metadata(args.metadata_path, args.collection_name)


def transform_c4c_df1(df, meta):
    """
    Casts a Spark data frame built from C4C data to the types specified in dtypes.

    Args:
        df: a PySpark DataFrame
        meta (dict of dicts): {"dtypes": dictionary mapping from C4C dtype to Spark dtype,
         "names": dictionary of name mappings"}

    Returns: PySpark DataFrame with types casted according to `dtypes`

    """
    cols = []
    dtypes = meta["dtypes"]

    translate_col_name = lambda name: camel_to_snake(meta["names"].get(name, name))  # noqa: E731

    counter = Counter()
    counter.update([translate_col_name(col.name) for col in df.schema.fields])

    for col in df.schema.fields:
        dtype = dtypes.get(col.name, "string")
        col_name2 = translate_col_name(col.name)

        # If two different columns map to the same column name, keep the existing one
        # to avoid duplicate col names
        if counter[col_name2] > 1:
            print(f"Not renaming column {col.name} due to duplicate column names")
            col_name2 = col.name
        else:
            print(f"Renaming column {col.name} -> {col_name2}")

        if dtype == "timestamp":
            cols.append(
                (F.regexp_extract(F.col(col.name), "/Date\((\d+)\)/", 1) / 1000)
                .cast("timestamp")
                .alias(col_name2)
            )
        elif isinstance(col.dataType, StructType):
            # drop __deferred
            pass
        elif isinstance(col.dataType, NullType):
            # Parquet doesn't support NULL columns -- need to cast to double
            cols.append(F.col(col.name).cast("double").alias(col_name2))
        elif dtype == "decimal":
            # Add it as is

            cols.append(F.col(col.name).cast("decimal(10,5)").alias(col_name2))
        else:

            cols.append(F.col(col.name).cast(dtype).alias(col_name2))
        print("df.select(cols)", df.select(cols))
    return df.select(cols)


df = transform_c4c_df1(df, meta)

count_after = df.count()

if count_before != count_after:
    raise ValueError(f"Mismatch in number of records; before: {count_before}, after: {count_after}")

# Keep only the last row per ID (no Change Data Capture)
if args.discard_id and args.discard_col:
    df = keep_only_most_recent_per_group(
        df=df, date_col=camel_to_snake(args.discard_col), group=args.discard_id
    )

    discard_id_df_count = df.select(args.discard_id).distinct().count()
    if discard_id_df_count == 0:
        raise ValueError(f"Distinct count for column {args.discard_id} is zero")
    if discard_id_df_count != df.count():
        raise ValueError(
            f"Mismatch in discarded record count with {discard_id_df_count - df.count()} number."
        )

# Repartition into smaller partitions for performance
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)

df.write.mode("overwrite").save(args.destination)

job.commit()
