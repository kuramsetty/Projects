#!/usr/bin/env python
"""Extract data from Adobe Marketo using the Bulk Extract API."""

import argparse

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from marketo import cast_marketo_bulk_df, get_marketo_bulk_data_types
from pyspark.context import SparkContext
from utils import (
    get_all_s3_objects,
    keep_only_most_recent_per_group,
    parse_s3_uri,
    remove_null_columns,
)

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")
s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--metadata-path", dest="metadata_path", help="S3 path to the metadata JSON from Marketo"
)
parser.add_argument(
    "--keep-last", dest="keep_last", action="store_true", help="Keep only the last change per ID"
)
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

dtypes = get_marketo_bulk_data_types(args.metadata_path)

# Full extract
bucket_full, prefix_full = parse_s3_uri(args.source + "/full")
objects_full = get_all_s3_objects(s3=s3, Bucket=bucket_full, Prefix=prefix_full)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]
print("Reading the following files from the full extract:")
for path_full in paths_full:
    print(path_full)

# Delta extract
bucket_delta, prefix_delta = parse_s3_uri(args.source + "/delta")
objects_delta = get_all_s3_objects(s3=s3, Bucket=bucket_delta, Prefix=prefix_delta)
if objects_delta:
    paths_delta = [f"s3://{bucket_delta}/{o['Key']}" for o in objects_delta]
    print("Reading the following files from the delta extracts:")
    for path_delta in paths_delta:
        print(path_delta)
else:
    paths_delta = []

glue_full_df = glueContext.create_dynamic_frame.from_options(
    format_options={"withHeader": True},
    connection_type="s3",
    format="csv",
    connection_options={"paths": paths_full + paths_delta},
)

full_df = glue_full_df.toDF()

df = cast_marketo_bulk_df(full_df, dtypes)
df = remove_null_columns(df)
df = keep_only_most_recent_per_group(df, "updated_at", "id")

n_partitions = int(df.rdd.getNumPartitions() / 4)
if n_partitions <= 1:
    n_partitions = 1

# We use repartition instead of coalesce because records are not distributed well across time slices
df = df.repartition(n_partitions)
#spark.sql("set spark.sql.parquet.datetimeRebaseModeInWrite=LEGACY")
spark.conf.set("spark.sql.parquet.datetimeRebaseModeInWrite","LEGACY")

df.write.mode("overwrite").save(args.destination)

job.commit()
