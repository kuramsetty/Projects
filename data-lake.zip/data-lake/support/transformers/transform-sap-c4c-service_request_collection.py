#!/usr/bin/env python
"""
Does the transformation for service_request collection to parquet format
"""
import argparse
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import boto3
from pyspark.sql.functions import lit,col,row_number
from pyspark.sql.window import Window

from utils import parse_s3_uri, get_all_s3_objects
from c4c import get_c4c_metadata, transform_c4c_df


dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")
s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description='Transform data from JSON to Parquet')
parser.add_argument('--source', dest='source', help="Source path in S3")
parser.add_argument('--destination', dest='destination', help="Destination path in S3")
parser.add_argument('--metadata-path', dest="metadata_path", help="S3 path to the metadata XML from C4C")
parser.add_argument('--collection-name', dest="collection_name", help="Name of the collection (used for metadata)")
parser.add_argument('--discard-history-id', dest='discard_id', help="Discard all history based on ID")
parser.add_argument('--discard-history-column', dest='discard_col', help="Discard all history except the max in the given column")
parser.add_argument('--JOB_NAME', dest='name', help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

# Read JSON from S3
bucket_full, prefix_full = parse_s3_uri(f"{args.source}")
print(f"bucket_full, prefix_full {bucket_full}, {prefix_full}")
objects_full = get_all_s3_objects(s3=s3, Bucket=bucket_full, Prefix=prefix_full)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]

glue_full_df = glueContext.create_dynamic_frame.from_options(
    format_options={"jsonPath": "", "multiline": True},
    connection_type="s3",
    format="json",
    connection_options={"paths": paths_full})
full_df = glue_full_df.toDF()
full_df = full_df.withColumn("x_etl_type", lit("full"))

df = full_df
#print("count ",df.count())
n_partitions = int(df.rdd.getNumPartitions() / 10)
df = df.dropDuplicates()

# Get data types from C4C
count_before = df.count()
meta = get_c4c_metadata(args.metadata_path, args.collection_name)
df = transform_c4c_df(df, meta)
count_after = df.count()

if count_before != count_after:
    raise ValueError(f"Mismatch in number of records; before: {count_before}, after: {count_after}")

#print("before count ",count_after)
window_spec = Window.partitionBy("id").orderBy(col("entity_last_changed_on").desc())
df_with_row_num = df.withColumn("row_num", row_number().over(window_spec))
df = df_with_row_num.filter(col("row_num") == 1).drop("row_num")
#print(" After count ",df.count())

# Repartition into smaller partitions for performance
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)

print("Writing...to s3")
df.write.mode("overwrite").save(args.destination)
print(f"Data written successfully to s3 {args.destination}")

job.commit()
