"""Transform for the supply chain gsp."""

import argparse
import json
import pandas as pd
import boto3
                   
from utils import camel_to_snake, parse_s3_uri, get_all_s3_objects

s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description='Transform data from JSON to Parquet')
parser.add_argument('--source', dest='source', help="Source path in S3")
parser.add_argument('--destination', dest='destination', help="Destination path in S3")
parser.add_argument('--JOB_NAME', dest='name', help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]


bucket_full, prefix_full = parse_s3_uri(args.source)
objects_full = get_all_s3_objects(s3=s3, Bucket=bucket_full, Prefix=prefix_full)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]


def explode_column_fromdict(data, key="", prefix="", **kwargs):
                             
    sub_data = data.explode(key)
    sub_data = sub_data[key].apply(pd.Series).drop(columns=0).add_prefix(prefix)
    result = pd.concat([data.drop(columns=key), sub_data], axis=1)
    return result


def expand_column_fromdict(data, key="", prefix="", **kwargs):
                        
    sub_data = data
    try:
        sub_data = sub_data[key].apply(pd.Series).drop(columns=0).add_prefix(prefix)
        result = pd.concat([data.drop(columns=key), sub_data], axis=1)
        return result
    except:
        return data


cols_rename = {
        "request_carrier_name": "Carrier name", 
        "containershipments_container_number": "Container no", 
        "containershipments_descriptive_name": "Container description", 
        "containershipments_status_verbose": "container shipment status name" , 
        "containershipments_container_type_iso": "container_type_iso" , 
        "containershipments_container_type_str": "container_type_str" , 
        "pod_loc_name": "pod_loc_name", 
        "dlv_loc_name": "dlv_loc_name", 
        "pol_loc_name": "pol_loc_name", 
        "containershipments_pol_vsldeparture_planned_initial": "pol_vsldeparture_planned_initial",
        "containershipments_pol_vsldeparture_planned_last":"pol_vsldeparture_planned_last", 
        "containershipments_pol_vsldeparture_detected":"pol_vsldeparture_detected", 
        "contractual_eta_pod":"Contractual ETA@POD", 
        "containershipments_pod_discharge_prediction":"pod_discharge_prediction",
        "containershipments_pol_loaded_planned_initial":"containershipments_pol_loaded_planned_initial", 
        "containershipments_pol_loaded_planned_last":"containershipments_pol_loaded_planned_last", 
        'containershipments_pol_loaded_actual':'containershipments_pol_loaded_actual',
        "containershipments_pod_vslarrival_planned_last": "pod_vslarrival_planned_last",
        "Shipment_arrival_prediction_predicted": "pod_vslarrival_predicted_date",
        "containershipments_pod_vslarrival_actual":"pod_vslarrival_actual", 
        "containershipments_pod_vslarrival_detected":"pod_vslarrival_detected", 
        "contractual_eta_dlv": "Contractual ETA@DLV",
        "containershipments_dlv_delivery_planned_last":"dlv_delivery_planned_last", 
        "containershipments_dlv_delivery_actual":"dlv_delivery_actual",
        "current_vessel_name":"current_vessel_name", 
        "current_vessel_nextport_name":"current_vessel_nextport_name", 
        "current_vessel_nextport_eta":"current_vessel_nextport_eta", 
        "current_vessel_position_latitude":"current_vessel_position_latitude", 
        "current_vessel_position_longitude": "current_vessel_position_longitude",
        "current_vessel_position_heading":"current_vessel_position_heading", 
        "descriptive_name":"Subscription description",
        "last_carrier_update":"Last carrier update", 
        "request_key": "Subscription ref no",
        "containershipments_empty_return_actual": "empty_return_actual",  
        "containershipments_pod_discharge_actual": "pod_discharge_actual",
        "containershipments_pod_departure_actual": "pod_departure_actual",
    }

df = [pd.read_json(f, lines=True) for f in paths_full]
data = pd.concat(df, ignore_index=True)
data = explode_column_fromdict(data, key="containershipments",prefix="containershipments_")
                              
data = expand_column_fromdict(data, key="containershipments_current_vessel_position", prefix="current_vessel_position_")
 
                              
data = expand_column_fromdict(data, key="containershipments_current_vessel", prefix="current_vessel_")
 
                              
data = expand_column_fromdict(data, key="containershipments_current_vessel_nextport", prefix="current_vessel_nextport_")
 
                              
data = expand_column_fromdict(data, key="containershipments_pod_vslarrival_prediction", prefix="Shipment_arrival_prediction_")
 
data = expand_column_fromdict(data, key="containershipments_pod_loc", prefix="pod_loc_")
data = expand_column_fromdict(data, key="containershipments_pol_loc", prefix="pol_loc_")
data = expand_column_fromdict(data, key="containershipments_dlv_loc", prefix="dlv_loc_")
                              
data = expand_column_fromdict(data, key="containershipments_pod_timeofarrival_warning", prefix="pod_timeofarrival_warning")
 
                              
         
data = expand_column_fromdict(data, key="pod_timeofarrival_warning_predicted_time_of_arrival", prefix="predicted_time_of_arrival")
                                       
 

# gsp = data[cols_rename.keys()]
GSP = data.rename(columns=cols_rename)
print("GSP df created")
GSP["DO number"] = GSP["Container description"].str.split(",").str[0]
GSP["SU number"] = GSP["Container description"].str.split(",").str[1]
GSP["Last carrier update"] = pd.to_datetime(GSP["Last carrier update"])

GSP_set = GSP
                     
GSP_set_DO = GSP_set[GSP_set.groupby("DO number")["Last carrier update"].transform(max)==GSP_set["Last carrier update"]]
                                     
 
GSP_set_DO = GSP_set_DO.drop_duplicates(subset="DO number")
print("GSP_set_DO df drop duplicates")
                     
GSP_set_BL = GSP_set[GSP_set.groupby("Subscription ref no")["Last carrier update"].transform(max)==GSP_set["Last carrier update"]]
                                     
 
GSP_set_BL = GSP_set_BL.drop_duplicates(subset="Subscription ref no")
print("GSP_set_BL df drop duplicates")
key = ["DO number", "SU number", "Container no"]
                           
GSP_set_jointkey = GSP_set[GSP_set.groupby(key)["Last carrier update"].transform(max)==GSP_set["Last carrier update"]]
 
GSP_set_jointkey = GSP_set_jointkey.drop_duplicates(subset=key)

                      
GSP_columns_rename = { "pod_loc_name": "POD",
                      "dlv_loc_name": "DLV",
                      "pol_loc_name": "POL",
                      "pol_vsldeparture_planned_initial" : "Planned ETD@POL",
                      "pol_vsldeparture_planned_last" : "ETD@POL",
                      "pol_vsldeparture_detected" : "Detected ATD@POL",
                      "pod_vslarrival_planned_last" : "ETA@POD",
                      "pod_vslarrival_predicted_date" : "Predicted ETA@POD",
                      "pod_vslarrival_actual": "ATA@POD",
                      "pod_vslarrival_detected" : "Detected ATA@POD",
                      "dlv_delivery_planned_last": "Planned ETA@DLV",
                      "dlv_delivery_actual": "ATA@DLV",
                      "current_vessel_name": "Vessel name",
                      "current_vessel_nextport_name" :"Next port",
                      "current_vessel_nextport_eta": "Next port ETA",
                      "current_vessel_position_latitude": "Vessel lat",
                      "current_vessel_position_longitude" :"Vessel long",
                      "current_vessel_position_heading" :"Vessel heading",
                      "Subscription ref no" : "BL number"
              }


bucket_dest, prefix_dest = parse_s3_uri(args.destination)

GSP_set_DO.rename(columns=GSP_columns_rename, inplace=True)
GSP_set_DO = GSP_set_DO.add_prefix("gsp_")
GSP_set_DO.columns = GSP_set_DO.columns.str.replace(' ','_')
GSP_set_DO.columns = GSP_set_DO.columns.str.lower()
print("GSP_set_DO df columns renamed")
for each_col in GSP_set_DO.columns:
    if GSP_set_DO.dtypes[each_col] == 'O':
        GSP_set_DO[each_col] = GSP_set_DO[each_col].astype(str)
GSP_set_DO.to_parquet(f"{args.destination}/gsp_set_do/gsp_set_do.parquet", index=False)
print("GSP_set_DO to parquet written successfully")

GSP_set_BL.rename(columns=GSP_columns_rename, inplace=True)
GSP_set_BL = GSP_set_BL.add_prefix("gsp_")
GSP_set_BL.columns = GSP_set_BL.columns.str.replace(' ','_')
GSP_set_BL.columns = GSP_set_BL.columns.str.lower()
print("GSP_set_BL df columns renamed")
for each_col in GSP_set_BL.columns:
    if GSP_set_BL.dtypes[each_col] == 'O':
        GSP_set_BL[each_col] = GSP_set_BL[each_col].astype(str)
GSP_set_BL.to_parquet(f"{args.destination}/gsp_set_bl/gsp_set_bl.parquet", index=False)
print("GSP_set_BL to parquet written successfully")

GSP_set_jointkey.rename(columns=GSP_columns_rename, inplace=True)
GSP_set_jointkey = GSP_set_jointkey.add_prefix("gsp_")
GSP_set_jointkey.columns = GSP_set_jointkey.columns.str.replace(' ','_')
GSP_set_jointkey.columns = GSP_set_jointkey.columns.str.lower()
print("GSP_set_jointkey df columns renamed")
for each_col in GSP_set_jointkey.columns:
    if GSP_set_jointkey.dtypes[each_col] == 'O':
        GSP_set_jointkey[each_col] = GSP_set_jointkey[each_col].astype(str)
                            
GSP_set_jointkey.to_parquet(f"{args.destination}/gsp_set_joint_key/gsp_set_joint_key.parquet", index=False)
 
print("GSP_set_jointkey to parquet written successfully")
