"""Extract program data from Adobe Marketo using the Bulk Extract API."""

import argparse
import json

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from marketorestpython.client import MarketoClient
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from utils import camel_to_snake, flatten, get_all_s3_objects, parse_s3_uri

s3 = boto3.client("s3")

secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="data-lake-adobe-marketo")[
        "SecretString"
    ]
)
client = MarketoClient(secret["munchkin_id"], secret["client_id"], secret["client_secret"])

parser = argparse.ArgumentParser(description="Ingest data from Marketo Programs")
parser.add_argument("--source", dest="source", help="Source Marketo programs extract")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

# Read JSON from S3
bucket, prefix = parse_s3_uri(args.source)
objects = get_all_s3_objects(s3=s3, Bucket=bucket, Prefix=prefix)
paths = [f"s3://{bucket}/{o['Key']}" for o in objects]

glue_df = glueContext.create_dynamic_frame.from_options(
    format_options={"jsonPath": "", "multiline": True},
    connection_type="s3",
    format="json",
    connection_options={"paths": paths},
)

# Convert to Spark DataFrame
df = glue_df.toDF()
flattened = flatten(df.schema)
df = df.select(*flattened)
df = df.select(*[F.col(f.name).alias(camel_to_snake(f.name)) for f in df.schema.fields])
df = df.withColumn(
    "created_at", F.regexp_replace(F.col("created_at"), "\+0000", "").cast("timestamp")
)
df = df.withColumn(
    "updated_at", F.regexp_replace(F.col("updated_at"), "\+0000", "").cast("timestamp")
)


# Repartition into smaller partitions for performance
n_partitions = int(df.rdd.getNumPartitions() / 10)
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)

df.write.mode("overwrite").save(args.destination)

job.commit()
