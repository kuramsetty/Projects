"""Transformers for Datorama."""

import argparse

import boto3
import pandas as pd
from awsglue.context import GlueContext
from awsglue.job import Job
from marketo import cast_marketo_bulk_df
from pyspark.context import SparkContext
from utils import parse_s3_uri

s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Ingest data from datorama")
parser.add_argument("--source", dest="source", help="Source Marketo programs extract")
parser.add_argument("--metadata-path", dest="metadata_path", help="S3 path to the metadata")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

MARKETO_TYPE_MAPPING = {
    "boolean": "boolean",
    "integer": "integer",
    "datetime": "timestamp",
    "date": "date",
    "number": "int",
    "float": "float",
    "image": "string",
    "link": "string",
    "text": "string",
}

dtypes = {}
metadata = pd.read_csv(args.metadata_path)

glueContext = GlueContext(SparkContext.getOrCreate())
spark = glueContext.spark_session
job = Job(glueContext)

job.init(args.name)

bucket_full, prefix_full = parse_s3_uri(args.source)
objects_full = s3.list_objects_v2(Bucket=bucket_full, Prefix=prefix_full).get("Contents", None)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]

df = spark.read.format("csv").option("header", "true").load(paths_full)

for column_name in df.columns:
    if column_name in list(metadata.loc[:, "Display Name"]):
        index = metadata.index[metadata["Display Name"] == column_name]
        data_type = metadata["Type"][index].values[0].lower()
        dtypes[column_name] = MARKETO_TYPE_MAPPING.get(data_type, "string")
    else:
        dtypes[column_name] = "int"

df = cast_marketo_bulk_df(df, dtypes)

n_partitions = int(df.rdd.getNumPartitions() / 4)
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)

df.write.mode("overwrite").save(args.destination)

job.commit()
