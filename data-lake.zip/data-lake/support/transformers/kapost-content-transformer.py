#!/usr/bin/env python
"""Transformers for Kapost Content."""
import argparse

import boto3
import pandas as pd
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.functions import col, expr, struct
from utils import (
    camel_to_snake,
    get_all_s3_objects,
    parse_s3_uri,
    remove_null_columns,
)

s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
parser.add_argument("--kapost-api-name", dest="kapost_api_name", help="Name of the API")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

bucket_full, prefix_full = parse_s3_uri(args.source)
objects_full = get_all_s3_objects(s3=s3, Bucket=bucket_full, Prefix=prefix_full)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]


def replace_null_with_empty(array):
    """Replacing null with quote's."""
    return [x if x is not None else "" for x in array]


def remove_empty_array_and_null_columns(df):
    """Removing empty array and null columns."""
    array_columns = [f.name for f in df.schema.fields if isinstance(f.dataType, T.ArrayType)]
    # empty_arrays_per_column = df.select([F.count(F.when(F.size(c) == 0, c)).alias(c) for c in
    # array_columns]).toPandas().transpose()
    print(f"array_columns--> {array_columns}")
    df_empty_array = (
        df.select([F.count(F.when(F.size(c) == 0, c)).alias(c) for c in array_columns])
        .toPandas()
        .transpose()
    )
    print(f"df_empty_array--> {df_empty_array}")
    df_None = (
        df.select([F.count(F.when((col(c).isNull()), c)).alias(c) for c in array_columns])
        .toPandas()
        .transpose()
    )
    print(f"df_None--> {df_None}")
    concat_df = pd.concat([df_empty_array, df_None])
    concat_df.columns = ["count"]
    print(f"concat_df--> {concat_df}")
    empty_arrays_per_column = concat_df.groupby(concat_df.index)["count"].sum().to_frame()
    print(f"empty_arrays_per_column--> {empty_arrays_per_column}")
    all_empty_array_columns = []
    if len(empty_arrays_per_column) > 0:
        empty_arrays_per_column.columns = ["n_nulls"]
        df_count = df.count()
        all_empty_array_columns = empty_arrays_per_column[
            empty_arrays_per_column.n_nulls == df_count
        ].index.tolist()

        for null_col in all_empty_array_columns:
            print(f"Removing empty array column {null_col}")
    print(f"all_empty_array_columns--> {all_empty_array_columns}")
    print(f"df.columns--> {df.columns}")
    filtered_columns = [c for c in df.columns if c not in set(all_empty_array_columns)]
    print(f"filtered_columns--> {filtered_columns}")

    return df.select([F.col(c) for c in filtered_columns])


try:
    # Read JSON from S3
    glue_df = glueContext.create_dynamic_frame.from_options(
        format_options={"jsonPath": "", "multiline": True},
        connection_type="s3",
        format="json",
        connection_options={"paths": paths_full},
    )

    # Convert to Spark DataFrame
    df = glue_df.toDF()
    if args.kapost_api_name == "content":
        df = df.drop("custom_fields")
        df = df.withColumn("published_date", F.to_timestamp("published_date"))
        df = df.withColumn("updated_at", F.to_timestamp("updated_at"))
    else:
        df = (
            df.select(F.col("id"), F.explode(df.custom_fields))
            .withColumnRenamed("id", "content_id")
            .select(["content_id", "col.*"])
            .drop("select_value_ids")
        )
        df = df.withColumn("created_at", F.to_timestamp("created_at"))
    print(" before updating Schema ", df.printSchema())

    df = df.withColumn(
        "last_updated_by",
        struct(
            col("last_updated_by.id"),
            col("last_updated_by.email"),
            col("last_updated_by.name"),
            col("last_updated_by.name_sort"),
            col("last_updated_by.avatar_feed_url"),
            col("last_updated_by.avatar_thumbnail_url"),
            col("last_updated_by.avatar_profile_large_url"),
            col("last_updated_by.avatar_profile_url"),
            col("last_updated_by.slug"),
            col("last_updated_by.created_at"),
            col("last_updated_by.updated_at"),
            col("last_updated_by.bio"),
            col("last_updated_by.short_bio"),
            col("last_updated_by.visitor"),
            col("last_updated_by.tz"),
            col("last_updated_by.follow_discussion_allowed"),
            col("last_updated_by.superadmin"),
            expr("transform(last_updated_by.tours_seen, x -> if(x is null, '', x))").alias(
                "tours_seen"
            ),
            col("last_updated_by.phone"),
            col("last_updated_by.removed"),
            col("last_updated_by.role"),
            expr("transform(last_updated_by.group_ids, x -> if(x is null, '', x))").alias(
                "group_ids"
            ),
        ),
    )

    # print("Schema ",df.printSchema())
    # print("Before removing null cols and empty array cols ")
    df = remove_null_columns(df)
    df = remove_empty_array_and_null_columns(df)
    print("After removing null cols and empty array cols ")
    print("Schema ", df.printSchema())

    df = df.select(*[F.col(f.name).alias(camel_to_snake(f.name)) for f in df.schema.fields])

    n_partitions = int(df.rdd.getNumPartitions() / 40)

    # Repartition into smaller partitions for performance
    if n_partitions <= 1:
        n_partitions = 1
    df = df.coalesce(n_partitions)

    print(f"Writing to {args.destination}")
    df.write.mode("overwrite").save(args.destination)
except Exception as e:
    # Handle exceptions
    print(f"An error occurred: {e}")

job.commit()
