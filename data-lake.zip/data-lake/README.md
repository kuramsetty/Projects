# Data Lake Repository

This repository is used to create the data lake. Specifically, it contains:

- Provisioning of S3 Buckets, Options, Lifecycle Policies etc (`data_lake.data_lake_bucket_stack.DataLakeBucketStack`)
- Various Glue Pipelines for ingesting data from source systems (`data_lake.data_lake_etl_stack.DataLakeGlueStack`)

The CodePipeline that runs off of this repository (On Infra Account #: 977982708932)

[is available here for qa](https://eu-central-1.console.aws.amazon.com/codesuite/codepipeline/pipelines/qa-data-lake-pipeline/view?region=eu-central-1),

[is available here for prod](https://eu-central-1.console.aws.amazon.com/codesuite/codepipeline/pipelines/prod-data-lake-pipeline/view?region=eu-central-1).

All you have to do is to commit to this repository.  The AWS resources will then
be provisioned via CodePipeline/CodeBuild.


## Extract and Transform Jobs

We define an ingestion pipeline as a 3-step process:

1. Extract data from the source system
2. Repartition and write data into the target format (preferrably parquet)
3. Crawl the data in the target format and add/update the data catalog

This process can be achieved using a Glue workflow and additional triggers for scheduling jobs:

![](img/glue_workflow.png)

You can add such a workflow by placing a jobspec YAML file into the `jobs` subdirectory. Once you push your new job
to gitlab, the workflow will be automatically created in Glue.

The following keywoards are currently supported:

* `name`: The name of this workflow.
* `database`: The Glue database where the table in the data catalog should be created. This database must exist already.
* `schedule`: AWS cron schedule for the workflow, e.g. `cron(10 19 ? * FRI *)`. Defaults to daily.
* `extractor`: The path to the script that is responsible for the extraction. It will receive it following arguments:
    - `--source SOURCE`: The source of this extraction, where `SOURCE` will be set according to `source` in
      the jobspec YAML.
    - `--destination DESTINATION`: S3 path where the extraction script should write to, where `DESTINATION` will
      be set according to `extractor_output` in the jobspec YAML.
* `extractor_args`: Any additional arguments passed to the extractor.
* `extractor_output`: The path where your `extractor` script writes to. Also the input to your `transformer`.
* `transformer`: Script that takes your extracted data, transforms it, and writes it to S3 in the target format.
  It will receive the following arguments:
    - `--source SOURCE`: The input for this transformer, where `SOURCE` will be set according to `extractor_output`.
    - `--destination DESTINATION`: The destination path where to write the transformed data to, where
      `DESTINATION` will be set according to `transformer_output`.
* `transformer_args`: Any additional arguments passed to the transformer.
* `transformer_output`: The path where your `transformer` script writes to. Also the input to the Glue crawler.
* `transformer_schedule`: In case you do not want to trigger the transformer by the success of the extractor, you can
  specify a separate schedule for the transformer. This is useful if you e.g. want to do CDC hourly, but only wish to
  write to parquet daily.

Note that everything you put into the `support` subdirectory will be automatically mirrored onto S3. Hence,
there is no need to upload Glue scripts manually.

An exemplary job may look as follows:

```yaml
vars:
  c4c: https://my343420.crm.ondemand.com/sap/c4c/odata/v1/c4codataapi
  database: sap_c4c

jobs:
- name: sap-c4c-corporate_account_collection
  database: '{database}'
  extractor: s3://{glue_bucket}/extractors/odata-full.py
  extractor_output: s3://{bucket}/raw/sap_c4c/corporate_account_collection
  source: '{c4c}/CorporateAccountCollection'
  transformer: s3://{glue_bucket}/transformers/odata-full.py
  transformer_output: s3://{bucket}/processed/sap_c4c/corporate_account_collection
  schedule: cron(10 19 ? * FRI *)

- name: sap-c4c-corporate_account_has_contact_person_collection
  database: '{database}'
  extractor: s3://{glue_bucket}/extractors/odata-full.py
  extractor_output: s3://{bucket}/raw/sap_c4c/corporate_account_has_contact_person_collection
  source: '{c4c}/CorporateAccountHasContactPersonCollection'
  transformer: s3://{glue_bucket}/transformers/odata-full.py
  transformer_output: s3://{bucket}/processed/sap_c4c/corporate_account_has_contact_person_collection
  transformer_args:
    foo: 3
```

The YAML jobspecs support custom variables as well as variables set by the CDK stacks. Custom variables
should be defined in the `vars` section while the following variables will be passed automatically:

- `glue_bucket`: The bucket that contains the Glue Python scripts. Note that anything put under `support` will
  be automatically uploaded to this bucket.  
- `bucket`: The data lake bucket (set in `cdk.json`)
- `account`: The AWS account id (set in `cdk.json`)
- `region`: The AWS region (set in `cdk.json`)

## Extraction Types

There are three types of extractions used in this pipeline:

- Full Extract: The entire data set is extracted in full on a schedule (e.g. daily)
- Delta Extract: First, a full extract is performed. Afterwards, only new data is extracted incrementally
- Change Data Capture: Similar to Delta Extract; however, all changes are recorded and added to the data set. This
  allows for a historical view of how specific rows have evolved over time.

## Design Principles

These design principles should be followed when adding/adjusting workflows and jobs:
- Reuse existing job scripts as much as possible. You can pass additional arguments for both the transformer
and extractor to cause different behavior for specific jobs.
- Always write the RAW data into S3 first. Avoid any preprocessing in the extraction step.

## Environment Setup (IDE etc)

If you want to develop this package locally, please be aware of the following:

- To resolve import errors in your IDE, you should add `support/glue` as source root. In e.g. PyCharm,
  this can be done by clicking on the `glue` folder in `support`, selecting `Mark directory as` and `Sources Root`.
- The majority extract jobs are written in such a way that they can be executed locally in case they don't require
  PySpark. Have a look at `scripts/test_jobs.sh` to find out how.

## Source Systems

### SAP Cloud for Customer (C4C) - Full Extract

Please see the following [documentation on the C4C OData API](https://github.com/SAP/C4CODATAAPIDEVGUIDE).

The jobspec file in ``jobs/c4c_jobs.yml`` has been automatically generated and added to git using the following
command:

```bash
python scripts/create-c4c-jobspecs.py jobs/c4c_jobs.yml
```

You can add additional sources to ``scripts/create-c4c-jobspecs.py``. After doing so, don't forget to also update
``jobs/c4c_jobs.yml`` by executing the python script.

### SAP Cloud for Customer (C4C) - Change Data Capture Extract

## CloudFormation Issues

In some rare cases it might be necessary to delete and redeploy the DataLakeETL-Glue CloudFormation stack. In
order to do so, please follow this sequence of events:

1. Delete the `DataLakeETL-Glue` Stack in CloudFormation
2. Empty and delete the `cap-data-lake-glue` bucket (don't worry, the content is deployed by the stack)
3. Redeploy the stack pushing to GitLab

## CDK Instructions

This is a blank project for Python development with CDK.

The `cdk.json` file tells the CDK Toolkit how to execute your app.

This project is set up like a standard Python project.  The initialization
process also creates a virtualenv within this project, stored under the `.venv`
directory.  To create the virtualenv it assumes that there is a `python3`
(or `python` for Windows) executable in your path with access to the `venv`
package. If for any reason the automatic creation of the virtualenv fails,
you can create the virtualenv manually.

To manually create a virtualenv on MacOS and Linux:

```bash
python3 -m venv .venv
```

After the init process completes and the virtualenv is created, you can use the following
step to activate your virtualenv.

```bash
source .venv/bin/activate
```

If you are a Windows platform, you would activate the virtualenv like this:

```bash
.venv\Scripts\activate.bat
```

Once the virtualenv is activated, you can install the required dependencies.

```bash
pip install -r requirements.txt
```

At this point you can now synthesize the CloudFormation template for this code.

```bash
cdk synth
```

To add additional dependencies, for example other CDK libraries, just add
them to your `setup.py` file and rerun the `pip install -r requirements.txt`
command.

### Useful commands

 * `cdk ls`          list all stacks in the app
 * `cdk synth`       emits the synthesized CloudFormation template
 * `cdk deploy`      deploy this stack to your default AWS account/region
 * `cdk diff`        compare deployed stack with current state
 * `cdk docs`        open CDK documentation

Enjoy!
