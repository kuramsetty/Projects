from aws_cdk import Stack
from aws_cdk import aws_glue as glue
from aws_cdk import aws_iam as iam
from aws_cdk.aws_s3_assets import Asset
from constructs import Construct

class ResourceStack(Stack):
    """AWS Glue workflow stack for data extraction and processing"""

    def __init__(self, scope: Construct, construct_id: str, environment: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        project_name = self.node.try_get_context("project_name")
        account = self.node.try_get_context(environment)["account"]
        custom_args = self.node.try_get_context(environment)["custom_args"]

        # Asset for the Glue job script
        glue_code_asset = Asset(
            self,
            'GlueCodeAsset',
            path="glue/sap-cdp-cloud-datalake-extract-profile-qa.py"
        )

        # IAM Role for Glue jobs
        glue_role = iam.Role.from_role_arn(
            self, "gluejobrole",
            f"arn:aws:iam::{account}:role/data-lake-glue-role"
        )

        # Define Glue Job: Extract Profile Data
        job_name_extract_profile = f"{project_name}-extract-profile-{environment}"
        default_arguments_profile = {
            "--source": "https://cdp.eu5.gigya.com/api/businessunits/4_cFrm6IsvdLW1rG95tVZ2qA/views",
            "--destination": f"s3://cap-{environment}-data-lake/profiles/",
            "--ingestion_type": "Delta",
            "--job_name": job_name_extract_profile,
            "--ENV": environment
        }
        glue_args_profile = {f'--{key}': value for key, value in custom_args.get('glue').items()}
        default_arguments_profile.update(glue_args_profile)

        glue.CfnJob(
            self, "sap-cdp-cloud-extract-profile",
            command=glue.CfnJob.JobCommandProperty(
                name="glueetl",
                python_version="3",
                script_location=f"s3://{glue_code_asset.s3_bucket_name}/{glue_code_asset.s3_object_key}"
            ),
            role=glue_role.role_name,
            description=f"Glue job to extract profile data for {project_name}",
            name=job_name_extract_profile,
            timeout=2048,
            execution_class="FLEX",
            glue_version="4.0",
            worker_type="G.1X",
            number_of_workers=4,
            default_arguments=default_arguments_profile
        )

        # Define Glue Job: Extract Data
        job_name_extract = f"{project_name}-extract-{environment}"
        default_arguments = {
            "--source": "https://cdp.eu5.gigya.com/api/businessunits/4_cFrm6IsvdLW1rG95tVZ2qA/views",
            "--destination": f"s3://cap-{environment}-data-lake/",
            "--ingestion_type": "Delta",
            "--job_name": job_name_extract,
            "--ENV": environment
        }
        glue_args = {f'--{key}': value for key, value in custom_args.get('glue').items()}
        default_arguments.update(glue_args)

        glue.CfnJob(
            self, "sap-cdp-cloud-extract",
            command=glue.CfnJob.JobCommandProperty(
                name="glueetl",
                python_version="3",
                script_location=f"s3://{glue_code_asset.s3_bucket_name}/{glue_code_asset.s3_object_key}"
            ),
            role=glue_role.role_name,
            description=f"Glue job to extract data for {project_name}",
            name=job_name_extract,
            timeout=2048,
            execution_class="FLEX",
            glue_version="4.0",
            worker_type="G.1X",
            number_of_workers=4,
            default_arguments=default_arguments
        )

        # Define Glue Workflow
        glue.CfnWorkflow(
            self, f"{project_name}-workflow",
            description=f"Workflow for {project_name} data extraction and processing",
            name=f"{project_name}-workflow"
        )

        # SCHEDULED Trigger: Runs job_name_extract_profile on a schedule
        glue.CfnTrigger(
            self, f"{project_name}-extract-profile-trigger",
            actions=[glue.CfnTrigger.ActionProperty(
                job_name=job_name_extract_profile,
                timeout=240
            )],
            type="SCHEDULED",
            description="Scheduled trigger for extract profile job",
            name=f"{project_name}-extract-profile-trigger",
            schedule=default_arguments_profile['--UPDATE_SCHEDULE'],
            start_on_creation=True,
            workflow_name=f"{project_name}-workflow"
        )

        # CONDITIONAL Trigger: Runs job_name_extract after job_name_extract_profile succeeds
        glue.CfnTrigger(
            self, f"{project_name}-glue-extract-job-trigger",
            actions=[glue.CfnTrigger.ActionProperty(
                job_name=job_name_extract,
                timeout=240
            )],
            type="CONDITIONAL",
            description="Trigger for extract job after extract profile job succeeds",
            predicate=glue.CfnTrigger.PredicateProperty(
                conditions=[
                    glue.CfnTrigger.ConditionProperty(
                        logical_operator="EQUALS",
                        job_name=job_name_extract_profile,
                        state="SUCCEEDED"
                    )
                ]
            ),
            workflow_name=f"{project_name}-workflow"
        )

        # CONDITIONAL Trigger: Runs Glue Crawler after job_name_extract succeeds
        glue.CfnTrigger(
            self, f"{project_name}-crawler-trigger",
            actions=[glue.CfnTrigger.ActionProperty(
                crawler_name=f"{project_name}-crawler"
            )],
            type="CONDITIONAL",
            description="Trigger for crawler after extract job succeeds",
            predicate=glue.CfnTrigger.PredicateProperty(
                conditions=[
                    glue.CfnTrigger.ConditionProperty(
                        logical_operator="EQUALS",
                        job_name=job_name_extract,
                        state="SUCCEEDED"
                    )
                ]
            ),
            workflow_name=f"{project_name}-workflow"
        )

        # Define Glue Crawler (Targets S3 data lake paths)
        s3_paths = [
            f"s3://cap-{environment}-data-lake/cdp-cloud/raw/full/profiles/con_profile/",
            f"s3://cap-{environment}-data-lake/cdp-cloud/raw/full/profiles/uni_profile/",
            f"s3://cap-{environment}-data-lake/cdp-cloud/transformed/activities/"
        ]

        glue.CfnCrawler(
            self, f"{project_name}-crawler",
            role=glue_role.role_name,
            targets=glue.CfnCrawler.TargetsProperty(
                s3_targets=[glue.CfnCrawler.S3TargetProperty(path=path) for path in s3_paths]
            ),
            database_name="sap-cdp-cloud",
            description="Crawler to crawl cdp cloud datasets events table",
            recrawl_policy={
                "recrawlBehavior": "CRAWL_EVERYTHING"
            },
            name=f"{project_name}-crawler"
        )
