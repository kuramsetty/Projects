
# Pipeline Template Repository

This repository functions as the starting point to cross account deployment CDK projects.
In this project, a Lambda function with a daily trigger is included.

Changes to this repository will be included in all newly created projects based on the pipeline-automation
repository.

## Development

Always run `pre-commit install` before making any changes
