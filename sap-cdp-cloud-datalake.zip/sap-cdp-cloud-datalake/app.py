"""CDK App for deploying resources to other accounts."""

import os

from aws_cdk import App, Stage
from constructs import Construct

from infra.pipeline_stack import PipelineStack
from infra.resource_stack import ResourceStack

environment = os.environ["ENVIRONMENT"]
branch = "main" if environment == "prod" else environment


class ResourceStage(Stage):
    """Resource Stage to create resources - to be defined by use case."""

    def __init__(
        self, scope: Construct, construct_id: str, source_zip: str, environment: str, **kwargs
    ):
        """ResourceStage constructor.

        Args:
            scope (Construct): Parent construct.
            construct_id (str): Construct ID.
            source_zip (str): S3 source zip file.
            environment (str): Environment qa/prod.
            **kwargs: Additional keyword arguments.
        """
        super().__init__(scope, construct_id, **kwargs)

        env = {
            "region": app.node.try_get_context(environment)["region"],
            "account": app.node.try_get_context(environment)["account"],
        }
        ResourceStack(self, "ResourceStack", environment=environment, env=env, **kwargs)


app = App()

project_name = app.node.try_get_context("project_name")
account_folder = app.node.try_get_context("account_folder")
resource_type = app.node.try_get_context("resource_type")
owner = app.node.try_get_context("owner")
env = {
    "region": app.node.try_get_context("region"),
    "account": app.node.try_get_context("account"),
}
tags = {"cov:owner": owner, "cov:use-case": project_name}
s3_source = f"s3://cap-infra-git2s3-sc/covestro-analytics-platform/platform/{account_folder}/{resource_type}/{project_name}/{branch}/covestro-analytics-platform_platform_{account_folder}_{resource_type}_{project_name}.zip"

stack = PipelineStack(
    app,
    f"{project_name}-{environment}-pipeline",
    env=env,
    source_zip=s3_source,
    pipeline_name=f"{project_name}-{environment}-resource-pipeline",
    stages=[
        ResourceStage(
            scope=app,
            construct_id=f"{project_name}-{environment}-resourcestage",
            source_zip=s3_source,
            environment=environment,
        )
    ],
    environment=environment,
    tags=tags,
)

app.synth()
