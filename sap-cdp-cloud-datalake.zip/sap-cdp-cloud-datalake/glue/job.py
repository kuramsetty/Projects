import argparse
import re
from time import sleep
from datetime import datetime
from urllib.parse import urlparse
import json
import requests
import boto3
from botocore.exceptions import ClientError

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.window import Window
# Create a Spark session
from pyspark.sql.types import *
from pyspark.sql.functions import col, expr
from datetime import timedelta

spark = SparkSession.builder.appName('json-payload').getOrCreate()

def get_secret():
    """Method to fetch secret creds."""
    secret_name = "cdp_cloud" # Secret name in AWS Secrets Manager
    region_name = "eu-central-1"  # Region where the secret is stored

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        print(f"Error fetching secret: {e}")
        raise e

    # Decrypts secret if it's a string
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)

# Fetch credentials from AWS Secrets Manager
secret_data = get_secret()
client_id = secret_data['client_id']  # Replace with the key for your Client ID from the secret
client_secret = secret_data['client_secret']  # Replace with the key for your Client Secret from the secret

data = {
    "grant_type": "client_credentials",  # OAuth 2.0 grant type
    "client_id": client_id,
    "client_secret": client_secret,
}
url = "https://oauth2.us1.gigya.com/oauth2/token"

# Send the POST request to the token URL
response = requests.post(url, data=data)
if response.status_code == 200:
    # Parse the response JSON and get the access token
    token = response.json().get("access_token")
    print(f"Access Token: {token}")
else:
    print(f"Error {response.status_code}: {response.text}")

whole_data = []

activities_list = ['activity_webbehavior','activity_webinar_event','activity_email_campaign','activity_lead','activity_form_submission','activity_interesting_moment']

def api_call(api_url):
    final_data = []
    for ids in api_url:

        api_url = f"https://cdp.eu5.gigya.com/api/businessunits/4_cFrm6IsvdLW1rG95tVZ2qA/views/HA2hHyAekHYNDQZ0xc0DWQ/customers/{ids}/activities?query=select * from activity_interesting_moment"

        headers = {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }
        # Make the GET request to the API
        response = requests.get(api_url, headers=headers)

        if response.status_code == 200:
            data = response.json()
            if len(data["activities"]) != 0:
                apidata = data["activities"]
                for ids_add in apidata:
                    ids_add["cdp_id"] = ids
                    final_data.append(ids_add)
    return final_data

def fetch_data_with_cursor(access_token, api_url, cursor_id=None):
    # Set up the request headers with the access token
    headers = {
        'Authorization': f'Bearer {access_token}',
        'Content-Type': 'application/json'
    }
    # Prepare the parameters for pagination (cursor_id for the next page)
    params = {}
    if cursor_id:
        params['CursorId'] = cursor_id

    # Make the GET request to the API
    response = requests.get(api_url, headers=headers, params=params)

    if response.status_code == 200:
        data = response.json()
        # Check if there's a next cursor_id for pagination
        next_cursor_id = data.get('nextCursorId')  # Replace with the actual key for pagination
        page_count = data.get('count')
        profile = data['profiles']
        if len(data) != 0:
            json_data = json.dumps(profile)
            whole_data.extend(profile)
            #print(json_data)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            custom_filename = f"data_{timestamp}.json"

            if int(page_count) != 0:
                print(f"Fetching next page with cursor_id: {next_cursor_id}")
                fetch_data_with_cursor(access_token, api_url, cursor_id=next_cursor_id)
            else:
                print("No more data.")

            return whole_data
    else:
        print(f"Error: {response.status_code} - {response.text}")


cur_url = "https://cdp.eu5.gigya.com/api/businessunits/4_cFrm6IsvdLW1rG95tVZ2qA/views/HFmKUL1GfodqAHEeCXTiCA/customers?query=select * from profile&openCursor=true&userKey='AAyvT5TFzNzg'&secret='fLQaQObAr+hGjtSgfENk0dYJFUFMuztl'"

schema = StructType([
    StructField("_id", StringType(), True),
    StructField("activityIndicators", ArrayType(
        StructType([
            StructField("count", DoubleType(), True),
            StructField("lastBoolean", BooleanType(), True),
            StructField("lastDate", StringType(), True),
            StructField("lastString", StringType(), True),
            StructField("name", StringType(), True),
            StructField("updated", StringType(), True)
        ])
    ), True),
    StructField("appliedRetentionPolicy", StringType(), True),
    StructField("attributes", StructType([
        StructField("addresses", ArrayType(
            StructType([
                StructField("addressId", StringType(), True),
                StructField("country", StringType(), True),
                StructField("town", StringType(), True)
            ])
        ), True),
        StructField("birthDate", StringType(), True),
        StructField("cdcId", StringType(), True),
        StructField("cdpId", ArrayType(StringType()), True),
        StructField("ciamId", ArrayType(StringType()), True),
        StructField("company", StructType([
            StructField("department", StringType(), True),
            StructField("industry", StringType(), True),
            StructField("jobFunction", StringType(), True),
            StructField("name", StringType(), True)
        ]), True),
        StructField("cookieId", StringType(), True),
        StructField("cov_add_source", StringType(), True),
        StructField("cov_c4c_contact_id", ArrayType(StringType()), True),
        StructField("cov_contact_status", StringType(), True),
        StructField("cov_department", StringType(), True),
        StructField("cov_inferred_intrst", StructType([
            StructField("cov_inf_int_indust", StringType(), True)
        ]), True),
        StructField("cov_interests_ind", StructType([
            StructField("cov_101", BooleanType(), True),
            StructField("cov_102", BooleanType(), True),
            StructField("cov_103", BooleanType(), True),
            StructField("cov_111", BooleanType(), True),
            StructField("cov_121", BooleanType(), True),
            StructField("cov_131", BooleanType(), True),
            StructField("cov_141", BooleanType(), True),
            StructField("cov_151", BooleanType(), True),
            StructField("cov_161", BooleanType(), True),
            StructField("cov_171", BooleanType(), True),
            StructField("cov_181", BooleanType(), True),
            StructField("cov_191", BooleanType(), True),
            StructField("cov_192", BooleanType(), True),
            StructField("cov_201", BooleanType(), True),
            StructField("cov_211", BooleanType(), True),
            StructField("cov_221", BooleanType(), True)
        ]), True),
        StructField("cov_interests_mat", StructType([
            StructField("cov_m01", BooleanType(), True),
            StructField("cov_m02", BooleanType(), True),
            StructField("cov_m03", BooleanType(), True),
            StructField("cov_m04", BooleanType(), True),
            StructField("cov_m05", BooleanType(), True),
            StructField("cov_m06", BooleanType(), True),
            StructField("cov_m07", BooleanType(), True),
            StructField("cov_m08", BooleanType(), True)
        ]), True),
        StructField("cov_interests_st", StructType([
            StructField("cov_st01", BooleanType(), True),
            StructField("cov_st02", BooleanType(), True),
            StructField("cov_st03", BooleanType(), True),
            StructField("cov_st04", BooleanType(), True)
        ]), True),
        StructField("cov_job_title", StringType(), True),
        StructField("cov_market_consent", StructType([
            StructField("cov_consent_source", StringType(), True),
            StructField("cov_external_optin", StringType(), True),
            StructField("cov_optin", StringType(), True),
            StructField("cov_optin_implicit", StringType(), True),
            StructField("cov_optin_req_sour", StringType(), True)
        ]), True),
        StructField("cov_person_source", StringType(), True),
        StructField("cov_primary_address", StructType([
            StructField("cov_country", StringType(), True)
        ]), True),
        StructField("cov_reg_source", StringType(), True),
        StructField("cov_reg_type", StringType(), True),
        StructField("crmId", ArrayType(StringType()), True),
        StructField("deviceId", ArrayType(StringType()), True),
        StructField("emailAccountToken", StringType(), True),
        StructField("emails", ArrayType(
            StructType([
                StructField("email", StringType(), True),
                StructField("isPrimary", BooleanType(), True)
            ])
        ), True),
        StructField("firstName", StringType(), True),
        StructField("language", StringType(), True),
        StructField("lastName", StringType(), True),
        StructField("lastNameEmail", StringType(), True),
        StructField("locale", StringType(), True),
        StructField("nickName", StringType(), True),
        StructField("phones", ArrayType(
            StructType([
                StructField("isPrimary", BooleanType(), True),
                StructField("number", StringType(), True)
            ])
        ), True),
        StructField("prefsIndustry", StructType([
            StructField("automotive", BooleanType(), True),
            StructField("cosmetics", BooleanType(), True),
            StructField("energy", BooleanType(), True),
            StructField("healthcare", BooleanType(), True),
            StructField("rail", BooleanType(), True)
        ]), True),
        StructField("prefsMaterial", StructType([
            StructField("adhesives", BooleanType(), True),
            StructField("composites", BooleanType(), True),
            StructField("films", BooleanType(), True),
            StructField("foams", BooleanType(), True),
            StructField("plastics", BooleanType(), True)
        ]), True),
        StructField("primaryCdpId", StringType(), True),
        StructField("primaryEmail", StringType(), True),
        StructField("primaryPhone", StringType(), True)
    ]), True),
    StructField("calculatedIndicators", ArrayType(StringType()), True),
    StructField("created", StringType(), True),
    StructField("docSize", LongType(), True),
    StructField("firstSeen", StringType(), True),
    StructField("journeys", ArrayType(
        StructType([
            StructField("id", StringType(), True),
            StructField("updated", StringType(), True)
        ])
    ), True),
    StructField("lastSeen", StringType(), True),
    StructField("matchRuleIds", ArrayType(StringType()), True),
    StructField("milestones", ArrayType(StringType()), True),
    StructField("predictiveIndicators", ArrayType(StringType()), True),
    StructField("privacy", StructType([
        StructField("purposes", ArrayType(
            StructType([
                StructField("date", StringType(), True),
                StructField("externalId", StringType(), True),
                StructField("purposeId", StringType(), True),
                StructField("status", StringType(), True)
            ])
        ), True),
        StructField("subscriptions", ArrayType(
            StructType([
                StructField("channelType", StringType(), True),
                StructField("date", StringType(), True),
                StructField("externalId", StringType(), True),
                StructField("status", StringType(), True)
            ])
        ), True)
    ]), True),
    StructField("relationships", ArrayType(
        StructType([
            StructField("HLQemP8mIYmLJ4lCH9LPqw", StructType([
                StructField("accountID", StringType(), True),
                StructField("cov_c4c_contact_id", StringType(), True),
                StructField("groupId", StringType(), True)
            ]), True)
        ])
    ), True),
    StructField("segments", ArrayType(
        StructType([
            StructField("name", StringType(), True),
            StructField("updated", StringType(), True),
            StructField("value", StringType(), True)
        ])
    ), True),
    StructField("updated", StringType(), True),
    StructField("updatedTimestamp", LongType(), True),
    StructField("viewId", StringType(), True)
])

data = fetch_data_with_cursor(token, cur_url, cursor_id=None)
df = spark.createDataFrame(whole_data, schema=schema)
df_profile_transformed = df.select('*', 'attributes.*').drop('attributes')
df_profile_transformed = df_profile_transformed.withColumn("cov_market_consent", array(col("cov_market_consent")))
primcdp = df.select("attributes.primaryCdpId")
primcdp = primcdp.withColumn("primaryCdpId", split(col("primaryCdpId"), ":")[1])
activity_form_submission = api_call([row["primaryCdpId"] for row in primcdp.select("primaryCdpId").collect()])
activity_form_df = spark.createDataFrame(activity_form_submission)
keys = activity_form_df.selectExpr("explode(attributes) as (key, value)").select("key").distinct().rdd.flatMap(lambda x: x).collect()

for key in keys:
    activity_form_df = activity_form_df.withColumn(key, col("attributes").getItem(key))

activity_form_df = activity_form_df.drop("attributes")
activity_form_df.repartition(5).write.mode('Overwrite').parquet("s3://cdp-cloud-qa/raw/full/activities/activity_interesting_moment/")

df_profile_transformed.repartition(5).write.mode('Overwrite').parquet("s3://cdp-cloud-qa/raw/full/profiles/con_profile/")
