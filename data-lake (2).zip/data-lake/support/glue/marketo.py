"""Module that provides function to interface with the Adobe Marketo REST API."""

import json
from time import sleep
from urllib.parse import urlparse

import boto3
from dateutil.relativedelta import relativedelta
from pyspark.sql import functions as F
from utils import camel_to_snake, parse_s3_uri

s3 = boto3.client("s3")

# Map from Marketo data types to Spark data types. See https://spark.apache.org/docs/latest/sql-ref-datatypes.html
MARKETO_TYPE_MAPPING = {
    "boolean": "boolean",
    "integer": "integer",
    "datetime": "timestamp",
    "date": "date",
    "reference": "int",
    "float": "float",
}


def get_marketo_bulk_data_types(metadata_path):
    """
    Gets the Spark data types from a Marketo metadata JSON, using `MARKETO_TYPE_MAPPING` in the process to map
    from Marketo types to Spark types.

    Args:
        metadata_path: S3 path pointing to the metadata JSON document from Market

    Returns:
        dictionary mapping from column name to spark datatype
    """  # noqa: D205
    json_doc = (
        boto3.resource("s3")
        .Object(urlparse(metadata_path).netloc, urlparse(metadata_path).path[1:])
        .get()["Body"]
        .read()
    )
    metadata = json.loads(json_doc)
    dtypes = {}

    for field in metadata:
        dtypes[field["rest"]["name"]] = MARKETO_TYPE_MAPPING.get(field["dataType"], "string")

    return dtypes


def cast_marketo_bulk_df(df, dtypes):
    """
    Casts the data types for the columns in the Spark DataFrame `df` according to `dtypes` and renames
    it to snake_case.

    Args:
        df: a Spark DataFrame
        dtypes: dictionary mapping from column names to spark data types

    Returns:
        Spark DataFrame with columns casted
    """  # noqa: D205
    cols = []

    for col_name in [f.name for f in df.schema.fields]:
        dtype = dtypes.get(col_name, "string")

        # Replace null with None (NULL)
        col = F.when(F.col(col_name).isin("null"), None).otherwise(F.col(col_name))

        if dtype != "string":
            print(f"Casting column {col_name} to {dtype}")

        if dtype in ["boolean", "bool"]:
            col = F.when(F.col(col_name).isin("true"), True).otherwise(False).cast(dtype)
        elif dtype != "string":
            col = F.col(col_name).cast(dtype)

        # Rename to snake_case
        col = col.alias(camel_to_snake(col_name))

        cols.append(col)

    return df.select(cols)


def wait_for_completion(client, job_ids, method_type="leads"):
    """
    Waits for the completion of all jobs whose jobs are listed in `job_ids`.

    Args:
        client: the marketo client
        job_ids: list of job ids to wait for
        method_type: marketo python api method to call to get the status (`leads` or `activities`)

    Returns: metadata for each job

    """
    job_ready = {}
    job_statuses = {}

    for job_id in job_ids:
        job_ready[job_id] = False

    while True:
        for job_id in job_ids:
            if all(job_ready.values()):
                return job_statuses
            else:
                print(f"Completed {sum(job_ready.values())}/{len(job_ready)} export jobs.")

            status = client.execute(f"get_{method_type}_export_job_status", job_id=job_id)[0]
            job_statuses[job_id] = status

            if status["status"] in ["Failed", "Cancelled"]:
                raise ValueError(f"Export job {job_id} has failed.")
            if status["status"] == "Completed":
                job_ready[job_id] = True

            sleep(30)


def create_extract_ranges(start_datetime, end_datetime):
    """
    Creates date ranges for full data extracts. You should specify a date or datetime object for both
    `start_datetime` and `end_datetime`.

    Args:
        start_datetime: datetime object; only year and month are taken into account
        end_datetime: datetime object

    Returns:
        A list of date ranges that span up to 31 days
    """  # noqa: D205
    extract_ranges = []
    current_timestamp = start_datetime

    while current_timestamp < end_datetime - relativedelta(months=1):
        next_start = current_timestamp + relativedelta(months=1, hour=0, minute=0, second=0)

        start_at = current_timestamp.isoformat().split(".")[0] + "Z"
        end_at = next_start.isoformat().split(".")[0] + "Z"

        extract_ranges.append({"startAt": start_at, "endAt": end_at})
        current_timestamp = next_start

    extract_ranges.append(
        {"startAt": end_at, "endAt": end_datetime.isoformat().split(".")[0] + "Z"}
    )

    return extract_ranges


def bulk_extract(client, job_filters, fields="all", method_type="leads"):
    """
    Initiates a bulk extract job using the specified `client` and `job_filters`.

    Args:
        client: The Marketo client object.
        job_filters: A dictionary containing filters to specify which data to extract.
        fields (optional): Specifies the fields to include in the extraction. Defaults to "all".
        method_type (optional): Specifies the type of data to extract. Defaults to "leads".

    Returns:
        The job ID of the initiated bulk extract job.
    """
    job_ids = []
    if fields == "all":
        fields = [d["rest"]["name"] for d in client.describe()]

    for filters in job_filters:
        job = client.execute(
            method=f"create_{method_type}_export_job", fields=fields, filters=filters
        )
        job_id = job[0]["exportId"]
        job_ids.append(job_id)
        client.execute(method=f"enqueue_{method_type}_export_job", job_id=job_id)

        print(f"Submitted {method_type} extract job for filters {filters}; job_id is {job_id}")

    return job_ids


def retrieve_job_results(client, job_filters, destination, method_type):
    """
    Retrieves the results of a bulk extract job initiated with the specified `client` and `job_filters`,
    and saves them to the specified `destination`.

    Args:
        client: The Marketo client object.
        job_filters: A dictionary containing filters to specify which data to retrieve.
        destination: The destination path where the extracted data will be saved.
        method_type: The type of data extracted, e.g., "leads".

    Returns:
        The path where the extracted data is saved.
    """  # noqa: D205
    job_ids = bulk_extract(client=client, job_filters=job_filters, method_type=method_type)
    job_statuses = wait_for_completion(client, job_ids, method_type=method_type)
    records_received = 0

    for i, (job_id, job_filter) in enumerate(zip(job_ids, job_filters)):
        print(f"\nJob {i}:")
        job_status = job_statuses[job_id]
        print(job_status)

        if job_status["numberOfRecords"] == 0:
            print(f"No records for {job_filter} -- not writing")
            continue

        records_received += job_status["numberOfRecords"]

        res = client.execute(method=f"get_{method_type}_export_job_file", job_id=job_id).decode(
            "utf-8"
        )
        path = (
            f"{destination}"
            f"x_etl_start_at={job_filter['updatedAt']['startAt']}/"
            f"x_etl_end_at={job_filter['updatedAt']['endAt']}/"
            "data.csv"
        )
        bucket, key = parse_s3_uri(path)

        s3.put_object(Body=res, Bucket=bucket, Key=key)

        print(f"Wrote {path} ({job_status['numberOfRecords']} records)")

    print(f"Retrieved {records_received} records in {len(job_filters)} jobs.")

    return job_statuses, records_received


def extract_activities(client, destination, start_date, end_date, max_errors=3):
    """
    Extracts activity data from Marketo using the specified `client` and saves it to the `destination` path.

    Args:
        client: The Marketo client object.
        destination: The destination path where the extracted data will be saved.
        start_date: The start date for extracting activities.
        end_date: The end date for extracting activities.
        max_errors (int): The maximum number of errors to tolerate during extraction. Defaults to 3.

    Returns:
        The number of activity records extracted.
    """
    records_received = 0
    error_count = 0
    res_activity_type = client.execute(method="get_activity_types")
    for each_activity_type_id in res_activity_type:
        try:
            activity_type_id = str(each_activity_type_id["id"])
            lead_activities_id = client.execute(
                method="get_lead_activities_yield",
                activityTypeIds=[activity_type_id],
                sinceDatetime=start_date,
                untilDatetime=end_date[:-1],
            )
            bucket, key = parse_s3_uri(destination)
            print(f"for {activity_type_id} starting time: {start_date} and end_time: {end_date}.")
            for count, res in enumerate(lead_activities_id):
                target_key = f"{key}/activity_id={activity_type_id}/x_etl_start_date={start_date}/\
                    part_{str(count).zfill(9)}.jsonl"
                s3.put_object(
                    Body="\n".join(json.dumps(elem) for elem in res), Bucket=bucket, Key=target_key
                )
                records_received += len(res)
                print(f"destination path: s3://{bucket}/{target_key}")
        except NameError:
            if error_count >= max_errors:
                raise
            error_count += 1
            sleep(4)
            continue
    return records_received
