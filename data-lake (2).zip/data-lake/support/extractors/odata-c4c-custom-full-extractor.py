"""Does a CDC extract (incremental) from OData endpoint. Results are written to S3 in JSON format."""

import argparse
import json
from datetime import datetime
from time import sleep

import boto3
import requests
from utils import parse_s3_uri

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")

parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--source", dest="source", help="Source URI of OData endpoint")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
args = parser.parse_known_args()[0]

secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="sap-c4c-odata")["SecretString"]
)
auth = (secret["username"], secret["password"])

# Used for for delta updates via DynamoDB table
timestamp = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S")

last_import = timestamp
last_full_import = timestamp


print("Performing Full Extract")
destination = f"{args.destination}/full"
records_received = 0
errors = 0

top_result = 1000
skip_result = 0
res = {"d": {"results": True}}
count = 0
while res["d"]["results"]:
    url = f"{args.source}&$skip={skip_result}&$top={top_result}&$format=json"
    try:
        result = requests.get(url, auth=auth)  # noqa: S113
        res = result.json()
        response = res["d"]["results"]
        if response:
            records_received += len(response)
            bucket, key = parse_s3_uri(destination)
            target_key = f"{key}/part_{str(count).zfill(9)}.jsonl"
            s3.put_object(
                Body="\n".join(json.dumps(elem) for elem in response), Bucket=bucket, Key=target_key
            )
            skip_result += top_result
            count += 1
            print(f"destination path: s3://{bucket}/{target_key}")
    except NameError:
        if errors >= 3:  # noqa: PLR2004
            print(f"Not Performing c4c Identity extract dated {timestamp}")
            raise
        errors += 1
        sleep(4)


table.put_item(
    Item={
        "last_import": timestamp,
        "last_full_import": last_full_import,
        "job_name": args.job_name,
        "records_received": records_received,
    }
)
