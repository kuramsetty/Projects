"""example."""

import argparse
import io
from urllib.parse import urlparse

import boto3
import pandas as pd
from sklearn import datasets

parser = argparse.ArgumentParser(description="Load the Iris data set")
parser.add_argument("--source", dest="source", help="not used", default="")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
args = parser.parse_known_args()[0]


iris = datasets.load_iris()
df = pd.DataFrame(data=iris["data"])
df.columns = iris["feature_names"]
df["target"] = iris["target"]
df.columns = [c.replace("(", "").replace(")", "").replace(" ", "_") for c in df.columns]

s = io.StringIO()
df.to_csv(s, index=False, compression=None)

s3 = boto3.client("s3")

s3.put_object(
    Body=s.getvalue(),
    Bucket=urlparse(args.destination).netloc,
    Key=urlparse(args.destination).path[1:] + "/iris.csv",
)
