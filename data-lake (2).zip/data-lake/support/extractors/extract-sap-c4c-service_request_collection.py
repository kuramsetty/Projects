"""
Does CDC extract (full) from an OData endpoint. Results are written to S3 in JSON lines format.
"""
import argparse
import concurrent.futures
import json
from datetime import datetime, timedelta
from time import sleep
from typing import List, Tuple
from urllib.parse import urlparse
import re
import boto3
import requests

futures = []
s3 = boto3.client("s3")
session = requests.Session()

parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--source", dest="source", help="Source URI of OData endpoint")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
parser.add_argument(
    "--changed-column", dest="changed_column", help="Column containing the `changed on` timestamp"
)
parser.add_argument(
    "--start-datetime",
    dest="start_datetime",
    help="Defining starting date from where we need to fetch",
)
parser.add_argument(
    "--end-datetime", dest="end_datetime", help="Defining ending date till where we need to fetch"
)
args = parser.parse_known_args()[0]

source = args.source
destination = args.destination
job_name = args.job_name
changed_column = args.changed_column
start_datetime = args.start_datetime
end_datetime = args.end_datetime

secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="sap-c4c-odata")["SecretString"]
)
auth = (secret["username"], secret["password"])
pattern = r"datetimeoffset'(\d{4}-\d{2}-\d{2})T\d{2}:\d{2}:\d{2}Z'"

# Method to fetch data from endpoint based on object id
def parse_s3_uri(s: str) -> Tuple[str, str]:
    """
    Parse the s3 path url.

    Args:
        s (str): s3 path url
    Returns:
        Tuple[str,str]: returns bucket, key from the path
    """
    bucket = urlparse(s).netloc
    key = urlparse(s).path[1:]
    return bucket, key


# Method to fetch data from endpoint
def retrieve_odata(
    url: str,
    auth: Tuple[str, str],
    session: requests.Session,
    language: str = "en",
    max_attempts: int = 3,
) -> dict:
    """
    Retrieve data from an OData endpoint.

    Args:
        url (str): The URL of the OData endpoint.
        auth (Tuple[str, str]): Tuple containing the username and password for authentication.
        session (requests.Session): A session object for making HTTP requests.
        language (str): The language for the request. Defaults to "en".
        max_attempts (int): The maximum number of retry attempts. Defaults to 3.

    Returns:
        dict: The JSON response from the OData endpoint.
    """
    headers = {"Accept-Language": language}
    for attempt in range(max_attempts):
        try:
            result = session.get(url, auth=auth, headers=headers)
            result.raise_for_status()
            try:
                result_json = result.json()
            except json.JSONDecodeError:
                raise ValueError(f"Response is invalid JSON: {result.text}")
            try:
                result_json["d"]["results"]
            except KeyError:
                raise ValueError(f"Response does not contain ['d']['results']: {result.text}")
            return result_json
        except requests.HTTPError as e:
            if attempt < max_attempts - 1:
                sleep_time = 2**attempt  # exponential backoff
                print(
                    f"Request failed with {result.status_code}. Retrying in {sleep_time} seconds."
                )
                sleep(sleep_time)
                continue
            else:
                raise ValueError(
                    f"Status code {result.status_code} returned. Message was: {result.text}"
                ) from e


def extract_odata_full(batch_generator: List[dict], destination: str, url: str) -> int:
    """
    Extracts the full data set from an OData endpoint and writes it to `destination`.

    Args:
        batch_generator: generator instance that yields individual batches
        destination: S3 location to write results
        url: odata api url endpoint

    Returns: Number of records written
    """
    matches = re.findall(pattern, url)

    # Extract start and end dates from matches
    url_start_date = matches[0]
    url_end_date = matches[1]
    bucket, key_prefix = parse_s3_uri(destination)
    keys_written = set()

    records_received = 0

    for i, batch in enumerate(batch_generator):
        records_received += len(batch)
        zfilled_i = str(i).zfill(10)

        # Generate a unique key using execution_id and current timestamp
        key = key_prefix + f"/part_{url_start_date}_{url_end_date}_{zfilled_i}.jsonl"

        print(f"Storing to s3://{bucket}/{key}")

        s3.put_object(
            Body="\n".join(json.dumps(record) for record in batch).encode("utf-8"),
            Bucket=bucket,
            Key=key,
        )
        keys_written.add(key)
    return records_received



def retrieve_odata_generator(
    url: str, auth: Tuple[str, str] = auth, session: requests.Session = session, max_errors: int = 4
) -> List[dict]:
    """
    Generator function to retrieve data from an OData endpoint.

    Args:
        url (str): The URL of the OData endpoint.
        auth (Tuple[str, str]): Tuple containing the username and password for authentication.
        session (requests.Session): A session object for making HTTP requests.
        max_errors (int): The maximum number of errors allowed before raising an exception.
                          Defaults to 4.

    Yields:
        List[dict]: A list of dictionaries containing data retrieved from the OData endpoint.
    """
    next_url = url
    i = 0
    errors = 0
    records_received = 0
    total_bytes = 0
    start_time = datetime.now()
    previous_time = datetime.now()
    backoff = 1

    while True:
        now = datetime.now()
        print(
            f"\n---- iteration {i}, trial {errors}, total {total_bytes / 1e6} MB, "
            f"step {(now - previous_time).seconds} seconds, elapsed {now - start_time} ----"
        )

        previous_time = now

        try:
            print(f"Retrieving {next_url}")
            res = retrieve_odata(next_url, auth=auth, session=session)
            errors = 0
            backoff = 1  # Reset backoff on successful request
        except ValueError:
            if errors >= max_errors:
                raise
            errors += 1
            # Wait with exponential backoff, max 64 seconds
            sleep(backoff)
            backoff = min(64, backoff * 2)  # Double backoff, up to a maximum of 64 seconds
            continue

        this_bytes = len(json.dumps(res["d"]["results"]).encode("utf-8"))
        total_bytes += this_bytes
        records_received += len(res["d"]["results"])

        if records_received > 0:
            # print(f"Retrieved {len(res['d']['results'])} records with {this_bytes / 1e6} MB.")
            yield res["d"]["results"]

        else:
            print("No records received.")

        try:
            next_url = res["d"]["__next"]
            i += 1
        except KeyError:
            break

    if records_received > 0:
        print(
            f"Done. Retrieved a total number of {records_received} records in {i + 1} partitions "
            f"with a total size of {total_bytes / 1e6} MB. for url {url}"
        )


# Method to call functions associated to process a url
def full_load(url: str):
    """
    Process the full data load for a given URL.

    Args:
        url (str): The URL of the OData endpoint.
    """
    print(f"Processing for url {url}")
    try:
        batches = retrieve_odata_generator(url=url, auth=auth, session=session)
        print(f"Writing for url {url}")
        extract_odata_full(batches, destination,url)
        print(f"Done Writing for url {url} to s3")
    except Exception as e:
        print(f"Error processing {url}: {e}") 


# Process to divide the single api endpoint into smaller url's in order to fetch data faster
urls = []
today = datetime.now()

if start_datetime:
    start_datetime = datetime.strptime(start_datetime, "%Y-%m-%dT%H:%M:%S")
    today = start_datetime
else:
    start_datetime = today
    start_datetime = start_datetime.strftime("%Y-%m-%dT%H:%M:%S")
    start_datetime = datetime.fromisoformat(start_datetime)
    start_datetime = start_datetime.replace(hour=0, minute=0, second=0)
    start_datetime = start_datetime.isoformat()
    start_datetime = datetime.strptime(start_datetime, "%Y-%m-%dT%H:%M:%S")
    today = start_datetime

end_datetime = datetime.strptime(end_datetime, "%Y-%m-%dT%H:%M:%S")
print("start_datetime ", start_datetime)
print("end_date ", end_datetime)
print("today ", today)

while today >= end_datetime:
    start_datetime = today - timedelta(days=1)
    if start_datetime <= end_datetime:
        start_datetime = end_datetime
    start_date = start_datetime.strftime("%Y-%m-%dT%H:%M:%SZ")
    end_date = today.strftime("%Y-%m-%dT%H:%M:%SZ")
    formatted_url = (
        source
        + f"/?$format=json&$filter=({changed_column} ge datetimeoffset'{start_date}' and {changed_column} \
        le datetimeoffset'{end_date}')"
    )
    urls.append(formatted_url)
    today -= timedelta(days=1)

print("urls-->", urls)

# Make API calls in parallel using ThreadPoolExecutor
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    for url in urls:
        future = executor.submit(full_load, url)
        futures.append(future)
    concurrent.futures.wait(futures)
print("process full load done")
