"""Marketo bulk extraction process."""

import argparse
import json
from datetime import datetime

import boto3
from marketo import create_extract_ranges, retrieve_job_results
from marketorestpython.client import MarketoClient
from utils import parse_s3_uri, recursive_s3_delete

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")

parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument(
    "--source",
    dest="source",
    help="Source bulk extract (activities or leads)",
    choices=["activities", "leads"],
)
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
parser.add_argument(
    "--changed-column", dest="changed_column", help="Column containing the `changed on` timestamp"
)
parser.add_argument(
    "--discard-history-on-full-extract",
    dest="discard",
    action="store_true",
    help="Deletes all delta extracts when doing another full extract",
)
parser.add_argument(
    "--force-full-extract", dest="force", help="Force full extract", action="store_true"
)
args = parser.parse_known_args()[0]

secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="data-lake-adobe-marketo")[
        "SecretString"
    ]
)
client = MarketoClient(secret["munchkin_id"], secret["client_id"], secret["client_secret"])

# Used for for delta updates via DynamoDB table
now = datetime.utcnow()
timestamp = now.isoformat().split(".")[0] + "Z"

# For createdAt filter:
# START_DATE = datetime(2019, 10, 1)

# For updatedAt filter:
START_DATE = datetime(2020, 6, 1)

last = table.get_item(Key={"job_name": args.job_name}).get("Item", None)

if last and not args.force:
    last_import = last.get("last_import", None)
    last_full_import = last.get("last_full_import", None)
else:
    last_import = timestamp
    last_full_import = timestamp

print(f"Last import: {last_import}, last full import: {last_full_import}.")


if last and not args.force:
    print("Performing Delta Extract")
    destination = f"{args.destination}/delta"

    job_filters = [{"updatedAt": {"startAt": last_import, "endAt": timestamp}}]
    job_statuses, records = retrieve_job_results(
        client=client,
        job_filters=job_filters,
        destination=f"{args.destination}/delta/",
        method_type=args.source,
    )

else:
    print("Performing Full Extract")
    extract_ranges = create_extract_ranges(start_datetime=START_DATE, end_datetime=now)
    job_filters = [{"updatedAt": extract_range} for extract_range in extract_ranges]

    job_statuses, records = retrieve_job_results(
        client=client,
        job_filters=job_filters,
        destination=f"{args.destination}/full/",
        method_type=args.source,
    )

    if args.discard:
        bucket, prefix = parse_s3_uri(args.destination)
        recursive_s3_delete(bucket, prefix + "/delta")

table.put_item(
    Item={
        "last_import": timestamp,
        "last_full_import": last_full_import,
        "job_name": args.job_name,
        "records_received": records,
    }
)
