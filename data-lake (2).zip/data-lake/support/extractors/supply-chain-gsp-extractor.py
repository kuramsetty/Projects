"""Does a CDC extract (incremental) from gsp endpoint. Results are written to S3 in JSON format."""

import argparse
import json
from datetime import datetime
from time import sleep

import boto3
import requests
from utils import parse_s3_uri

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")

parser = argparse.ArgumentParser(description="Ingest data from GSP APIs")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
args = parser.parse_known_args()[0]

s3 = boto3.client("s3")
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="supply-chain-apac-gsp")[
        "SecretString"
    ]
)
prod_auth = {"Authorization": f"TOKEN {secret['token']}"}

# Used for DynamoDB table updates
now = datetime.utcnow()
timestamp = now.isoformat().split(".")[0]


def extract_supply_chain_gsp_api(url, destination, max_errors=3):
    """
    Extracts data from a Supply Chain GSP (Global Service Provider) API endpoint and stores it in an S3 bucket.

    Args:
        url (str): The URL of the Supply Chain GSP API endpoint.
        destination (str): The destination S3 URI where the extracted data will be stored.
        max_errors (int, optional): The maximum num of consecutive errors allowed before stopping extraction.
            Defaults to 3.

    Returns:
        int: The total number of records received and stored in S3.
    """
    records_received = 0
    errors = 0
    page = 1
    res = requests.get(  # noqa: S113
        f"{url}?page_size=200&page={page}", headers=prod_auth, verify=False  # noqa: S501
    )
    while res.links.get('next">'):
        # status_error = 0
        try:
            print(f"{url}?page_size=200&page={page}")
            res = requests.get(  # noqa: S113
                f"{url}?page_size=200&page={page}", headers=prod_auth, verify=False  # noqa: S501
            )
            print(f"GET Api Response::{res.status_code}")
            if res.status_code == 200:  # noqa: PLR2004
                response = res.json()

                records_received += len(response)

                bucket, key = parse_s3_uri(destination)
                target_key = f"{key}/page_id={page}/data.jsonl"
                s3.put_object(
                    Body="\n".join(json.dumps(elem) for elem in response),
                    Bucket=bucket,
                    Key=target_key,
                )
                print(f"destination path: s3://{bucket}/{target_key}")
                page += 1
                sleep(10)
            else:
                raise ValueError(
                    f"printing failed status code::, {res.status_code} with error message:: {res.text} for \
                        page: {page}"
                )
        except NameError:
            if errors >= max_errors:
                raise
            errors += 1
            sleep(4)
            continue

    return records_received


print("Performing Full Extract")
records = extract_supply_chain_gsp_api(url=secret["url"], destination=args.destination)

table.put_item(
    Item={
        "last_import": timestamp,
        "job_name": args.job_name,
        "records_received": records,
    }
)
