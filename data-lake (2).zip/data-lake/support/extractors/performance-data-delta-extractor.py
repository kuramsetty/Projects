"""Does a full export (entire collection)from OData endpoint. Results written to S3 in JSON format."""

import argparse
import json
from datetime import datetime, timedelta
from time import sleep
from urllib.parse import urlparse

import boto3
import requests
from dateutil.relativedelta import relativedelta

parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--source", dest="source", help="Source URI of OData endpoint")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
parser.add_argument("--load", dest="load", help="full load or delta load")
args = parser.parse_known_args()[0]

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")


def get_all_s3_objects(s3, **base_kwargs):
    """
    Retrieve a list of all objects in an S3 bucket, handling pagination automatically.

    Args:
        s3 (boto3.client): An initialized boto3 S3 client object.
        **base_kwargs (Any): Additional keyword arguments to be passed to the list_objects_v2 method.

    Returns:
        List[Dict[str, Any]]: A list of dictionaries representing the retrieved S3 objects.
    """
    objects = []
    continuation_token = None
    while True:
        list_kwargs = dict(MaxKeys=1000, **base_kwargs)
        if continuation_token:
            list_kwargs["ContinuationToken"] = continuation_token
        response = s3.list_objects_v2(**list_kwargs)
        if response.get("Contents", []):
            objects.extend(response["Contents"])
        # yield from response.get('Contents', [])
        if not response.get("IsTruncated"):  # At the end of the list?
            break
        continuation_token = response.get("NextContinuationToken")
    return objects


def retrieve_odata(url, auth, language="en"):
    """
    Retrieves a single response from an OData endpoint.

    Args:
        url (str): OData Endpoint URL
        auth (dict): 2-tuple of (username, password)
        language (str): default en

    Returns: Dictionary containing the OData response

    """
    headers = {"Accept-Language": language}
    result = requests.get(url, auth=auth, headers=headers)  # noqa: S113
    if result.status_code != 200:  # noqa: PLR2004
        raise ValueError(f"Status code {result.status_code} returned. Message was: {result.text}")

    try:
        result_json = result.json()
    except json.JSONDecodeError:
        raise ValueError(f"Response is invalid JSON: {result.text}")

    try:
        result_json["d"]["results"]
    except KeyError:
        raise ValueError(f"Response does not contain ['d']['results']: {result.text}")

    return result_json


def retrieve_odata_generator(url, auth, max_errors=4):
    """
    Iteratively retrieves OData responses by following the `__next` link in each response.

    Args:
        url: OData Endpoint URL
        auth: 2-tuple of (username, password)
        max_errors: maximum number of failed retries

    Returns: Python generator for each OData chunk

    """
    next_url = url
    i = 0
    errors = 0
    records_received = 0
    total_bytes = 0
    start_time = datetime.now()
    previous_time = datetime.now()

    while True:
        now = datetime.now()

        print(
            f"\n---- iteration {i}, trial {errors}, total {total_bytes / 1e6} MB, "
            f"step {(now - previous_time).seconds} seconds, elapsed {now - start_time} ----"
        )
        previous_time = now

        print(f"Retrieving {url}")
        try:
            res = retrieve_odata(next_url, auth=auth)
            errors = 0
        except ValueError:
            if errors >= max_errors:
                raise
            errors += 1
            sleep(4)
            continue

        this_bytes = len(json.dumps(res["d"]["results"]).encode("utf-8"))
        total_bytes += this_bytes
        records_received += len(res["d"]["results"])

        if records_received > 0:
            print(f"Retrieved {len(res['d']['results'])} records with {this_bytes / 1e6} MB.")
            yield res["d"]["results"]

        else:
            print("No records received.")

        try:
            next_url = res["d"]["__next"]
            i += 1
        except KeyError:
            break

    if records_received > 0:
        print("")
        print(
            f"Done. Retrieved a total number of {records_received} records in {i + 1} partitions "
            f"with a total size of {total_bytes / 1e6} MB."
        )


def extract_odata_full(batch_generator, destination, cleanup=True):
    """
    Extracts the full data set from an OData endpoint and writes it to `destination`.

    Args:
        batch_generator: generator instance that yields individual batches
        destination: S3 location to write results to
        cleanup: Clean up (delete) parts that were downloaded by a previous run of this job

    Returns: Number of records written

    """
    bucket, key_prefix = parse_s3_uri(destination)
    keys_written = set()

    records_received = 0

    for i, batch in enumerate(batch_generator):
        records_received += len(batch)
        zfilled_i = str(i).zfill(10)
        key = key_prefix + f"/part_{zfilled_i}.jsonl"

        print(f"Storing to s3://{bucket}/{key}")

        s3.put_object(
            Body="\n".join(json.dumps(record) for record in batch).encode("utf-8"),
            Bucket=bucket,
            Key=key,
        )
        keys_written.add(key)

    # if cleanup:
    #     print("")
    #     try:
    #         existing_objects = get_all_s3_objects(s3=s3, Bucket=bucket, Prefix=f"{key_prefix}/")
    #     except KeyError:
    #         existing_objects = []

    #     for existing_object in existing_objects:
    #         existing_key = existing_object["Key"]
    #         if existing_key not in keys_written:
    #             print(f"WARNING: s3://{bucket}/{existing_key} exists, but was not
    # written by this job; deleting.")
    #             s3.delete_object(Bucket=bucket, Key=existing_key)

    return records_received


def parse_s3_uri(s):
    """
    Parses an S3 URI into bucket name and object key.

    Args:
        s: string to parse

    Returns: 2-tuple with (bucket, key)

    """
    bucket = urlparse(s).netloc
    key = urlparse(s).path[1:]

    return bucket, key


secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(
        SecretId="sap-c4c/TicketIntelligence_Performance"
    )["SecretString"]
)
auth = (secret["username"], secret["password"])


# Used for for delta updates via DynamoDB table
timestamp = datetime.utcnow().isoformat().split(".")[0] + "Z"

last = table.get_item(Key={"job_name": args.job_name}).get("Item", None)

if last:
    last_import = last.get("last_import", None)
    last_full_import = last.get("last_full_import", None)
else:
    last_import = timestamp
    last_full_import = timestamp

print(f"Last import: {last_import}, last full import: {last_full_import}.")

records_received = 0

if args.load == "full":
    # start_date = '2023-03-10T00:00:00'
    last_import = "2023-03-10T02:42:36"
    start_date = (datetime.strptime(last_import, "%Y-%m-%dT%H:%M:%S") + timedelta(days=1)).strftime(
        "%Y-%m-%dT%H:%M:%S"
    )
    while datetime.strptime(start_date, "%Y-%m-%dT%H:%M:%S") < datetime.now() - relativedelta(
        days=1
    ):
        end_date = (
            datetime.strptime(start_date, "%Y-%m-%dT%H:%M:%S")
            + relativedelta(days=1)
            - timedelta(days=1)
        ).strftime("%Y-%m-%dT%H:%M:%S")

        url = (
            f"https://my343420.crm.ondemand.com/sap/c4c/odata/analytics/ds/CodRespTimeAna.svc/CodRespTimeAna?\
            $select=U_UnitCode,C_Browser,C_OsVersion,C_BrowserVersion,C_Timestamp,C_ScreenNameTech,\
            C_DeviceType,C_Woc,C_User,C_IpAddress,C_ScreenName,C_Time,C_UiStep,C_UiStepType,C_HourSlot,\
            C_MinSlot,C_WocvId,C_CalWeek,C_CalDay,C_ColdStartInd,C_ClientType,C_Os,to_CalDay/C_YearId,\
            to_CalDay/C_YearMonth,to_CalDay/C_YearQuarter,to_CalDay/C_Weekday,to_CalDay/C_QuarterId,\
            to_CalDay/C_MonthId,to_CalDay/C_GregDate,to_CalDay/C_YearWeek,to_CalDay/C_DayId,to_CalDay/Count,\
            Count,K_Tti,K_BrfProcTime,K_WsProcTime,K_NoOfRoundtrips,K_ClientTime,K_NetworkTime,K_ServerTime,\
            K_PdiProcTime,K_WfProcTime&$expand=to_CalDay&$filter=(C_CalDay eq datetime%27{start_date}%27)&$format=json"
        )
        print("url", url)
        batches = retrieve_odata_generator(url=url, auth=auth)
        destination = f"{args.destination}/x_etl_start_date={start_date}"
        records_received = extract_odata_full(batch_generator=batches, destination=destination)
        start_date = (
            datetime.strptime(end_date, "%Y-%m-%dT%H:%M:%S") + timedelta(days=1)
        ).strftime("%Y-%m-%dT%H:%M:%S")


elif args.load == "delta":
    # end_date = datetime.now()
    # dt = datetime.strptime(str(d), '%Y-%m-%d %H:%M:%S.%f')
    # start_date = dt + timedelta(hours=-1)
    print("***Delta Load***")
    start_date = (datetime.now()).strftime("%Y-%m-%dT%H:%M:%S")

    url = (
        f"https://my343420.crm.ondemand.com/sap/c4c/odata/analytics/ds/CodRespTimeAna.svc/CodRespTimeAna?"\
        f"$select=U_UnitCode,C_Browser,C_OsVersion,C_BrowserVersion,C_Timestamp,C_ScreenNameTech,"\
        f"C_DeviceType,C_Woc,C_User,C_IpAddress,C_ScreenName,C_Time,C_UiStep,C_UiStepType,C_HourSlot,"\
        f"C_MinSlot,C_WocvId,C_CalWeek,C_CalDay,C_ColdStartInd,C_ClientType,C_Os,to_CalDay/C_YearId,"\
        f"to_CalDay/C_YearMonth,to_CalDay/C_YearQuarter,to_CalDay/C_Weekday,to_CalDay/C_QuarterId,"\
        f"to_CalDay/C_MonthId,to_CalDay/C_GregDate,to_CalDay/C_YearWeek,to_CalDay/C_DayId,to_CalDay/Count,"\
        f"Count,K_Tti,K_BrfProcTime,K_WsProcTime,K_NoOfRoundtrips,K_ClientTime,K_NetworkTime,K_ServerTime,"\
        f"K_PdiProcTime,K_WfProcTime&$expand=to_CalDay&$filter=(C_CalDay eq datetime%27{start_date}%27)&$format=json"
    )
    print("url", url)
    batches = retrieve_odata_generator(url=url, auth=auth)
    destination = f"{args.destination}/x_etl_start_date={start_date}"
    records_received = extract_odata_full(batch_generator=batches, destination=destination)
# start_date = (datetime.strptime(end_date, '%Y-%m-%dT%H:%M:%S')+
# timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%S")


table.put_item(
    Item={
        "last_import": timestamp,
        "last_full_import": last_full_import,
        "job_name": args.job_name,
        # 'records_received': records_received,
    }
)
