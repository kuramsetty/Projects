"""Marketo activity extraction process."""

import argparse
import json
from datetime import datetime

import boto3
from marketo import extract_activities
from marketorestpython.client import MarketoClient

s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")

parser = argparse.ArgumentParser(description="Ingest data from Marketo Activities")
# parser.add_argument('--source', dest='source', help="Source Marketo activities extract")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
parser.add_argument(
    "--force-full-extract", dest="force", help="Force full extract", action="store_true"
)
args = parser.parse_known_args()[0]

s3 = boto3.client("s3")
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="data-lake-adobe-marketo")[
        "SecretString"
    ]
)
client = MarketoClient(secret["munchkin_id"], secret["client_id"], secret["client_secret"])


# Used for for delta updates via DynamoDB table
now = datetime.utcnow()
timestamp = now.isoformat().split(".")[0] + "Z"

# For updatedAt filter:
START_DATE = datetime(2020, 4, 1).isoformat().split(".")[0] + "Z"
# activity_type_id = 1 #Loop over 57
last = table.get_item(Key={"job_name": args.job_name}).get("Item", None)

if last and not args.force:
    last_import = last.get("last_import", None)
    last_full_import = last.get("last_full_import", None)
else:
    last_import = timestamp
    last_full_import = timestamp

print(f"Last import: {last_import}, last full import: {last_full_import}.")

if last and not args.force:
    print("Performing Delta Extract")
    destination = f"{args.destination}/delta"
    records = extract_activities(
        client=client, destination=destination, start_date=last_import, end_date=timestamp
    )

else:
    print("Performing Full Extract")
    records = extract_activities(
        client=client,
        destination=f"{args.destination}/full",
        start_date=START_DATE,
        end_date=timestamp,
    )


table.put_item(
    Item={
        "last_import": timestamp,
        "last_full_import": last_full_import,
        "job_name": args.job_name,
        "records_received": records,
    }
)
