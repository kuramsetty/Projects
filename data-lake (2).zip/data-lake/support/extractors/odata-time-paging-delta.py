"""Does a CDC extract (incremental) from OData endpoint. Results are written to S3 in JSON format."""

# The way this works is as follows:
#   1. A full extract is done once and written to a bucket into a full/ subdirectory. The datetime boundary is
#      saved in a DynamoDB table. In the case of a full extract, we filter the data up to the the datetime
#      when the full extract starts.
#   2. A delta extract is done by filtering the OData query such that only records are returned that have been
#      changed since the last time we performed a query. Once the delta extract is done, we write the datetime
#      stamp to a DynamoDB and use it in the next delta extract.

import argparse
import json
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from time import sleep

import boto3
import requests
from utils import parse_s3_uri

parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--source", dest="source", help="Source URI of OData endpoint")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
args = parser.parse_known_args()[0]

s3 = boto3.client("s3")
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(
        SecretId="sap-c4c/TicketIntelligence_Performance"
    )["SecretString"]
)
print("printing---------------->", secret)
auth = (secret["username"], secret["password"])
# auth = (secret['_DATELAKEODA'],secret['9FMjkCSeQ8zs47lXGYc0'])


def get_all_s3_objects(s3, **base_kwargs):
    """
    Retrieve a list of all objects in an S3 bucket, handling pagination automatically.

    Args:
        s3 (boto3.client): An initialized boto3 S3 client object.
        **base_kwargs (Any): Additional keyword arguments to be passed to the list_objects_v2 method.

    Returns:
        List[Dict[str, Any]]: A list of dictionaries representing the retrieved S3 objects.
    """
    objects = []
    continuation_token = None
    while True:
        list_kwargs = dict(MaxKeys=1000, **base_kwargs)
        if continuation_token:
            list_kwargs["ContinuationToken"] = continuation_token
        response = s3.list_objects_v2(**list_kwargs)
        if response.get("Contents", []):
            objects.extend(response["Contents"])
        # yield from response.get('Contents', [])
        if not response.get("IsTruncated"):  # At the end of the list?
            break
        continuation_token = response.get("NextContinuationToken")
    return objects


def retrieve_odata(url, auth, session, language="en", max_attempts=3):
    """
    Retrieves OData from a given URL using the provided authentication and session.

    Args:
        url (str): The URL of the OData service.
        auth (AuthBase): The authentication method to be used in the request.
        session (Session): The session object to be used for the request.
        language (str, optional): The language for the Accept-Language header. Defaults to "en".
        max_attempts (int, optional): The maximum number of retry attempts in case of failure. Defaults to 3.

    Returns:
        dict: The JSON response containing the OData retrieved from the URL.

    Raises:
        ValueError: If the response is not valid JSON or does not contain the expected structure.
        ValueError: If the maximum number of retry attempts is reached and the request still fails.
    """
    headers = {"Accept-Language": language}
    for attempt in range(max_attempts):
        try:
            result = session.get(url, auth=auth, headers=headers)
            result.raise_for_status()

            try:
                result_json = result.json()
            except json.JSONDecodeError:
                raise ValueError(f"Response is invalid JSON: {result.text}")

            try:
                result_json["d"]["results"]
            except KeyError:
                raise ValueError(f"Response does not contain ['d']['results']: {result.text}")

            return result_json

        except requests.HTTPError as e:
            if attempt < max_attempts - 1:
                sleep_time = 2**attempt  # exponential backoff
                print(
                    f"Request failed with {result.status_code}. Retrying in {sleep_time} seconds."
                )
                sleep(sleep_time)
                continue
            else:
                raise ValueError(
                    f"Status code {result.status_code} returned. Message was: {result.text}"
                ) from e


def extract_odata_full(batch_generator, destination, cleanup=True):
    """
    Extracts data from a batch generator and stores it in JSON Lines format in S3.

    Args:
        batch_generator (generator): A generator yielding batches of data to be extracted.
        destination (str): The S3 URI where the extracted data will be stored.
        cleanup (bool, optional): If True, performs cleanup by deleting S3 objects that were not written
            by the current job. Defaults to True.

    Returns:
        int: The total number of records received and stored in S3.

    """
    bucket, key_prefix = parse_s3_uri(destination)
    keys_written = set()

    records_received = 0
    k = 0

    def store_to_s3(batch):
        zfilled_i = str(k + i).zfill(10)
        key = key_prefix + f"/part_{zfilled_i}.jsonl"

        print(f"Storing to s3://{bucket}/{key}")

        s3.put_object(
            Body="\n".join(json.dumps(record) for record in batch).encode("utf-8"),
            Bucket=bucket,
            Key=key,
        )
        keys_written.add(key)

    executor = ThreadPoolExecutor(max_workers=10)

    for i, batch in enumerate(batch_generator):
        records_received += len(batch)

        # Store to S3 concurrently
        executor.submit(store_to_s3, batch)

    # if cleanup:
    #     print("")
    #     try:
    #         existing_objects = get_all_s3_objects(s3=s3, Bucket=bucket, Prefix=f"{key_prefix}/")
    #     except KeyError:
    #         existing_objects = []

    #     for existing_object in existing_objects:
    #         existing_key = existing_object["Key"]
    #         if existing_key not in keys_written:
    #             print(f"WARNING: s3://{bucket}/{existing_key} exists, but was not \
    #              written by this job; deleting.")
    #             s3.delete_object(Bucket=bucket, Key=existing_key)

    return records_received


def retrieve_odata_generator(url, auth, session, max_errors=4):
    """
    Iteratively retrieves OData responses by following the `__next` link in each response.

    Args:
        url: OData Endpoint URL
        auth: 2-tuple of (username, password)
        session: request session
        max_errors: maximum number of failed retries

    Returns: Python generator for each OData chunk

    """
    next_url = url
    i = 0
    errors = 0
    records_received = 0
    total_bytes = 0
    start_time = datetime.now()
    previous_time = datetime.now()
    backoff = 1

    while True:
        now = datetime.now()

        print(
            f"\n---- iteration {i}, trial {errors}, total {total_bytes / 1e6} MB, "
            f"step {(now - previous_time).seconds} seconds, elapsed {now - start_time} ----"
        )

        previous_time = now

        print(f"Retrieving {url}")
        try:
            res = retrieve_odata(next_url, auth=auth, session=session)
            errors = 0
            backoff = 1  # Reset backoff on successful request
        except ValueError:
            if errors >= max_errors:
                raise
            errors += 1
            # Wait with exponential backoff, max 64 seconds
            sleep(backoff)
            backoff = min(64, backoff * 2)  # Double backoff, up to a maximum of 64 seconds
            continue

        this_bytes = len(json.dumps(res["d"]["results"]).encode("utf-8"))
        total_bytes += this_bytes
        records_received += len(res["d"]["results"])

        if records_received > 0:
            print(f"Retrieved {len(res['d']['results'])} records with {this_bytes / 1e6} MB.")
            yield res["d"]["results"]

        else:
            print("No records received.")

        try:
            next_url = res["d"]["__next"]
            i += 1
        except KeyError:
            break

    if records_received > 0:
        print("")
        print(
            f"Done. Retrieved a total number of {records_received} records in {i + 1} partitions "
            f"with a total size of {total_bytes / 1e6} MB."
        )


url = args.source + "&$format=json"

# Reuse Connection
session = requests.Session()
batches = retrieve_odata_generator(url=url, auth=auth, session=session)
records_received = extract_odata_full(batch_generator=batches, destination=args.destination)
