"""Does extract of data from kapost api for users and write them into s3 bucket."""

import argparse
import json
from datetime import datetime
from time import sleep
from typing import Dict, List

import boto3
import requests
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from utils import parse_s3_uri


def extract_kapost_users_api(  # noqa: PLR0913
    url: str,
    destination: str,
    endpoint: str,
    users_list: List[str],
    secret: Dict[str, str],
    max_errors: int = 3,
) -> int:
    """
    Extracts data for a list of users from a Kapost API endpoint and uploads it to an S3 destination.

    Args:
        url (str): The base URL of the Kapost API.
        destination (str): The S3 URI where the extracted data will be uploaded.
        endpoint (str): The specific API endpoint to extract data from.
        users_list (List[str]): A list of user IDs for which data will be extracted.
        secret (Dict[str, str]): A dictionary containing the secret credentials needed for API authentication.
        max_errors (int, optional): The maximum number of errors allowed per user before raising an exception.
            Defaults to 3.

    Returns:
        int: The total number of records received and uploaded to S3.
    """
    records_received = 0
    errors = 0
    for user in users_list:
        try:
            print(f"{url}/{endpoint}")
            res = requests.get(  # noqa: S113
                f"{url}/{endpoint}/{user}", auth=(secret["api_key"], "x")
            )
            print(f"GET Api Response::{res.status_code}")

            errors = 0
            while errors < max_errors and res.status_code != 200:  # noqa: PLR2004
                print(f"printing error message::{res.text} for user id:{user}")
                errors += 1
                res = requests.get(  # noqa: S113
                    f"{url}/{endpoint}/{user}", auth=(secret["api_key"], "x")
                )
                raise ValueError("Returned non 200 status code!")

            res = res.json()
            response = res["response"]
            records_received += len(response)

            bucket, key = parse_s3_uri(destination)
            print(f"storing user # {user}.")
            target_key = f"{key}/user_id={user}/data.json"
            s3.put_object(Body=json.dumps(response), Bucket=bucket, Key=target_key)
            print(f"destination path: s3://{bucket}/{target_key}")
            sleep(30)
        except NameError:
            if errors >= max_errors:
                raise
            errors += 1
            sleep(4)
            continue

    return records_received


s3 = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="kapost-api-key")["SecretString"]
)

parser = argparse.ArgumentParser(description="Ingest data from Kapost")
parser.add_argument("--source", dest="source", help="Source Kapost endpoint")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
parser.add_argument(
    "--force-full-extract", dest="force", help="Force full extract", action="store_true"
)
args = parser.parse_known_args()[0]

# Used for DynamoDB table updates
now = datetime.utcnow()
timestamp = now.isoformat().split(".")[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.job_name)

df = spark.read.parquet(args.source)
users = df.select(df.creator_id).union(df.select(df.assignee_id))
distinct_users = users.distinct().toPandas().dropna()

try:
    print("Performing Full Extract")
    records = extract_kapost_users_api(
        url=secret["url"],
        destination=args.destination,
        endpoint="users",
        users_list=distinct_users["creator_id"],
        secret=secret,
    )

    table.put_item(
        Item={
            "last_import": timestamp,
            "job_name": args.job_name,
            "records_received": records,
        }
    )
except Exception as e:
    # Handle exceptions
    print(f"An error occurred: {e}")

job.commit()
