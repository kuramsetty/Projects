"""Does khoros extract from khoros api and write the results into s3 in .csv format."""

import argparse
import concurrent.futures
import io
import json
import time
from datetime import datetime
from io import StringIO
from urllib.parse import urlparse

import boto3
import pandas as pd
import requests

parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--job-name", dest="job_name", help="Name of this job (used for DynamoDB metadata)"
)
args = parser.parse_known_args()[0]

today = datetime.today()
formatted_date = today.strftime("%Y-%m-%d")
print("formatted_date ->", formatted_date)

s3 = boto3.client("s3")
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="KhorosCred")["SecretString"]
)

access_token = secret["access_token"]


def khoros_export_function(access_token: str, khoros: dict) -> dict:
    """
    Perform Khoros export operation.

    Args:
        access_token (str): Access token for authentication.
        khoros (dict): Dictionary containing Khoros export details.

    Returns:
        dict: Export summary containing export ID.
    """
    key = list(khoros.keys())[0]
    value = list(khoros.values())[0]
    base_url = "https://api.spredfast.com/v2/analytics/export/" + value
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
    fields = khoros_field_list[key]

    # The payload may contain any required parameters for the API request
    payload = {
        "query": {
            "start": "2022-01-01",
            "stop": formatted_date,
            "fields": fields,
            #             "fields": [353]
        }
    }
    print("base_url-->", base_url)
    response = requests.post(base_url, headers=headers, json=payload)  # noqa: S113
    if response.status_code == 200:  # noqa: PLR2004
        print("success")
        return response.json()
    else:
        print(
            f"Failed to get data from {base_url}. Status code: {response.status_code} response.text \
                {response.text}"
        )
        return None


def get_export_results(access_token: str, export_id: str) -> dict:
    """
    Get export results from Khoros.

    Args:
        access_token (str): Access token for authentication.
        export_id (str): Export ID for retrieving export results.

    Returns:
        dict: Export results.
    """
    base_url = f"https://api.spredfast.com/v2/analytics/export/{export_id}/status"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}

    response = requests.get(base_url, headers=headers)  # noqa: S113

    if response.status_code == 200:  # noqa: PLR2004
        return response.json()
    else:
        print(f"Failed to get export results from {base_url}. Status code: {response.status_code}")
        return None


def export_status(access_token: str, export_id: str, khoros: dict) -> None:
    """
    Check and update export status.

    Args:
        access_token (str): Access token for authentication.
        export_id (str): Export ID for retrieving export status.
        khoros (dict): Dictionary containing Khoros export details.
    """
    export_results = get_export_results(access_token, export_id)
    status = export_results["status"]

    if status == "incomplete":
        print("status", status)
        time.sleep(20)
        export_status(access_token, export_id, khoros)
    else:
        print("status-", status, list(khoros.keys())[0])

        key = list(khoros.keys())[0]

        s3_csv_url = export_results["url"]
        save_csv(key, s3_csv_url)
    status = export_results["status"]


# Replace 'your-s3-csv-file-link' with the actual pre-signed URL or direct link
# s3_csv_url = 'https://your-s3-csv-file-link.csv'


def save_csv(key: str, s3_csv_url: str) -> None:
    """
    Save CSV file from provided URL.

    Args:
        key (str): Key for identifying the CSV file.
        s3_csv_url (str): URL of the CSV file.

    Returns:
        None
    """
    #   local_file_path = 'local-file.csv'
    # local_file_path = key + ".csv"

    try:
        # Send an HTTP GET request to the S3 URL
        response = requests.get(s3_csv_url)  # noqa: S113

        # Check if the request was successful (status code 200)
        if response.status_code == 200:  # noqa: PLR2004
            try:
                # Save the CSV content to a local file
                # with open(local_file_path, "wb") as local_file:

                urlData = response.content
                #                     print(urlData)
                df = pd.read_csv(io.StringIO(urlData.decode("utf-8")))

                # cols = list(df.columns)

                csv_buf = StringIO()
                df.to_csv(csv_buf, encoding="utf-8", index=False, columns=df.columns, sep="\t")
                csv_buf.seek(0)

                filepath = urlparse(args.destination).path[1:] + "/" + key + ".csv"

                s3.put_object(
                    Body=csv_buf.getvalue(),
                    Bucket=urlparse(args.destination).netloc,
                    Key=filepath,
                )
                print(f"File written successful to {filepath}")
            except Exception as e:
                print(f"error {e}")

        else:
            print(f"Failed to download. Status code: {response.status_code}")

    except requests.exceptions.RequestException as e:
        print(f"An error occurred: {e}")


khoros_list = [
    {"daily_account_level_export": "accounts"},
    {"published_posts_export": "posts"},
    {"daily_post_summary_export": "daily_post_summary"},
    #  {'customer_feedback_export':'customer_feedback'},
    #  {'stream_item_export':'stream_items'},
    #  {'stream_item_action_export':'stream_item_actions'},
    {"ads_net_values_export": "net_ads"},
    # {'profiles_export':'profiles'}
]

khoros_field_list = {
    "daily_account_level_export": [
        0,
        1,
        14,
        15,
        16,
        17,
        20,
        21,
        24,
        25,
        27,
        28,
        33,
        34,
        35,
        36,
        38,
        39,
        41,
        42,
        207,
        208,
        209,
        210,
        211,
        212,
        213,
        214,
        277,
        278,
        340,
        341,
    ],
    "published_posts_export": [
        44,
        45,
        46,
        47,
        48,
        49,
        50,
        51,
        52,
        53,
        54,
        55,
        56,
        57,
        58,
        59,
        60,
        61,
        62,
        63,
        64,
        65,
        66,
        67,
        68,
        69,
        70,
        71,
        72,
        73,
        74,
        75,
        76,
        77,
        78,
        79,
        80,
        81,
        82,
        83,
        84,
        85,
        86,
        87,
        88,
        89,
        90,
        91,
        92,
        93,
        94,
        95,
        96,
        97,
        98,
        99,
        100,
        101,
        102,
        103,
        104,
        105,
        106,
        107,
        108,
        109,
        110,
        111,
        112,
        113,
        114,
        115,
        116,
        117,
        118,
        119,
        120,
        121,
        122,
        124,
        125,
        130,
        131,
        132,
        133,
        134,
        135,
        136,
        138,
        139,
        140,
        141,
        142,
        143,
        144,
        146,
        147,
        148,
        150,
        151,
        153,
        154,
        155,
        156,
        159,
        203,
        204,
        205,
        206,
        219,
        220,
        221,
        222,
        231,
        232,
        233,
        240,
        241,
        242,
        243,
        244,
        245,
        246,
        247,
        248,
        274,
        282,
        283,
        284,
        290,
        291,
        293,
        294,
        295,
        296,
        297,
        298,
        299,
        303,
        304,
        305,
        306,
        307,
        308,
        309,
        310,
        311,
        312,
        313,
        314,
        315,
        316,
        317,
        318,
        319,
        320,
        321,
        322,
        323,
        324,
        326,
        328,
        329,
        330,
        331,
        332,
        333,
        334,
        335,
        336,
        337,
        338,
        339,
        342,
        343,
        350,
        351,
        352,
        353,
    ],
    "daily_post_summary_export": [
        78,
        79,
        80,
        81,
        82,
        83,
        84,
        85,
        108,
        110,
        111,
        112,
        113,
        114,
        115,
        116,
        117,
        118,
        119,
        120,
        121,
        122,
        130,
        131,
        132,
        133,
        134,
        135,
        136,
        138,
        139,
        140,
        141,
        142,
        143,
        144,
        146,
        147,
        148,
        150,
        151,
        153,
        154,
        155,
        156,
        219,
        220,
        221,
        222,
        231,
        232,
        233,
        240,
        241,
        242,
        244,
        245,
        246,
        247,
        248,
        274,
        290,
        291,
        293,
        294,
        295,
        296,
        297,
        298,
        299,
        303,
        304,
        305,
        306,
        307,
        308,
        309,
        310,
        311,
        312,
        313,
        314,
        315,
        316,
        317,
        318,
        319,
        320,
        321,
        323,
        324,
        326,
        329,
        330,
        331,
        333,
        334,
        335,
        336,
        342,
        343,
        350,
        351,
        352,
        353,
    ],
    "customer_feedback_export": [47, 51, 70, 167, 169, 186, 197, 198, 279, 280, 281],
    "stream_item_export": [
        47,
        51,
        54,
        57,
        70,
        164,
        165,
        166,
        167,
        169,
        184,
        185,
        186,
        187,
        188,
        189,
        190,
        191,
        192,
        193,
        194,
        195,
        196,
        197,
        198,
        199,
        200,
        201,
        237,
        286,
        287,
        288,
        289,
        300,
        301,
        302,
        325,
        327,
        400,
    ],
    "stream_item_action_export": [
        47,
        51,
        54,
        70,
        160,
        164,
        165,
        167,
        168,
        169,
        170,
        171,
        173,
        174,
        175,
        176,
        177,
        178,
        179,
        180,
        183,
        185,
        186,
        187,
        188,
        191,
        200,
        201,
        287,
        288,
        289,
        300,
        301,
        302,
        325,
        327,
        400,
    ],
    "ads_net_values_export": [
        54,
        63,
        66,
        70,
        283,
        15001,
        15002,
        15003,
        15004,
        15005,
        15006,
        15007,
        15009,
        15010,
        15012,
        15013,
        15014,
        15016,
        15017,
        15020,
        15022,
        15023,
        15024,
        15025,
        15026,
        15030,
        15037,
        15038,
        15042,
        15045,
        15046,
        15049,
        15050,
        15051,
        15052,
        15053,
        15054,
        15055,
        15056,
        15057,
        15058,
        15059,
        15060,
        15061,
        15062,
        15063,
        15064,
        15065,
        15066,
        15067,
        15068,
        15069,
        15070,
        15071,
        15072,
        15073,
        15074,
        15075,
        15076,
        15077,
        15078,
        15079,
        15080,
        15081,
        15082,
        15083,
        15084,
        15085,
        15086,
        15087,
        15088,
        15089,
        15090,
        15091,
        15092,
        15093,
        15094,
        15095,
        15096,
        15097,
        15098,
        15099,
        15100,
        15101,
        15102,
        15103,
        15104,
        15105,
        20000,
        20001,
        20002,
        20003,
        20004,
        20005,
        20006,
        20007,
        20008,
        20009,
        20011,
        20013,
        20014,
        20015,
        20016,
        20017,
        20018,
        20019,
        20020,
        20021,
        20024,
        20025,
        20026,
        20027,
        20028,
    ],
    "profiles_export": [
        54,
        400,
        401,
        402,
        403,
        404,
        405,
        406,
        407,
        408,
        409,
        410,
        411,
        412,
        413,
        414,
        415,
        416,
        417,
        418,
        419,
        420,
        421,
        422,
        423,
    ],
}


def process_khoros(access_token: str, khoros: dict) -> None:
    """
    Process Khoros export.

    Args:
        access_token (str): Access token for authentication.
        khoros (dict): Dictionary containing Khoros export details.

    Returns:
        None
    """
    khoros_summary = khoros_export_function(access_token, khoros)
    export_id = khoros_summary["export_id"]
    export_status(access_token, export_id, khoros)


with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
    # Submit each khoros task to the executor
    futures = [executor.submit(process_khoros, access_token, khoros) for khoros in khoros_list]
    # Wait for all tasks to complete
    concurrent.futures.wait(futures)
