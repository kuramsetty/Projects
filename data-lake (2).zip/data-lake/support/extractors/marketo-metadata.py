"""Retrieves Marketo metadata and writes it to S3."""

import argparse
import json
from urllib.parse import urlparse

import boto3
from marketorestpython.client import MarketoClient

parser = argparse.ArgumentParser(description="Ingest data from OData API")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
args = parser.parse_known_args()[0]

s3 = boto3.client("s3")
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="data-lake-adobe-marketo")[
        "SecretString"
    ]
)
client = MarketoClient(secret["munchkin_id"], secret["client_id"], secret["client_secret"])

metadata = client.describe()

s3.put_object(
    Body=json.dumps(metadata),
    Bucket=urlparse(args.destination).netloc,
    Key=urlparse(args.destination).path[1:] + "/metadata.json",
)
