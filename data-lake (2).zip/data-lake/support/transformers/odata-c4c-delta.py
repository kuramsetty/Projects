#!/usr/bin/env python
"""Transform for the delta load."""
import argparse

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from c4c import get_c4c_metadata, transform_c4c_df
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from utils import camel_to_snake, get_all_s3_objects, keep_only_most_recent_per_group, parse_s3_uri

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")
s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--metadata-path", dest="metadata_path", help="S3 path to the metadata XML from C4C"
)
parser.add_argument(
    "--collection-name", dest="collection_name", help="Name of the collection (used for metadata)"
)
parser.add_argument(
    "--discard-history-id", dest="discard_id", help="Discard all history based on ID"
)
parser.add_argument(
    "--discard-history-column",
    dest="discard_col",
    help="Discard all history except the max in the given column",
)
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

# Read JSON from S3
bucket_full, prefix_full = parse_s3_uri(f"{args.source}/full")
objects_full = get_all_s3_objects(s3=s3, Bucket=bucket_full, Prefix=prefix_full)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]

glue_full_df = glueContext.create_dynamic_frame.from_options(
    format_options={"jsonPath": "", "multiline": True},
    connection_type="s3",
    format="json",
    connection_options={"paths": paths_full},
)
full_df = glue_full_df.toDF()
full_df = full_df.withColumn("x_etl_type", F.lit("full"))

bucket_delta, key = parse_s3_uri(f"{args.source}/delta")
objects_delta = get_all_s3_objects(s3=s3, Bucket=bucket_delta, Prefix=key)

if objects_delta:
    paths_delta = [f"s3://{bucket_delta}/{o['Key']}" for o in objects_delta]
    glue_delta_df = glueContext.create_dynamic_frame.from_options(
        format_options={"jsonPath": "", "multiline": True},
        connection_type="s3",
        format="json",
        connection_options={"paths": paths_delta},
    )
    delta_df = glue_delta_df.toDF()
    delta_df = delta_df.withColumn("x_etl_type", F.lit("delta"))

    df = full_df.union(delta_df.select(full_df.columns))
else:
    df = full_df

n_partitions = int(df.rdd.getNumPartitions() / 10)
df = df.dropDuplicates()

# Get data types from C4C
count_before = df.count()
meta = get_c4c_metadata(args.metadata_path, args.collection_name)
df = transform_c4c_df(df, meta)
count_after = df.count()

if count_before != count_after:
    raise ValueError(f"Mismatch in number of records; before: {count_before}, after: {count_after}")

# Keep only the last row per ID (no Change Data Capture)
if args.discard_id and args.discard_col:
    df = keep_only_most_recent_per_group(
        df=df, date_col=camel_to_snake(args.discard_col), group=args.discard_id
    )

    discard_id_df_count = df.select(args.discard_id).distinct().count()
    if discard_id_df_count == 0:
        raise ValueError(f"Distinct count for column {args.discard_id} is zero")
    if discard_id_df_count != df.count():
        raise ValueError(
            f"Mismatch in discarded record count with {glue_full_df.count() - df.count()} number."
        )

# Repartition into smaller partitions for performance
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)
print("count ", df.count())

df.write.mode("overwrite").save(args.destination)
print(f"Data written successfully to s3 {args.destination}")

job.commit()
