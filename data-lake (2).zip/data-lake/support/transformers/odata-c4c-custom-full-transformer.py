#!/usr/bin/env python
"""Transform data for custom full load."""
import argparse

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from utils import get_all_s3_objects, parse_s3_uri, remove_null_columns

s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

bucket_full, prefix_full = parse_s3_uri(args.source)
objects_full = get_all_s3_objects(s3=s3, Bucket=bucket_full, Prefix=prefix_full)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]


# Read JSON from S3
glue_df = glueContext.create_dynamic_frame.from_options(
    format_options={"jsonPath": "", "multiline": True},
    connection_type="s3",
    format="json",
    connection_options={"paths": paths_full},
)

# Convert to Spark DataFrame
df = glue_df.toDF()
df = df.drop("__metadata")
df = remove_null_columns(df)

# Repartition into smaller partitions for performance
n_partitions = int(df.rdd.getNumPartitions() / 4)
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)

df.write.mode("overwrite").save(args.destination)

job.commit()
