#!/usr/bin/env python
"""Extract activities from Marketo."""

import argparse
import json
from pprint import pprint

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from marketorestpython.client import MarketoClient
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql import types as T
from utils import camel_to_snake, get_all_s3_objects, parse_s3_uri

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")
s3 = boto3.client("s3")
secret = json.loads(
    boto3.client("secretsmanager").get_secret_value(SecretId="data-lake-adobe-marketo")[
        "SecretString"
    ]
)
client = MarketoClient(secret["munchkin_id"], secret["client_id"], secret["client_secret"])

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--metadata-path", dest="metadata_path", help="S3 path to the metadata JSON from Marketo"
)
parser.add_argument(
    "--keep-last", dest="keep_last", action="store_true", help="Keep only the last change per ID"
)
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

glueContext = GlueContext(SparkContext.getOrCreate())
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)


def flatten_df(nested_df):
    """Flatten the struct type column."""
    flat_cols = [c[0] for c in nested_df.dtypes if c[1][:6] != "struct"]
    nested_cols = [c[0] for c in nested_df.dtypes if c[1][:6] == "struct"]
    flat_df = nested_df.select(
        flat_cols
        + [
            F.col(nc + "." + c).alias(nc + "_" + c)
            for nc in nested_cols
            for c in nested_df.select(nc + ".*").columns
        ]
    )
    return flat_df


def read_activity(source, activity_type_id, verbose=False):
    """Read the activities."""
    # Full extract
    bucket_full, prefix_full = parse_s3_uri(source + f"/full/activity_id={activity_type_id}/")
    objects_full = get_all_s3_objects(
        s3=s3, Bucket=bucket_full, Prefix=prefix_full
    )  # s3.list_objects(Bucket=bucket_full, Prefix=prefix_full).get("Contents", None)
    if objects_full:
        paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]
        if verbose:
            print("Reading the following files from the full extract:")
            for path_full in paths_full:
                print(path_full)
    else:
        return None

    # Delta extract
    bucket_delta, prefix_delta = parse_s3_uri(source + f"/delta/activity_id={activity_type_id}/")
    objects_delta = get_all_s3_objects(
        s3=s3, Bucket=bucket_delta, Prefix=prefix_delta
    )  # s3.list_objects(Bucket=bucket_delta, Prefix=prefix_delta).get("Contents", None)
    if objects_delta:
        paths_delta = [f"s3://{bucket_delta}/{o['Key']}" for o in objects_delta]

        if verbose:
            print("Reading the following files from the delta extracts:")
            for path_delta in paths_delta:
                print(path_delta)
    else:
        paths_delta = []

    glue_df = glueContext.create_dynamic_frame.from_options(
        format_options={"jsonPath": "", "multiline": True},
        connection_type="s3",
        format="json",
        connection_options={"paths": paths_full + paths_delta},
    )

    return glue_df


# def flatten(schema, prefix: str = ""):
#     # return a list of sub-items to select, within a given field
#     def field_items(field):
#         name = f'{prefix}.{field.name}' if prefix else field.name
#         if type(field.dataType) == StructType:
#             return flatten(field.dataType, name)
#         else:
#             return [F.col(name).alias(name.replace('.', '_'))]
#
#     return [item for field in schema.fields for item in field_items(field)]
#
#
# def transform_activity(df):
#     def flatten_df_schema(df, field):
#         df = df.withColumn(field.name, df[field.name].getItem(0))
#         df = df.select(*flatten(df.schema))
#         if 'ArrayType' in str(df.schema.fields):
#             return transform_activity(df)
#         else:
#             df = df.select(*[F.col(f.name).alias(camel_to_snake(f.name)) for f in df.schema.fields])
#             return df
#
#     for each in df.schema.fields:
#         if type(each.dataType) == ArrayType:
#             df = flatten_df_schema(df, each)
#     return df


def pivot_attributes(df):
    """
    This pivots key value pairs in an array such that they become new columns in the data frame.

    Given the following schema::

        root
         |-- id: integer (nullable = true)
         |-- marketoGUID: string (nullable = true)
         |-- leadId: integer (nullable = true)
         |-- activityDate: string (nullable = true)
         |-- activityTypeId: integer (nullable = true)
         |-- primaryAttributeValueId: integer (nullable = true)
         |-- primaryAttributeValue: string (nullable = true)
         |-- attributes: array (nullable = true)
         |    |-- element: struct (containsNull = true)
         |    |    |-- name: string (nullable = true)
         |    |    |-- value: struct (nullable = true)
         |    |    |    |-- boolean: boolean (nullable = true)
         |    |    |    |-- double: double (nullable = true)
         |    |    |    |-- int: integer (nullable = true)
         |    |    |    |-- string: string (nullable = true)
         |-- campaignId: integer (nullable = true)

    This function creates a data frame which looks as follows::

        root
         |-- id: integer (nullable = true)
         |-- marketoGUID: string (nullable = true)
         |-- leadId: integer (nullable = true)
         |-- activityDate: string (nullable = true)
         |-- activityTypeId: integer (nullable = true)
         |-- primaryAttributeValueId: integer (nullable = true)
         |-- primaryAttributeValue: string (nullable = true)
         |-- campaignId: integer (nullable = true)
         |-- API Method Name: struct (nullable = true)
         |    |-- boolean: boolean (nullable = true)
         |    |-- double: double (nullable = true)
         |    |-- int: integer (nullable = true)
         |    |-- string: string (nullable = true)
         |-- Modifying User: struct (nullable = true)
         |    |-- boolean: boolean (nullable = true)
         |    |-- double: double (nullable = true)
         |    |-- int: integer (nullable = true)
         |    |-- string: string (nullable = true)
         |-- New Value: struct (nullable = true)
         |    |-- boolean: boolean (nullable = true)
         |    |-- double: double (nullable = true)
         |    |-- int: integer (nullable = true)
         |    |-- string: string (nullable = true)


    The second data frame has been created by creating a new column for each distinct `name` in the
    attributes.element.name structure.

    Args:
        df: a Spark Data Frame

    Returns: Spark Data Frame

    """
    df = df.withColumn("__idx", F.monotonically_increasing_id())
    attributes = df.select("__idx", F.explode("attributes")).select(
        "__idx", "col.name", "col.value"
    )
    pivoted_attributes = attributes.groupby("__idx").pivot("name").agg({"value": "first"})
    return df.join(pivoted_attributes, on="__idx", how="left").drop("__idx").drop("attributes")


def sanitize_nested_schema(df):
    """Sanitize the nested columns."""
    new_schema = T.StructType.fromJson(
        json.loads(
            df.schema.json()
            .replace("Old Value", "old_value")
            .replace("New Value", "new_value")
            .replace("Attribute Name", "attribute_name")
        )
    )

    return spark.createDataFrame(df.rdd, schema=new_schema)


def flatten_attributes(df, activity):
    """
    Flatten the attributes of the specified activity in the DataFrame.

    Args:
        df (DataFrame): The DataFrame containing activity data.
        activity (str): The name of the activity whose attributes need to be flattened.

    Returns:
        DataFrame: The DataFrame with flattened attributes for the specified activity.

    """
    # Don't flatten these columns because they contain heterogenous data types and we want to keep a column
    # for each data type
    dont_flatten_cols = ["Old Value", "New Value"]

    # Find all the columns in the data frame that are of type struct.
    struct_cols = [f.name for f in df.schema.fields if str(f.dataType).startswith("StructType")]

    # Create a dictionary that maps from column name to data type according to the metadata
    col_types = dict([(a["name"], a["dataType"]) for a in activity["attributes"]])

    # We kickstart or select statement with all columns that are not struct
    cols = [F.col(c.name) for c in df.schema.fields if c.name not in struct_cols]

    for struct_col in struct_cols:
        if struct_col in dont_flatten_cols:
            # # Instead of selecting only type out of (double, integer, boolean, ...),
            # we create a column for each type.
            # field = [f for f in df.schema.fields if f.name == struct_col][0]

            # col_subnames = [f["name"] for f in json.loads(field.json())["type"]["fields"]]
            # for col_subname in col_subnames:
            # cols.append(F.col(f"{struct_col}.{col_subname}").alias(f"{struct_col}_{col_subname}"))

            cols.append(F.col(struct_col))
        else:
            # We select the correct column according to the type specifiec in the metadata document

            try:
                dtype = col_types[struct_col]
            except KeyError:
                print(
                    f"Warning: Column {struct_col} is of type StructField, "
                    "but Marketo Metadata does not list it. Dropping."
                )
                continue

            if dtype == "integer":
                col_subname = "int"
            elif dtype == "boolean":
                col_subname = "boolean"
            else:
                col_subname = "string"

            cols.append(F.col(f"{struct_col}.{col_subname}").alias(struct_col))

    return df.select(*cols)


def write_activity(df, destination):
    """Write the activity."""
    n_partitions = int(df.rdd.getNumPartitions() / 100)
    if n_partitions <= 1:
        n_partitions = 1

    # We use repartition instead of coalesce because records are not distributed well across time slices
    df = df.repartition(n_partitions)
    df.write.mode("overwrite").save(destination)


for activity in client.execute(method="get_activity_types"):
    activity_id = str(activity["id"])
    glue_df = read_activity(source=args.source, activity_type_id=activity_id)

    if glue_df is None:
        continue

    print(f"Loaded activity with id {activity_id}. The activity has the following metadata")
    pprint(activity)

    print("And the following schema:")
    # df = glue_df.toDF()
    try:
        df = glue_df.toDF()
    except ValueError:
        print("error")
        print(activity_id)
        continue
    # df.printSchema()

    print("Schema after pivoting attributes:")
    df = pivot_attributes(df)
    # df.printSchema()

    print("Schema after flattening attributes:")
    df = flatten_attributes(df, activity)
    # df.printSchema()

    print("Schema after flattening 'new_value and old_value' columns:")
    df = flatten_df(df)
    # df.printSchema()

    print("Schema after sanitization:")
    df = sanitize_nested_schema(df)

    timestamp_cols = set([a["name"] for a in activity["attributes"] if a["dataType"] == "datetime"])
    cols = set([f.name for f in df.schema.fields])

    for timestamp_col in timestamp_cols:
        if timestamp_col in cols:
            df = df.withColumn(timestamp_col, F.col(timestamp_col).cast("timestamp"))

    df = df.select(*[F.col(f.name).alias(camel_to_snake(f.name)) for f in df.schema.fields])

    if "activity_date" in set(f.name for f in df.schema.fields):
        df = df.withColumn("activity_date", F.col("activity_date").cast("timestamp"))

    # df.printSchema()
    write_activity(
        df, destination=args.destination + f"/activity_{camel_to_snake(activity['name'])}"
    )

    # try:
    #     write_activity(df, destination=args.destination + f"/activity_{camel_to_snake(activity['name'])}")
    # except:
    #     print("error",activity['name'])
    del df

job.commit()
