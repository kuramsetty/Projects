"""Transformers for Khoros."""

import argparse
import re

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql.functions import col, to_date
from pyspark.sql.types import DecimalType, TimestampType
from utils import parse_s3_uri

s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="khoros data")
parser.add_argument("--source", dest="source", help="extracted data")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]


glueContext = GlueContext(SparkContext.getOrCreate())
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

bucket_full, prefix_full = parse_s3_uri(args.source)
objects_full = s3.list_objects_v2(Bucket=bucket_full, Prefix=prefix_full).get("Contents", None)

paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]


# print("path before for loop")
# print(paths_full)
def camel_to_snake(s):
    """
    Converts CamelCase to snake_case.

    Args:
        s: string to convert

    Returns: new string in snake_case

    """
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", s)
    s = re.sub(r"([a-z\d])([A-Z])", r"\1_\2", s)
    s = s.replace("-", "_").replace(" ", "_").replace(".", "_")

    s = s.lower()
    s = re.sub(r"_([a-z])_", r"\1_", s)
    s = "".join(c for c in s if c.isalpha() or c.isnumeric() or c == "_")
    if s[0] == "_":
        s = s[1:]
    if s[-1] == "_":
        s = s[:-1]

    return s


filenames = []
try:

    # for i in paths_full:
    #     print(i)
    #     print("path in for loop")
    #     print(paths_full)
    #     if 'daily_account_level_export' in str(i):
    #         filenames.append('daily_account_level_export')
    #     elif 'published_posts_export' in str(i):
    #         filenames.append('published_posts_export')
    #     elif 'daily_post_summary_export' in str(i):
    #         filenames.append('daily_post_summary_export')
    #     elif 'customer_feedback_export' in str(i):
    #         filenames.append('customer_feedback_export')
    #     elif 'stream_item_export' in str(i):
    #         filenames.append('stream_item_export')
    #     elif 'stream_item_action_export' in str(i):
    #         filenames.append('stream_item_action_export')
    #     elif 'profiles_export' in str(i):
    #         filenames.append('profiles_export')
    #     elif 'ads_net_values_export' in str(i):
    #         filenames.append('ads_net_values_export')
    print("path----->", paths_full)
    for i in paths_full:
        print("testing the for loop------")
        if "daily_account_level_export" in str(i):
            print("daily_account_level_export--->", i)
            filename = "daily_account_level_export"
        elif "published_posts_export" in str(i):
            filename = "published_posts_export"
            print("published_posts_export--->", i)
        elif "daily_post_summary_export" in str(i):
            filename = "daily_post_summary_export"
            print("daily_post_summary_export--->", i)
        elif "customer_feedback_export" in str(i):
            filename = "customer_feedback_export"
            print("customer_feedback_export--->", i)
        elif "stream_item_export" in str(i):
            filename = "stream_item_export"
            print("stream_item_export--->", i)
        elif "stream_item_action_export" in str(i):
            filename = "stream_item_action_export"
            print("stream_item_action_export--->", i)
        elif "ads_net_values_export" in str(i):
            filename = "ads_net_values_export"
            print("ads_net_values_export--->", i)
        elif "profiles_export" in str(i):
            filename = "profiles_export"
            print("profiles_export--->", i)
        print(i)
        if "daily_account_level_export" in str(i):
            # print(i)
            # Read the specific file
            daily_account_level_export_df = spark.read.csv(i, sep="\t", header=True)
            print("printing the schema daily_account_level_export-------->")
            daily_account_level_export_df.printSchema()
            metric_index = daily_account_level_export_df.columns.index("Metric")
            # print(metric_index)
            date_columns = daily_account_level_export_df.columns[metric_index + 1 :]
            # print(date_columns)
            daily_account_level_export_df = daily_account_level_export_df.withColumnRenamed(
                "Spredfast Account ID", "Spredfast_Account_ID"
            )
            df_pivot = daily_account_level_export_df.selectExpr(
                "Spredfast_Account_ID",
                "Account",
                "Channel",
                "Metric",
                f"stack({len(date_columns)}, "
                + ", ".join([f"'{c}', `{c}`" for c in date_columns])
                + ") as (Date, value)",
            )

            # df_pivot.show()

            df_pivot = (
                df_pivot.groupBy("Spredfast_Account_ID", "Account", "Channel", "Date")
                .pivot("Metric")
                .agg(F.first("value"))
            )
            # Converting date type from varchar to date
            df_pivot = df_pivot.withColumn("Date", to_date("Date", "yyyy-MM-dd"))
            df_pivot = df_pivot.withColumn("Date", col("Date").cast(TimestampType()))
            df_pivot.printSchema()
            # cols_rename= []
            df_pivot = df_pivot.withColumnRenamed("Page Fans", "Page_Fans")
            df_pivot = df_pivot.withColumnRenamed("Page Fans - New", "Page_Fans_New")
            df_pivot = df_pivot.withColumnRenamed("Profile Followers", "Profile_Followers")
            df_pivot = df_pivot.withColumnRenamed(
                "Profile Followers - New", "Profile_Followers_New"
            )
            df_pivot = df_pivot.withColumnRenamed(
                "Profile Following - New", "Profile_Following_New"
            )
            df_pivot = df_pivot.withColumnRenamed("Profile Following", "Profile_Following")
            df_pivot = df_pivot.withColumnRenamed("Page Followers", "Page_Followers")
            df_pivot = df_pivot.withColumnRenamed("Page Followers - New", "Page_Followers_New")
            df_pivot = df_pivot.withColumnRenamed("Account Followers", "Account_Followers")
            df_pivot = df_pivot.withColumnRenamed(
                "Account Followers - New", "Account_Followers_New"
            )
            df_pivot = df_pivot.withColumnRenamed("Account Mentions", "Account_Mentions")
            df_pivot = df_pivot.withColumnRenamed(
                "Account Mention Audience", "Account_Mention_Audience"
            )
            df_pivot = df_pivot.withColumnRenamed(
                "Account Direct Messages Received", "Account_Direct_Messages_Received"
            )
            df_pivot = df_pivot.withColumnRenamed("Channel Subscribers", "Channel_Subscribers")
            df_pivot = df_pivot.withColumnRenamed(
                "Channel Subscribers - New", "Channel_Subscribers_New"
            )
            df_pivot = df_pivot.withColumnRenamed(
                "Profile Impressions - 1 Day", "Profile_Impressions_1_Day"
            )
            df_pivot = df_pivot.withColumnRenamed("Profile Reach - 1 Day", "Profile_Reach_1_Day")
            df_pivot = df_pivot.withColumnRenamed(
                "Profile Clicks - Email Contact", "Profile_Clicks_Email_Contact"
            )
            df_pivot = df_pivot.withColumnRenamed(
                "Profile Clicks - Phone Call", "Profile_Clicks_Phone_Call"
            )
            df_pivot = df_pivot.withColumnRenamed(
                "Profile Clicks - Get Directions", "Profile_Clicks_Get_Directions"
            )
            df_pivot = df_pivot.withColumnRenamed(
                "Profile Clicks - Text Message", "Profile_Clicks_Text_Message"
            )
            df_pivot = df_pivot.withColumnRenamed(
                "Profile Clicks - Website", "Profile_Clicks_Website"
            )
            df_pivot = df_pivot.withColumnRenamed("Profile Views", "Profile_Views")

            columns_to_decimal1 = [
                "Page_Fans",
                "Page_Fans_New",
                "Profile_Followers",
                "Profile_Followers_New",
                "Profile_Following_New",
                "Profile_Following",
                "Page_Followers",
                "Page_Followers_New",
                "Account_Followers",
                "Account_Followers_New",
                "Account_Mentions",
                "Account_Mention_Audience",
                "Channel_Subscribers",
                "Channel_Subscribers_New",
                "Profile_Impressions_1_Day",
                "Profile_Reach_1_Day",
                "Profile_Clicks_Email_Contact",
                "Profile_Clicks_Get_Directions",
                "Profile_Clicks_Text_Message",
                "Profile_Clicks_Website",
                "Profile_Views",
                "Account_Direct_Messages_Received",
            ]

            #
            # Iterate through the columns and cast them to DecimalType
            for column_name in columns_to_decimal1:
                df_pivot = df_pivot.withColumn(column_name, col(column_name).cast(DecimalType()))

            df_pivot.printSchema()
            df = df_pivot

            df.show(2, False)

        elif "daily_post_summary_export" in str(i):
            # print(i)
            # Read the specific file
            daily_post_summary_export_df = spark.read.csv(i, sep="\t", header=True)
            print("printing the schema daily_post_summary_export_df -------->")
            daily_post_summary_export_df.printSchema()
            metric_index = daily_post_summary_export_df.columns.index("Metric")
            # print(metric_index)
            date_columns = daily_post_summary_export_df.columns[metric_index + 1 :]
            # print(date_columns)
            daily_post_summary_export_df = daily_post_summary_export_df.withColumnRenamed(
                "Account ID", "Account_ID"
            )
            df_pivot = daily_post_summary_export_df.selectExpr(
                "Account_ID",
                "Account",
                "Channel",
                "Metric",
                f"stack({len(date_columns)}, "
                + ", ".join([f"'{c}', `{c}`" for c in date_columns])
                + ") as (Date, value)",
            )

            # df_pivot.show()

            df_pivot = (
                df_pivot.groupBy("Account_ID", "Account", "Channel", "Date")
                .pivot("Metric")
                .agg(F.first("value"))
            )
            # Converting date type from varchar to date
            df_pivot = df_pivot.withColumn("Date", col("Date").cast(TimestampType()))
            df_pivot.printSchema()

            original_column2 = [
                "Post Clicks",
                "Post Clicks - App Installs Clicks - Advanced",
                "Post Clicks - App Opens Clicks - Advanced",
                "Post Clicks - Button Click",
                "Post Clicks - Detail Expands - Advanced",
                "Post Clicks - Emails Clicks - Advanced",
                "Post Clicks - Follows Clicks - Advanced",
                "Post Clicks - Hashtag Clicks - Advanced",
                "Post Clicks - Link Click",
                "Post Clicks - Media Clicks - Advanced",
                "Post Clicks - Other Click",
                "Post Clicks - Permalink Clicks - Advanced",
                "Post Clicks - Photo View",
                "Post Clicks - Profile Clicks - Advanced",
                "Post Clicks - URL Clicks - Advanced",
                "Post Clicks - Video Play",
                "Post Comments",
                "Post Dislikes",
                "Post Engaged Users",
                "Post Engagement",
                "Post Engagement - Advanced",
                "Post Impressions",
                "Post Impressions - Advanced",
                "Post Impressions - Organic",
                "Post Impressions - Paid",
                "Post Impressions - Viral",
                "Post Likes",
                "Post Likes - Advanced",
                "Post Link Shortener Clicks",
                "Post Native Retweet Audience",
                "Post Native Retweets",
                "Post Reach",
                "Post Reach - Advanced",
                "Post Reach - Organic",
                "Post Reach - Paid",
                "Post Reach - Viral",
                "Post Reactions",
                "Post Reactions - Angry",
                "Post Reactions - Haha",
                "Post Reactions - Like",
                "Post Reactions - Love",
                "Post Reactions - Sad",
                "Post Reactions - Wow",
                "Post Replies",
                "Post Replies - Advanced",
                "Post Retweets - Advanced",
                "Post Retweets - Quoted - Advanced",
                "Post Retweets - Unquoted - Advanced",
                "Post Saves",
                "Post Shares",
                "Post Shares (Reels)",
                "Post Unlikes - Advanced",
                "Post Unreplies - Advanced",
                "Post Unretweets - Advanced",
                "Post Video Plays (Reels)",
                "Post Video Starts - Advanced",
                "Post Video Time Watched",
                "Post Video Time Watched 3s",
                "Post Video Viewers",
                "Post Video Views",
                "Post Video Views - 25 Percent - Advanced",
                "Post Video Views - 50 Percent - Advanced",
                "Post Video Views - 75 Percent - Advanced",
                "Post Video Views - 95 Percent - Advanced",
                "Post Video Views - Advanced",
                "Post Video Views - Complete - Advanced",
                "Post Video Views 3s",
                "Story Exits",
                "Story Impressions",
                "Story Reach",
                "Story Replies",
                "Story Taps Back",
                "Story Taps Forward",
            ]

            # Rename all columns by adding underscores
            for old_col_name in df_pivot.columns:
                if old_col_name in original_column2:
                    new_col_name = old_col_name.replace(" ", "_")
                    df_pivot = df_pivot.withColumnRenamed(old_col_name, new_col_name)

            columns_to_decimal2 = [
                "Post_Clicks",
                "Post_Clicks_-_App_Installs_Clicks_-_Advanced",
                "Post_Clicks_-_App_Opens_Clicks_-_Advanced",
                "Post_Clicks_-_Button_Click",
                "Post_Clicks_-_Detail_Expands_-_Advanced",
                "Post_Clicks_-_Emails_Clicks_-_Advanced",
                "Post_Clicks_-_Follows_Clicks_-_Advanced",
                "Post_Clicks_-_Hashtag_Clicks_-_Advanced",
                "Post_Clicks_-_Link_Click",
                "Post_Clicks_-_Media_Clicks_-_Advanced",
                "Post_Clicks_-_Other_Click",
                "Post_Clicks_-_Permalink_Clicks_-_Advanced",
                "Post_Clicks_-_Photo_View",
                "Post_Clicks_-_Profile_Clicks_-_Advanced",
                "Post_Clicks_-_URL_Clicks_-_Advanced",
                "Post_Clicks_-_Video_Play",
                "Post_Comments",
                "Post_Dislikes",
                "Post_Engaged_Users",
                "Post_Engagement",
                "Post_Engagement_-_Advanced",
                "Post_Impressions",
                "Post_Impressions_-_Advanced",
                "Post_Impressions_-_Organic",
                "Post_Impressions_-_Paid",
                "Post_Impressions_-_Viral",
                "Post_Likes",
                "Post_Likes_-_Advanced",
                "Post_Link_Shortener_Clicks",
                "Post_Native_Retweet_Audience",
                "Post_Native_Retweets",
                "Post_Reach",
                "Post_Reach_-_Advanced",
                "Post_Reach_-_Organic",
                "Post_Reach_-_Paid",
                "Post_Reach_-_Viral",
                "Post_Reactions",
                "Post_Reactions_-_Angry",
                "Post_Reactions_-_Haha",
                "Post_Reactions_-_Like",
                "Post_Reactions_-_Love",
                "Post_Reactions_-_Sad",
                "Post_Reactions_-_Wow",
                "Post_Replies",
                "Post_Replies_-_Advanced",
                "Post_Retweets_-_Advanced",
                "Post_Retweets_-_Quoted_-_Advanced",
                "Post_Retweets_-_Unquoted_-_Advanced",
                "Post_Saves",
                "Post_Shares",
                "Post_Shares_(Reels)",
                "Post_Unlikes_-_Advanced",
                "Post_Unreplies_-_Advanced",
                "Post_Unretweets_-_Advanced",
                "Post_Video_Plays_(Reels)",
                "Post_Video_Starts_-_Advanced",
                "Post_Video_Time_Watched",
                "Post_Video_Time_Watched_3s",
                "Post_Video_Viewers",
                "Post_Video_Views",
                "Post_Video_Views_-_25_Percent_-_Advanced",
                "Post_Video_Views_-_50_Percent_-_Advanced",
                "Post_Video_Views_-_75_Percent_-_Advanced",
                "Post_Video_Views_-_95_Percent_-_Advanced",
                "Post_Video_Views_-_Advanced",
                "Post_Video_Views_-_Complete_-_Advanced",
                "Post_Video_Views_3s",
                "Story_Exits",
                "Story_Impressions",
                "Story_Reach",
                "Story_Replies",
                "Story_Taps_Back",
                "Story_Taps_Forward",
            ]

            for column_name in columns_to_decimal2:
                df_pivot = df_pivot.withColumn(column_name, col(column_name).cast(DecimalType()))
            # Display the DataFrame after renaming columns
            df_pivot.printSchema()
            # df_pivot.show(2)

            # Writing the pivoted DataFrame to an output directory
            # df_pivot.write.mode("overwrite").save(args.destination + '/daily_account_level_export')
            # print("before the merging:")
            df = df_pivot

        elif "published_posts_export" in str(i):
            # print(i)
            # Read the specific file
            published_posts_export_df = spark.read.csv(i, sep="\t", header=True)
            print("printing the schema published_posts_export_df-------->")
            published_posts_export_df.printSchema()
            original_columns = [
                "Khoros Post ID",
                "Khoros Stream Item Key",
                "Channel Post ID",
                "Initiative",
                "Initiative ID",
                "Account Set",
                "Account Set ID",
                "Account",
                "Khoros Account ID",
                "Channel Account ID",
                "Khoros Publishing Event ID",
                "Published Date",
                "User ID",
                "User Email",
                "Media Type",
                "Asset Ids",
                "Image Link",
                "Media Links",
                "Post Title",
                "Post Text",
                "Link Title",
                "Link Description",
                "Khoros Link ID",
                "Post Engagement",
                "Post Engagement - Advanced",
                "Post Engagement Rate",
                "Post Engagement Rate - Advanced",
                "Facebook - Post Unique Engagement Rate",
                "Facebook - Post Clicks - Button Click",
                "Facebook - Post Clicks - Link Click",
                "Facebook - Post Clicks - Other Click",
                "Facebook - Post Clicks - Photo View",
                "Facebook - Post Clicks - Video Play",
                "Facebook - Post Comments",
                "Facebook - Post Engaged Fans",
                "Facebook - Post Engaged Users",
                "Facebook - Post Fan Impressions",
                "Facebook - Post Fan Impressions - Paid",
                "Facebook - Post Fan Reach",
                "Facebook - Post Fan Reach - Paid",
                "Facebook - Post Impressions",
                "Facebook - Post Impressions - Organic",
                "Facebook - Post Impressions - Paid",
                "Facebook - Post Impressions - Viral",
                "Facebook - Post Negative Feedback",
                "Facebook - Post Negative Feedback - Hide",
                "Facebook - Post Negative Feedback - Hide All",
                "Facebook - Post Negative Feedback - Report",
                "Facebook - Post Negative Feedback - Unlike Page",
                "Facebook - Post Negative Feedback Users",
                "Facebook - Post Reach",
                "Facebook - Post Reach - Organic",
                "Facebook - Post Reach - Paid",
                "Facebook - Post Reach - Viral",
                "Facebook - Post Reactions",
                "Facebook - Post Reactions - Angry",
                "Facebook - Post Reactions - Haha",
                "Facebook - Post Reactions - Like",
                "Facebook - Post Reactions - Love",
                "Facebook - Post Reactions - Sad",
                "Facebook - Post Reactions - Wow",
                "Facebook - Post Shares",
                "Facebook - Post Video Average Watch Time",
                "Facebook - Post Video Length",
                "Facebook - Post Video Views 3s",
                "Facebook - Post Video Views 3s - Autoplayed",
                "Facebook - Post Video Views 3s - Clicked To Play",
                "Facebook - Post Video Views 3s - Organic",
                "Facebook - Post Video Views 3s - Paid",
                "Facebook - Post Video Views 30s - Autoplayed",
                "Facebook - Post Video Views 30s - Clicked To Play",
                "Facebook - Post Video Views 30s - Organic",
                "Facebook - Post Video Views 30s - Paid",
                "Facebook - Post Video Views Complete - Organic",
                "Facebook - Post Video Views Complete - Paid",
                "Facebook - Post Video Viewers 3s",
                "Facebook - Post Video Viewers 3s - Organic",
                "Facebook - Post Video Viewers 3s - Paid",
                "Facebook - Post Video Viewers Complete - Organic",
                "Facebook - Post Video Viewers Complete - Paid",
                "Instagram - Post Comments",
                "Instagram - Post Impressions",
                "Instagram - Post Likes",
                "Instagram - Post Reach",
                "Instagram - Post Saves",
                "Instagram - Post Video Views",
                "Instagram - Post Shares (Reels)",
                "Instagram - Post Video Plays (Reels)",
                "Instagram - Story Exits",
                "Instagram - Story Impressions",
                "Instagram - Story Reach",
                "Instagram - Story Replies",
                "Instagram - Story Taps Back",
                "Instagram - Story Taps Forward",
                "Linkedin - Post Comments",
                "Linkedin - Post Impressions",
                "Linkedin - Post Likes",
                "Linkedin - Post Clicks",
                "Linkedin - Post Shares",
                "Linkedin - Post Video Views 3s",
                "Linkedin - Post Video Viewers",
                "Linkedin - Post Video Time Watched",
                "Linkedin - Post Video Time Watched 3s",
                "Pinterest - Post Comments",
                "Pinterest - Post Likes",
                "Pinterest - Post Saves",
                "Twitter - Post Likes",
                "Twitter - Post Native Retweet Audience",
                "Twitter - Post Native Retweets",
                "Twitter - Post Replies",
                "Twitter - Post Clicks - App Installs Clicks - Advanced",
                "Twitter - Post Clicks - App Opens Clicks - Advanced",
                "Twitter - Post Clicks - Detail Expands - Advanced",
                "Twitter - Post Clicks - Emails Clicks - Advanced",
                "Twitter - Post Clicks - Follows Clicks - Advanced",
                "Twitter - Post Clicks - Hashtag Clicks - Advanced",
                "Twitter - Post Clicks - Media Clicks - Advanced",
                "Twitter - Post Clicks - Permalink Clicks - Advanced",
                "Twitter - Post Clicks - Profile Clicks - Advanced",
                "Twitter - Post Clicks - URL Clicks - Advanced",
                "Twitter - Post Impressions - Advanced",
                "Twitter - Post Likes - Advanced",
                "Twitter - Post Reach - Advanced",
                "Twitter - Post Replies - Advanced",
                "Twitter - Post Retweets - Advanced",
                "Twitter - Post Retweets - Quoted - Advanced",
                "Twitter - Post Retweets - Unquoted - Advanced",
                "Twitter - Post Unlikes - Advanced",
                "Twitter - Post Unreplies - Advanced",
                "Twitter - Post Unretweets - Advanced",
                "Twitter - Post Video Starts - Advanced",
                "Twitter - Post Video Views - Advanced",
                "Twitter - Post Video Views - 25 Percent - Advanced",
                "Twitter - Post Video Views - 50 Percent - Advanced",
                "Twitter - Post Video Views - 75 Percent - Advanced",
                "Twitter - Post Video Views - 95 Percent - Advanced",
                "Twitter - Post Video Views - Complete - Advanced",
                "Vk - Post Comments",
                "Vk - Post Likes",
                "Vk - Post Reposts",
                "Weibo - Post Comments",
                "Weibo - Post Reposts",
                "Youtube - Post Comments",
                "Youtube - Post Dislikes",
                "Youtube - Post Likes",
                "Youtube - Post Video Views",
                "Tiktok - Post Video Views",
                "Tiktok - Video Length",
                "Tiktok - Post Likes",
                "Tiktok - Post Comments",
                "Tiktok - Video Shares",
                "Tiktok - Post Reach",
                "Tiktok - Post Video Views - Complete",
                "Tiktok - Video Total Play Time",
                "Tiktok - Video Average Watch Time",
                "Post Link Shortener Clicks",
                "Web Analytics Bounces from Social",
                "Web Analytics Conversion Value from Social",
                "Web Analytics Conversions from Social",
                "Web Analytics New Visitors from Social",
                "Web Analytics Page Views from Social",
                "Web Analytics Visits from Social",
            ]

            # Rename all columns by adding underscores
            for old_col_name in published_posts_export_df.columns:
                if old_col_name in original_columns:
                    new_col_name = old_col_name.replace(" ", "_")
                    published_posts_export_df = published_posts_export_df.withColumnRenamed(
                        old_col_name, new_col_name
                    )

            # Display the DataFrame after renaming columns
            published_posts_export_df.show(2)

            columns_to_cast_1 = [
                "Post_Engagement",
                "Post_Engagement_-_Advanced",
                "Post_Engagement_Rate",
                "Post_Engagement_Rate_-_Advanced",
                "Facebook_-_Post_Unique_Engagement_Rate",
                "Facebook_-_Post_Clicks_-_Button_Click",
                "Facebook_-_Post_Clicks_-_Link_Click",
                "Facebook_-_Post_Clicks_-_Other_Click",
                "Facebook_-_Post_Clicks_-_Photo_View",
                "Facebook_-_Post_Clicks_-_Video_Play",
                "Facebook_-_Post_Comments",
                "Facebook_-_Post_Engaged_Fans",
                "Facebook_-_Post_Engaged_Users",
                "Facebook_-_Post_Fan_Impressions",
                "Facebook_-_Post_Fan_Impressions_-_Paid",
                "Facebook_-_Post_Fan_Reach",
                "Facebook_-_Post_Fan_Reach_-_Paid",
                "Facebook_-_Post_Impressions",
                "Facebook_-_Post_Impressions_-_Organic",
                "Facebook_-_Post_Impressions_-_Paid",
                "Facebook_-_Post_Impressions_-_Viral",
                "Facebook_-_Post_Negative_Feedback",
                "Facebook_-_Post_Negative_Feedback_-_Hide",
                "Facebook_-_Post_Negative_Feedback_-_Hide_All",
                "Facebook_-_Post_Negative_Feedback_-_Report",
                "Facebook_-_Post_Negative_Feedback_-_Unlike_Page",
                "Facebook_-_Post_Negative_Feedback_Users",
                "Facebook_-_Post_Reach",
                "Facebook_-_Post_Reach_-_Organic",
                "Facebook_-_Post_Reach_-_Paid",
                "Facebook_-_Post_Reach_-_Viral",
                "Facebook_-_Post_Reactions",
                "Facebook_-_Post_Reactions_-_Angry",
                "Facebook_-_Post_Reactions_-_Haha",
                "Facebook_-_Post_Reactions_-_Like",
                "Facebook_-_Post_Reactions_-_Love",
                "Facebook_-_Post_Reactions_-_Sad",
                "Facebook_-_Post_Reactions_-_Wow",
                "Facebook_-_Post_Shares",
                "Facebook_-_Post_Video_Average_Watch_Time",
                "Facebook_-_Post_Video_Length",
                "Facebook_-_Post_Video_Views_3s",
                "Facebook_-_Post_Video_Views_3s_-_Autoplayed",
                "Facebook_-_Post_Video_Views_3s_-_Clicked_To_Play",
                "Facebook_-_Post_Video_Views_3s_-_Organic",
                "Facebook_-_Post_Video_Views_3s_-_Paid",
                "Facebook_-_Post_Video_Views_30s_-_Autoplayed",
                "Facebook_-_Post_Video_Views_30s_-_Clicked_To_Play",
                "Facebook_-_Post_Video_Views_30s_-_Organic",
                "Facebook_-_Post_Video_Views_30s_-_Paid",
                "Facebook_-_Post_Video_Views_Complete_-_Organic",
                "Facebook_-_Post_Video_Views_Complete_-_Paid",
                "Facebook_-_Post_Video_Viewers_3s",
                "Facebook_-_Post_Video_Viewers_3s_-_Organic",
                "Facebook_-_Post_Video_Viewers_3s_-_Paid",
                "Facebook_-_Post_Video_Viewers_Complete_-_Organic",
                "Facebook_-_Post_Video_Viewers_Complete_-_Paid",
                "Instagram_-_Post_Comments",
                "Instagram_-_Post_Impressions",
                "Instagram_-_Post_Likes",
                "Instagram_-_Post_Reach",
                "Instagram_-_Post_Saves",
                "Instagram_-_Post_Video_Views",
                "Instagram_-_Post_Shares_(Reels)",
                "Instagram_-_Post_Video_Plays_(Reels)",
                "Instagram_-_Story_Exits",
                "Instagram_-_Story_Impressions",
                "Instagram_-_Story_Reach",
                "Instagram_-_Story_Replies",
                "Instagram_-_Story_Taps_Back",
                "Instagram_-_Story_Taps_Forward",
                "Linkedin_-_Post_Comments",
                "Linkedin_-_Post_Impressions",
                "Linkedin_-_Post_Likes",
                "Linkedin_-_Post_Clicks",
                "Linkedin_-_Post_Shares",
                "Linkedin_-_Post_Video_Views_3s",
                "Linkedin_-_Post_Video_Viewers",
                "Linkedin_-_Post_Video_Time_Watched",
                "Linkedin_-_Post_Video_Time_Watched_3s",
                "Pinterest_-_Post_Comments",
                "Pinterest_-_Post_Likes",
                "Pinterest_-_Post_Saves",
                "Twitter_-_Post_Likes",
                "Twitter_-_Post_Native_Retweet_Audience",
                "Twitter_-_Post_Native_Retweets",
                "Twitter_-_Post_Replies",
                "Twitter_-_Post_Clicks_-_App_Installs_Clicks_-_Advanced",
                "Twitter_-_Post_Clicks_-_App_Opens_Clicks_-_Advanced",
                "Twitter_-_Post_Clicks_-_Detail_Expands_-_Advanced",
                "Twitter_-_Post_Clicks_-_Emails_Clicks_-_Advanced",
                "Twitter_-_Post_Clicks_-_Follows_Clicks_-_Advanced",
                "Twitter_-_Post_Clicks_-_Hashtag_Clicks_-_Advanced",
                "Twitter_-_Post_Clicks_-_Media_Clicks_-_Advanced",
                "Twitter_-_Post_Clicks_-_Permalink_Clicks_-_Advanced",
                "Twitter_-_Post_Clicks_-_Profile_Clicks_-_Advanced",
                "Twitter_-_Post_Clicks_-_URL_Clicks_-_Advanced",
                "Twitter_-_Post_Impressions_-_Advanced",
                "Twitter_-_Post_Likes_-_Advanced",
                "Twitter_-_Post_Reach_-_Advanced",
                "Twitter_-_Post_Replies_-_Advanced",
                "Twitter_-_Post_Retweets_-_Advanced",
                "Twitter_-_Post_Retweets_-_Quoted_-_Advanced",
                "Twitter_-_Post_Retweets_-_Unquoted_-_Advanced",
                "Twitter_-_Post_Unlikes_-_Advanced",
                "Twitter_-_Post_Unreplies_-_Advanced",
                "Twitter_-_Post_Unretweets_-_Advanced",
                "Twitter_-_Post_Video_Starts_-_Advanced",
                "Twitter_-_Post_Video_Views_-_Advanced",
                "Twitter_-_Post_Video_Views_-_25_Percent_-_Advanced",
                "Twitter_-_Post_Video_Views_-_50_Percent_-_Advanced",
                "Twitter_-_Post_Video_Views_-_75_Percent_-_Advanced",
                "Twitter_-_Post_Video_Views_-_95_Percent_-_Advanced",
                "Twitter_-_Post_Video_Views_-_Complete_-_Advanced",
                "Vk_-_Post_Comments",
                "Vk_-_Post_Likes",
                "Vk_-_Post_Reposts",
                "Weibo_-_Post_Comments",
                "Weibo_-_Post_Reposts",
                "Youtube_-_Post_Comments",
                "Youtube_-_Post_Dislikes",
                "Youtube_-_Post_Likes",
                "Youtube_-_Post_Video_Views",
                "Tiktok_-_Post_Video_Views",
                "Tiktok_-_Video_Length",
                "Tiktok_-_Post_Likes",
                "Tiktok_-_Post_Comments",
                "Tiktok_-_Video_Shares",
                "Tiktok_-_Post_Reach",
                "Tiktok_-_Post_Video_Views_-_Complete",
                "Tiktok_-_Video_Total_Play_Time",
                "Tiktok_-_Video_Average_Watch_Time",
                "Post_Link_Shortener_Clicks",
                "Web_Analytics_Bounces_from_Social",
                "Web_Analytics_Conversion_Value_from_Social",
                "Web_Analytics_Conversions_from_Social",
                "Web_Analytics_New_Visitors_from_Social",
                "Web_Analytics_Page_Views_from_Social",
                "Web_Analytics_Visits_from_Social"
            ]

            # Iterate through the columns and cast them to DecimalType
            for column_name in columns_to_cast_1:
                published_posts_export_df = published_posts_export_df.withColumn(
                    column_name, col(column_name).cast(DecimalType())
                )
                # published_posts_export_df.printSchema()
            # print("After converting:")
            columns_to_datetime1 = ["Published_Date"]
            for column_name in columns_to_datetime1:
                published_posts_export_df = published_posts_export_df.withColumn(
                    column_name, col(column_name).cast(TimestampType())
                )

            published_posts_export_df.printSchema()
            df = published_posts_export_df
            # df.show()
        elif "ads_net_values_export" in str(i):
            # print(i)
            # Read the specific file
            ads_net_values_export_df = spark.read.csv(i, sep="\t", header=True)
            print("printing the schema ads_net_values_export_df-------->")
            ads_net_values_export_df.printSchema()
            # print("Before converting:")
            # ads_net_values_export_df.printSchema()
            # Assuming you have a list of column names that you want to convert to decimal, let's call it
            # `decimal_columns`
            # List of columns to convert to DecimalType
            original_columns1 = [
                "Channel",
                "Ad Account",
                "Ad Account Currency",
                "Ad Name",
                "Ad ID",
                "Delivery Start Date",
                "Ad Set Start Date",
                "Ad Set End Date",
                "Status",
                "Ad Created Date",
                "Time Elapsed %",
                "Ad Set",
                "Ad Set ID",
                "Ad Campaign",
                "Ad Campaign ID",
                "Objective",
                "Ad Title",
                "Ad Text",
                "Social Account",
                "Image Link",
                "Link",
                "Labels",
                "Optimization Goal",
                "Buying Type",
                "Budget",
                "Budget Type",
                "Plan",
                "Platform",
                "Position",
                "Device",
                "Ad Clicks (All)",
                "Ad Comments",
                "Ad Engagement",
                "Ad Engagement Rate",
                "Ad Impressions",
                "Ad Link Clicks",
                "Ad Media Engagements",
                "Ad Reactions",
                "Ad Saves",
                "Ad Shares",
                "Ad Video Plays",
                "Ad Video Views - 10s",
                "Ad Video Views - 10s - Cost",
                "Ad Video Views - 3s",
                "Ad Video Views - 3s - Cost",
                "Ad Video Watches at 100%",
                "Ad Video Watches at 25%",
                "Ad Video Watches at 50%",
                "Ad Video Watches at 75%",
                "Ad Video Watches at 95%",
                "Add of Payment Info - Cost",
                "Add to Cart - Cost",
                "Add to Wishlist - Cost",
                "Adds of Payment Info",
                "Adds of Payment Info - Value",
                "Adds to Cart",
                "Adds to Cart - Value",
                "Adds to Wishlist",
                "Adds to Wishlist - Value",
                "App Install - Cost",
                "App Installs",
                "App Installs - Value",
                "Application Submitted - Cost",
                "Applications Submited",
                "Applications Submitted - Value",
                "CPC (All)",
                "CPC (Cost Per Link Click)",
                "CPM (Cost per 1,000 Impressions)",
                "CTR (All)",
                "CTR (Link Click-Through Rate)",
                "Checkout Initiated - Cost",
                "Checkouts Initiated",
                "Checkouts Initiated - Value",
                "Content View - Cost",
                "Content Views",
                "Content Views - Value",
                "Custom Conversions",
                "Custom Conversions - Cost",
                "Landing Page Views",
                "Landing Page Views - Value",
                "Lead (Form) - Cost",
                "Lead - Cost",
                "Leads",
                "Leads (Form)",
                "Leads (Form) - Value",
                "Leads - Value",
                "Page Engagement Rate from Ads",
                "Page Engagement from Ads",
                "Page Likes",
                "Page Photo Views",
                "Purchase - Cost",
                "Purchase ROAS (Return on Ad Spend)",
                "Purchases",
                "Purchases - Value",
                "Registration Completed - Cost",
                "Registrations Completed",
                "Registrations Completed - Value",
                "Search - Cost",
                "Searches",
                "Searches - Value",
                "Spend",
                "Subscription - Cost",
                "Subscriptions",
                "Subscriptions - Value",
                "Total Conversion - Cost",
                "Total Conversion Value",
                "Total Conversions",
            ]

            # Rename all columns by adding underscores
            for old_col_name in ads_net_values_export_df.columns:
                if old_col_name in original_columns1:
                    new_col_name = old_col_name.replace(" ", "_")
                    ads_net_values_export_df = ads_net_values_export_df.withColumnRenamed(
                        old_col_name, new_col_name
                    )

            # Display the DataFrame after renaming column
            ads_net_values_export_df.printSchema()

            columns_to_decimal = [
                "Ad_ID",
                "Time_Elapsed_%",
                "Ad_Clicks_(All)",
                "Ad_Comments",
                "Ad_Engagement",
                "Ad_Engagement_Rate",
                "Ad_Impressions",
                "Ad_Link_Clicks",
                "Ad_Media_Engagements",
                "Ad_Reactions",
                "Ad_Saves",
                "Ad_Shares",
                "Ad_Video_Plays",
                "Ad_Video_Views_-_10s",
                "Ad_Video_Views_-_10s_-_Cost",
                "Ad_Video_Views_-_3s",
                "Ad_Video_Views_-_3s_-_Cost",
                "Ad_Video_Watches_at_100%",
                "Ad_Video_Watches_at_25%",
                "Ad_Video_Watches_at_50%",
                "Ad_Video_Watches_at_75%",
                "Ad_Video_Watches_at_95%",
                "Add_of_Payment_Info_-_Cost",
                "Add_to_Cart_-_Cost",
                "Add_to_Wishlist_-_Cost",
                "Adds_of_Payment_Info",
                "Adds_of_Payment_Info_-_Value",
                "Adds_to_Cart",
                "Adds_to_Cart_-_Value",
                "Adds_to_Wishlist",
                "Adds_to_Wishlist_-_Value",
                "App_Install_-_Cost",
                "App_Installs",
                "App_Installs_-_Value",
                "Application_Submitted_-_Cost",
                "Applications_Submited",
                "Applications_Submitted_-_Value",
                "CPC_(All)",
                "CPC_(Cost_Per_Link_Click)",
                "CPM_(Cost_per_1,000_Impressions)",
                "CTR_(All)",
                "CTR_(Link_Click-Through_Rate)",
                "Checkout_Initiated_-_Cost",
                "Checkouts_Initiated",
                "Checkouts_Initiated_-_Value",
                "Content_View_-_Cost",
                "Content_Views",
                "Content_Views_-_Value",
                "Custom_Conversions",
                "Custom_Conversions_-_Cost",
                "Custom Conversions - Value",
                "Downloads",
                "Downloads - Cost",
                "Downloads - Value",
                "Event Responses",
                "Landing Page View - Cost",
                "Landing_Page_Views",
                "Landing_Page_Views_-_Value",
                "Lead_(Form)_-_Cost",
                "Lead_-_Cost",
                "Leads",
                "Leads_(Form)",
                "Leads_(Form)_-_Value",
                "Leads_-_Value",
                "Page_Engagement_Rate_from_Ads",
                "Page_Engagement_from_Ads",
                "Page_Likes",
                "Page_Photo_Views",
                "Purchase_-_Cost",
                "Purchase_ROAS_(Return_on_Ad_Spend)",
                "Purchases",
                "Purchases_-_Value",
                "Registration_Completed_-_Cost",
                "Registrations_Completed",
                "Registrations_Completed_-_Value",
                "Search_-_Cost",
                "Searches",
                "Searches_-_Value",
                "Spend",
                "Subscription_-_Cost",
                "Subscriptions",
                "Subscriptions_-_Value",
                "Total_Conversion_-_Cost",
                "Total_Conversion_Value",
                "Total_Conversions",
            ]

            # Iterate through the columns and cast them to DecimalType
            for column_name in columns_to_decimal:
                ads_net_values_export_df = ads_net_values_export_df.withColumn(
                    column_name, col(column_name).cast(DecimalType())
                )

            columns_to_datetime2 = [
                "Delivery_Start_Date",
                "Ad_Set_End_Date",
                "Ad_Set_Start_Date",
                "Ad_Created_Date",
            ]
            for column_name in columns_to_datetime2:
                ads_net_values_export_df = ads_net_values_export_df.withColumn(
                    column_name, col(column_name).cast(TimestampType())
                )

            ads_net_values_export_df.printSchema()
            df = ads_net_values_export_df

            df.show(2, False)
        else:
            print("end of if condition---->")
            df = spark.read.csv(i, sep="\t", header=True)
            print("it is in else:")
            # df.show(2,False)
        df = df.select(*[F.col(f.name).alias(camel_to_snake(f.name)) for f in df.schema.fields])
        print("final schema:", i, df.printSchema())
        df.show(2, False)
        # df.repartition(4).write.mode("append").parquet(args.destination + "/" + str(filename))
        # print("final schema:", i)
        # df.printSchema()
        df.write.mode("append").save(args.destination + "/" + str(filename))
        print(f"Successfully written khoros data {filename} to {args.destination}")
except NameError:
    print("Error: paths_full variable does not exist.")

job.commit()
