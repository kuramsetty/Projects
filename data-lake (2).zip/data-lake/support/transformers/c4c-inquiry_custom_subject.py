"""Transformers for inquiry_custom_subject to retrieve list of emoji's present in description."""

import argparse

import boto3
import emoji
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from pyspark.sql.functions import col, from_unixtime, regexp_extract, when
from utils import get_all_s3_objects, parse_s3_uri

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")
s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--metadata-path", dest="metadata_path", help="S3 path to the metadata XML from C4C"
)
parser.add_argument(
    "--collection-name", dest="collection_name", help="Name of the collection (used for metadata)"
)
parser.add_argument(
    "--discard-history-id", dest="discard_id", help="Discard all history based on ID"
)
parser.add_argument(
    "--discard-history-column",
    dest="discard_col",
    help="Discard all history except the max in the given column",
)
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

# Read JSON from S3
bucket_full, prefix_full = parse_s3_uri(f"{args.source}/full")
objects_full = get_all_s3_objects(s3=s3, Bucket=bucket_full, Prefix=prefix_full)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]
print("paths_full-->", paths_full)

glue_full_df = glueContext.create_dynamic_frame.from_options(
    format_options={"jsonPath": "", "multiline": True},
    connection_type="s3",
    format="json",
    connection_options={"paths": paths_full},
)
full_df = glue_full_df.toDF()
full_df = full_df.withColumn("x_etl_type", F.lit("full"))
print("count-->", full_df.count())
bucket_delta, key = parse_s3_uri(f"{args.source}/delta")

objects_delta = get_all_s3_objects(s3=s3, Bucket=bucket_delta, Prefix=key)

if objects_delta:
    paths_delta = [f"s3://{bucket_delta}/{o['Key']}" for o in objects_delta]
    glue_delta_df = glueContext.create_dynamic_frame.from_options(
        format_options={"jsonPath": "", "multiline": True},
        connection_type="s3",
        format="json",
        connection_options={"paths": paths_delta},
    )
    delta_df = glue_delta_df.toDF()
    print("delta", delta_df.count())
    df = delta_df
    # delta_df = delta_df.withColumn("x_etl_type", F.lit("delta"))

    # df = full_df.union(delta_df.select(full_df.columns))
    print("Union delta and full")
else:
    df = full_df
    print("full only")
# print("Before count ",df.count())
n_partitions = int(df.rdd.getNumPartitions() / 10)
# df = df.dropDuplicates()
# print("After count ",df.count())
# Repartition into smaller partitions for performance

df = df.drop("__metadata")
df = df.withColumn(
    "timestamp", regexp_extract(df["creationdatetime"], r"/Date\((\d+)\)/", 1).cast("long")
)
df = df.withColumn("creationdatetime", from_unixtime(col("timestamp") / 1000).cast("timestamp"))
df = df.drop("timestamp")
df = df.withColumn(
    "timestamp", regexp_extract(df["lastchangedatetime"], r"/Date\((\d+)\)/", 1).cast("long")
)
df = df.withColumn("lastchangedatetime", from_unixtime(col("timestamp") / 1000).cast("timestamp"))
df = df.drop("timestamp")


# Define a function to check if any element in the array is an emoji description
def has_emoji(text_descriptions):
    """Method to check if the description text has emoji inside or not and returns count."""
    count = 0
    # print(text_descriptions)
    for desc in text_descriptions:
        if desc in emoji.EMOJI_DATA and desc != "®":
            count += 1
    return count


# Create a user-defined function (UDF)
has_emoji_udf = F.udf(has_emoji)

# Add a new column using the UDF
df = df.withColumn("has_emoji", when(has_emoji_udf(F.col("Name")) > 0, "True").otherwise("False"))

# print(df.show(3))
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)

print("Writing to processed path ", args.destination)

df.write.mode("overwrite").save(args.destination)
print("Written to processed path successfully")

job.commit()
