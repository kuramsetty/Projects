"""Transformers for ChangeDocumentLeads."""

import argparse

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql.functions import col, from_unixtime, lit, regexp_extract
from utils import get_all_s3_objects, parse_s3_uri

dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("data_lake_delta")
s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--metadata-path", dest="metadata_path", help="S3 path to the metadata XML from C4C"
)
parser.add_argument(
    "--collection-name", dest="collection_name", help="Name of the collection (used for metadata)"
)
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

# Read JSON from S3
bucket_full, prefix_full = parse_s3_uri(f"{args.source}/full")
objects_full = get_all_s3_objects(s3=s3, Bucket=bucket_full, Prefix=prefix_full)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]

glue_full_df = glueContext.create_dynamic_frame.from_options(
    format_options={"jsonPath": "", "multiline": True},
    connection_type="s3",
    format="json",
    connection_options={"paths": paths_full},
)
full_df = glue_full_df.toDF()
full_df = full_df.withColumn("x_etl_type", lit("full"))
print("Full df done")

bucket_delta, key = parse_s3_uri(f"{args.source}/delta")
print("bucket_delta and key ", bucket_delta, key)
objects_delta = get_all_s3_objects(s3=s3, Bucket=bucket_delta, Prefix=key)

if objects_delta:
    print("creating delta df")
    paths_delta = [f"s3://{bucket_delta}/{o['Key']}" for o in objects_delta]
    glue_delta_df = glueContext.create_dynamic_frame.from_options(
        format_options={"jsonPath": "", "multiline": True},
        connection_type="s3",
        format="json",
        connection_options={"paths": paths_delta},
    )
    delta_df = glue_delta_df.toDF()
    # print(delta_df.show(2,False))
    print("schema-->", delta_df.printSchema())
    delta_df = delta_df.withColumn("x_etl_type", lit("delta"))
    print("created delta df")
    print("count-->", delta_df.count())
    # df = full_df.union(delta_df.select(full_df.columns))
    df = delta_df
else:
    df = full_df

df = df.drop("__metadata")
df = df.withColumn(
    "timestamp", regexp_extract(df["ChangeDateTime"], r"/Date\((\d+)\)/", 1).cast("long")
)
df = df.withColumn("ChangeDateTime", from_unixtime(col("timestamp") / 1000).cast("timestamp"))
df = df.drop("timestamp")
n_partitions = int(df.rdd.getNumPartitions() / 10)
print("schema-->", df.printSchema())
df = df.dropDuplicates()
print("Droping duplicates count", df.count())
# Get data types from C4C
# count_before = df.count()
# meta = get_c4c_metadata(args.metadata_path, args.collection_name)
# df = transform_c4c_df(df, meta)
# count_after = df.count()

# if count_before != count_after:
#      raise ValueError(f"Mismatch in number of records; before: {count_before}, after: {count_after}")

# Repartition into smaller partitions for pderformance
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)

print("writing df")
df.write.mode("overwrite").save(args.destination)
print(f"written df to {args.destination} successfully")

job.commit()
