"""Transformers for glue Job runs."""

import argparse

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from utils import camel_to_snake, parse_s3_uri

s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

glueContext = GlueContext(SparkContext.getOrCreate())
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)


bucket_full, prefix_full = parse_s3_uri(args.source)
objects_full = s3.list_objects_v2(Bucket=bucket_full, Prefix=prefix_full).get("Contents", None)
paths_full = [f"s3://{bucket_full}/{o['Key']}" for o in objects_full]


df = spark.read.csv(paths_full[0], sep=",", header=True)
df = df.select(*[F.col(f.name).alias(camel_to_snake(f.name)) for f in df.schema.fields])

n_partitions = int(df.rdd.getNumPartitions() / 4)
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)
df.write.mode("overwrite").save(args.destination)

job.commit()
