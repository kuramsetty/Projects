#!/usr/bin/env python
"""Transform for the full load."""
import argparse

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from c4c import get_c4c_metadata, transform_c4c_df
from pyspark.context import SparkContext
from utils import get_all_s3_objects, parse_s3_uri

s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument(
    "--metadata-path", dest="metadata_path", help="S3 path to the metadata XML from C4C"
)
parser.add_argument(
    "--collection-name", dest="collection_name", help="Name of the collection (used for metadata)"
)
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

bucket, prefix = parse_s3_uri(args.source)
objects = get_all_s3_objects(s3=s3, Bucket=bucket, Prefix=prefix)
paths = [f"s3://{bucket}/{o['Key']}" for o in objects]


# Read JSON from S3
glue_df = glueContext.create_dynamic_frame.from_options(
    format_options={"jsonPath": "", "multiline": True},
    connection_type="s3",
    format="json",
    connection_options={"paths": paths},
)

# Convert to Spark DataFrame
df = glue_df.toDF()
n_partitions = int(df.rdd.getNumPartitions() / 10)
df = df.dropDuplicates()

# Get data types from C4C
meta = get_c4c_metadata(args.metadata_path, args.collection_name)
df = transform_c4c_df(df, meta)

# Repartition into smaller partitions for performance
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)

df.write.mode("overwrite").save(args.destination)

job.commit()
