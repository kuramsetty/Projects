#!/usr/bin/env python
"""Transformers for Kapost Users."""
import argparse

import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.context import SparkContext
from pyspark.sql import functions as F
from utils import camel_to_snake, remove_null_columns

s3 = boto3.client("s3")

parser = argparse.ArgumentParser(description="Transform data from JSON to Parquet")
parser.add_argument("--source", dest="source", help="Source path in S3")
parser.add_argument("--destination", dest="destination", help="Destination path in S3")
parser.add_argument("--JOB_NAME", dest="name", help="Job name (passed by Glue)")
args = parser.parse_known_args()[0]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args.name)

df = spark.read.json(args.source)
df = remove_null_columns(df)
df = df.select(*[F.col(f.name).alias(camel_to_snake(f.name)) for f in df.schema.fields])

df = df.withColumn("created_at", F.to_timestamp("created_at"))
df = df.withColumn("updated_at", F.to_timestamp("updated_at"))

n_partitions = int(df.rdd.getNumPartitions() / 4)

# Repartition into smaller partitions for performance
if n_partitions <= 1:
    n_partitions = 1
df = df.coalesce(n_partitions)

df.write.mode("overwrite").save(args.destination)

job.commit()
