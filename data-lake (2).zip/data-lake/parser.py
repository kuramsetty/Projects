"""Parser."""

import os
import sys
from glob import glob

import yaml


def parse_jobs_filenames(dirname):
    """Parse job's filenames."""
    all_files = []
    for filename in glob(os.path.join(dirname, "*.yml")):
        all_files.append(filename)
    return all_files


def parse_jobs(filename, **kwargs):
    """Parse jobs."""
    all_jobs = []
    # for filename in glob(os.path.join(dirname, "*.yml")):
    jobs = parse_job(filename, **kwargs)
    if jobs:
        all_jobs.extend(jobs)

    return all_jobs


def parse_job(filename, additional_vars=None, verbose=True):
    """Parse job."""
    print(f"Reading job specifications from {filename}")
    with open(filename, "r") as fp:
        job_spec_yaml = fp.read()

    job_spec = yaml.safe_load(job_spec_yaml)

    vars = job_spec.get("vars", {})
    if additional_vars is not None:
        vars.update(additional_vars)

    try:
        job_spec = yaml.safe_load(job_spec_yaml.format(**vars))
    except KeyError as e:
        print(f"Variable {e} not found in {filename}. Please add it to the 'vars' section.")
        sys.exit(1)

    jobs = job_spec["jobs"]

    extractor_outputs = {}
    transformer_outputs = {}

    for job in jobs:
        if "extractor_output" in job:
            if job["extractor_output"] in extractor_outputs:
                raise ValueError(
                    f"The extractor {job['name']} is trying to write to {job['extractor_output']}, "
                    f"but the extractor {extractor_outputs[job['extractor_output']]} is already doing that."
                )
            extractor_outputs[job["extractor_output"]] = job["name"]

        if "transformer_output" in job:
            if job["transformer_output"] in transformer_outputs:
                raise ValueError(
                    f"The transformer {job['name']} is trying to write to {job['transformer_output']}, "
                    f"but the transformer {transformer_outputs[job['transformer_output']]} is \
                        already doing that."
                )
            transformer_outputs[job["transformer_output"]] = job["name"]

    if verbose:
        print("\nParsed the following job specifications:")
        for i, job in enumerate(jobs):
            print(f"\nJob {i}:")
            for key, value in job.items():
                print(f"\t{key}: {value}")

    print("\n")

    return jobs
