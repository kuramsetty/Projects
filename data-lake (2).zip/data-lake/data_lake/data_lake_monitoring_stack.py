import os

from aws_cdk import Stack as Stack
from aws_cdk import aws_events as events
from aws_cdk import aws_events_targets as targets
from aws_cdk import aws_iam as iam
from aws_cdk import aws_lambda as lambda_
from aws_cdk import aws_sns as sns
from constructs import Construct


class DataLakeMonitoringStack(Stack):
    def __init__(self, scope: Construct, id: str, environment: str, **kwargs) -> None:
        super().__init__(scope=scope, id=id, description="Monitors ETL Pipelines", **kwargs)

        deploy_account = self.node.try_get_context(environment)["deploy_account"]
        region = self.node.try_get_context("region")

        role = iam.Role(
            scope=self,
            id="data-lake-monitoring-role",
            role_name="data-lake-monitoring-role",
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            description="Lambda Role for Data Lake Monitoring",
        )

        role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name(
                "service-role/AWSLambdaBasicExecutionRole"
            )
        )

        role.add_to_policy(
            iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=["sns:Publish"],
                resources=[f"arn:aws:sns:{region}:{deploy_account}:data-lake-etl",
                           "arn:aws:sns:eu-central-1:011840291019:servicenow-sns-dev",
                           "arn:aws:sns:eu-central-1:011840291019:servicenow-sns-prod"
                ],
            )
        )

        lambda_dir = os.path.abspath(os.path.join("lambda_functions", "monitoring"))

        topic = sns.Topic(
            scope=self,
            id="data-lake-sns-topic",
            display_name="Glue Pipeline Monitoring",
            topic_name="data-lake-etl",
        )

        fn = lambda_.Function(
            scope=self,
            runtime=lambda_.Runtime.PYTHON_3_8,
            id="data-lake-monitoring",
            description="Shoots notifications for failed Glue jobs to SNS and creates ServiceNow-Incident",
            function_name="data-lake-monitoring",
            handler="lambda_function.lambda_handler",
            role=role,
            code=lambda_.Code.from_asset(lambda_dir),
        )

        rule = events.Rule(
            scope=self,
            description="Drops an alert when Glue jobs fail",
            rule_name="data-lake-etl-rule",
            id="data-lake-etl-rule",
            event_pattern=events.EventPattern(
                source=["aws.glue"], detail_type=["Glue Job State Change"]
            ),
            targets=[targets.LambdaFunction(fn)],
        )
