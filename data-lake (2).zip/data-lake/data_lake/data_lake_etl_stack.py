"""Data lake etl stack."""

import random
from parser import parse_jobs

from aws_cdk import Stack
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_glue as glue
from aws_cdk import aws_iam as iam
from aws_cdk import aws_s3 as s3
from aws_cdk import aws_s3_assets as assets
from constructs import Construct

from const import TAGS
from data_lake.data_lake_bucket_stack import DataLakeBucketStack


class DataLakeETLStack(Stack):  # noqa: D101,PLR0913,PLR0912,PLR0915
    def __init__(  # noqa: D107
        self,
        scope: Construct,
        id: str,
        environment: str,
        bucket_stack: DataLakeBucketStack,
        filename: str,
        **kwargs,
    ) -> None:
        super().__init__(
            scope=scope,
            id=id,
            description="Provisions Glue pipelines via CodePipeline and Git",
            **kwargs,
        )

        bucket_name = self.node.try_get_context(environment)["bucket"]
        deploy_account = self.node.try_get_context(environment)["deploy_account"]
        region = self.node.try_get_context("region")
        # sap_c4c_odata = self.node.try_get_context(environment)["sap-c4c-odata"]  # noqa: F841
        # data_lake_adobe_marketo = self.node.try_get_context(environment)[
        #    "data-lake-adobe-marketo"]  # noqa: F841
        # kapost_api_key = self.node.try_get_context(environment)["kapost-api-key"]  # noqa: F841
        # vpc_id = self.node.try_get_context(environment)["vpc_id"]  # noqa: F841
        subnet_id = self.node.try_get_context(environment)["subnet_id"]
        # theobald_url = self.node.try_get_context(environment)["theobald_url"]  # noqa: F841
        # supply_chain_apac_gsp = self.node.try_get_context(environment)[
        #    "supply-chain-apac-gsp"]  # noqa: F841
        glue_role_name = self.node.try_get_context(environment)["glue_role_name"]
        # qualtricsCred = self.node.try_get_context(environment)["QualtricsCred"]  # noqa: F841
        # b73_odata = self.node.try_get_context(environment)["b73-odata"]  # noqa: F841

        # vpc = ec2.Vpc.from_lookup(self, "covestro-vpc", vpc_id=vpc_id)
        subnet = ec2.Subnet.from_subnet_attributes(
            scope=self, id="glue-subnet", availability_zone="eu-central-1", subnet_id=subnet_id
        )  # noqa: F841

        glue_bucket = s3.Bucket.from_bucket_attributes(
            self, f"{bucket_name}-glue", bucket_arn=f"arn:aws:s3:::{bucket_name}-glue"
        )

        role = iam.Role.from_role_arn(
            self, "Role", f"arn:aws:iam::{deploy_account}:role/{glue_role_name}", mutable=False
        )

        glue_bucket.grant_read(role)
        bucket_stack.data_lake_bucket.grant_read_write(role)
        bucket_stack.athena_bucket.grant_read_write(role)
        bucket_stack.support_bucket.grant_read(role)

        theobald_glue_bucket = s3.Bucket.from_bucket_attributes(
            self,
            f"{bucket_name}-theobald-glue",
            bucket_arn=f"arn:aws:s3:::{bucket_name}-theobald-glue",
        )
        theobald_glue_bucket.grant_read(role)

        glue_libraries = assets.Asset(
            scope=self, id="data-lake-glue-libraries", path="support/glue/"
        )
        glue_libraries.grant_read(role)

        jobs = parse_jobs(
            filename=filename,
            additional_vars={
                "region": region,
                "bucket": bucket_name,
                "glue_bucket": f"{bucket_name}-glue",
                "account": deploy_account,
            },
        )

        # for db in set([job["database"] for job in jobs if "database" in job]):
        #     glue.CfnDatabase(
        #         scope=self,
        #         id=f"data-lake-{db}-database",
        #         catalog_id=deploy_account,
        #         database_input={
        #         "name": f"{db}"
        #     }
        #     )

        db_set = set([job["database"] for job in jobs if "database" in job])
        ref_db_set = set([job["reference_database"] for job in jobs if "reference_database" in job])
        if len(db_set) == 1:
            database_name = db_set.pop()
            glue.CfnDatabase(
                scope=self,
                id=f"data-lake-{database_name}-database",
                catalog_id=deploy_account,
                database_input={"name": database_name},
            )
        elif len(ref_db_set) == 1:
            database_name = ref_db_set.pop()

        for job in jobs:
            job_type = job.get("type", "etl")

            if "schedule" in job:
                schedule = job["schedule"]
            else:
                # Kickstart Random Number Generator with the job name such that
                # the time is deterministic w.r.t. the job name
                random.seed(str(job))  # noqa: S311
                hour = random.randint(19, 23)
                minute = random.randint(0, 59)
                schedule = f"cron({minute} {hour} * * ? *)"

            if environment != "prod":
                schedule = "cron(0 0 * * ? 2199)"

            if "transformer_schedule" in job:
                transformer_schedule = job["transformer_schedule"]

                if environment != "prod":
                    transformer_schedule = "cron(0 0 * * ? 2199)"
            else:
                transformer_schedule = None

            if job_type == "etl":
                has_transformer = "transformer" in job
                has_crawler = job.get("enable_crawler", True)

                glue_workflow = glue.CfnWorkflow(
                    scope=self,
                    id=f"data-lake-{job['name']}",
                    name=f"data-lake-{job['name']}",
                    description=f"Ingests data and runs crawler for {job['name']}",
                )

                if transformer_schedule:
                    # If there's a separate `transformer_schedule`, we create a second Glue workflow to run the
                    # transformer at a different time.
                    glue_workflow2 = glue.CfnWorkflow(
                        scope=self,
                        id=f"data-lake-{job['name']}-transformer",
                        name=f"data-lake-{job['name']}-transformer",
                        description=f"Transforms data and runs crawler for {job['name']}",
                    )

                # ==== Extract Job ==== #
                # Extractor Arguments
                extractor_default_arguments = {
                    "--source": job.get("source", ""),
                    "--destination": job.get("extractor_output"),
                    "--job-name": job["name"],
                    "--extra-py-files": glue_libraries.s3_object_url,
                    "--TempDir": f"s3://{glue_bucket.bucket_name}/temp/",
                }
                if "extractor_args" in job:
                    for key, value in job["extractor_args"].items():
                        extractor_default_arguments[f"--{key}"] = value

                extract_job = glue.CfnJob(
                    scope=self,
                    id=f"data-lake-extract-{job['name']}",
                    name=f"data-lake-extract-{job['name']}",
                    description="Extracts data from the source system and writes it to S3 in raw format",
                    tags=TAGS,
                    command=glue.CfnJob.JobCommandProperty(
                        name="glueetl", python_version="3", script_location=job["extractor"]
                    ),
                    default_arguments=extractor_default_arguments,
                    glue_version="4.0",
                    worker_type="G.1X",
                    number_of_workers=2,
                    role=role.role_arn,
                )

                extract_job_trigger = glue.CfnTrigger(
                    scope=self,
                    id=f"data-lake-extract-trigger-{job['name']}",
                    name=f"data-lake-extract-{job['name']}",
                    description=f"Triggers extract job for data source {job['name']}",
                    type="SCHEDULED",
                    workflow_name=glue_workflow.ref,
                    schedule=schedule,
                    start_on_creation=True,
                    actions=[glue.CfnTrigger.ActionProperty(job_name=extract_job.ref)],
                )
                extract_job_trigger.add_depends_on(extract_job)
                extract_job_trigger.add_depends_on(glue_workflow)

                # ==== Transformer Job (if any) ==== #
                if has_transformer:
                    if "transformer_input" in job:
                        source = job["transformer_input"]
                    else:
                        source = job["extractor_output"]

                    # Transformer Arguments
                    transformer_default_arguments = {
                        "--source": source,
                        "--destination": job["transformer_output"],
                        "--extra-py-files": glue_libraries.s3_object_url,
                        "--TempDir": f"s3://{glue_bucket.bucket_name}/temp/",
                    }

                    if "transformer_args" in job:
                        for key, value in job["transformer_args"].items():
                            transformer_default_arguments[f"--{key}"] = value

                    transform_job = glue.CfnJob(
                        scope=self,
                        id=f"data-lake-transform-{job['name']}",
                        name=f"data-lake-transform-{job['name']}",
                        description="Transforms raw data from the extractor into e.g. parquet",
                        command=glue.CfnJob.JobCommandProperty(
                            name="glueetl", script_location=job["transformer"]
                        ),
                        default_arguments=transformer_default_arguments,
                        glue_version="4.0",
                        worker_type="G.1X",
                        number_of_workers=2,
                        role=role.role_arn,
                    )

                    transform_job_trigger = None

                    if transformer_schedule:
                        # Separate schedule/workflow for the transformer (user supplied)
                        transform_job_trigger = glue.CfnTrigger(
                            scope=self,
                            id=f"data-lake-transform-trigger-{job['name']}",
                            name=f"data-lake-transform-trigger-{job['name']}",
                            description=f"Triggers transform job for data source {job['name']}",
                            type="SCHEDULED",
                            workflow_name=glue_workflow2.ref,
                            schedule=transformer_schedule,
                            start_on_creation=True,
                            actions=[glue.CfnTrigger.ActionProperty(job_name=transform_job.ref)],
                        )
                        transform_job_trigger.add_depends_on(transform_job)
                        transform_job_trigger.add_depends_on(glue_workflow2)
                    else:
                        transform_job_trigger = glue.CfnTrigger(
                            scope=self,
                            id=f"data-lake-transform-trigger-{job['name']}",
                            name=f"data-lake-transform-trigger-{job['name']}",
                            description=f"Triggers transform job for data source {job['name']}",
                            type="CONDITIONAL",
                            workflow_name=glue_workflow.ref,
                            start_on_creation=True,
                            actions=[
                                glue.CfnTrigger.ActionProperty(
                                    job_name=transform_job.ref,
                                )
                            ],
                            predicate=glue.CfnTrigger.PredicateProperty(
                                conditions=[
                                    glue.CfnTrigger.ConditionProperty(
                                        logical_operator="EQUALS",
                                        job_name=extract_job.ref,
                                        state="SUCCEEDED",
                                    )
                                ]
                            ),
                        )
                        transform_job_trigger.add_depends_on(transform_job)
                        transform_job_trigger.add_depends_on(glue_workflow)

                if has_transformer and has_crawler:
                    glue_crawler = glue.CfnCrawler(
                        scope=self,
                        id=f"data-lake-crawler-{job['name']}",
                        name=f"data-lake-crawler-{job['name']}",
                        database_name=database_name,
                        # database_name=job["database"],
                        role=role.role_arn,
                        schema_change_policy=glue.CfnCrawler.SchemaChangePolicyProperty(
                            update_behavior="UPDATE_IN_DATABASE",
                            delete_behavior="DELETE_FROM_DATABASE",
                        ),
                        targets={"s3Targets": [{"path": job["transformer_output"]}]},
                    )

                    glue_crawler_trigger = glue.CfnTrigger(
                        scope=self,
                        id=f"data-lake-crawler-trigger-{job['name']}",
                        name=f"data-lake-crawler-trigger-{job['name']}",
                        description=f"Triggers crawler for data source {job['name']}",
                        type="CONDITIONAL",
                        workflow_name=(
                            glue_workflow2.ref if transformer_schedule else glue_workflow.ref
                        ),
                        start_on_creation=True,
                        actions=[
                            glue.CfnTrigger.ActionProperty(
                                crawler_name=glue_crawler.ref,
                            )
                        ],
                        predicate=glue.CfnTrigger.PredicateProperty(
                            conditions=[
                                glue.CfnTrigger.ConditionProperty(
                                    logical_operator="EQUALS",
                                    job_name=(
                                        transform_job.ref if has_transformer else extract_job.ref
                                    ),
                                    state="SUCCEEDED",
                                )
                            ]
                        ),
                    )
                    glue_crawler_trigger.add_depends_on(glue_crawler)
                    glue_crawler_trigger.add_depends_on(
                        transform_job if has_transformer else extract_job
                    )
                    glue_crawler_trigger.add_depends_on(
                        glue_workflow2 if transformer_schedule else glue_workflow
                    )

            elif job_type == "crawler":
                glue_crawler = glue.CfnCrawler(
                    scope=self,
                    id=f"data-lake-crawler-theobald-{job['name']}",
                    name=f"data-lake-crawler-theobald-{job['name']}",
                    # database_name=job["database"],
                    database_name=database_name,
                    role=role.role_arn,
                    schema_change_policy=glue.CfnCrawler.SchemaChangePolicyProperty(
                        update_behavior="UPDATE_IN_DATABASE",
                        delete_behavior="DELETE_FROM_DATABASE",
                    ),
                    targets={"s3Targets": [{"path": job["source"]}]},
                )

                crawler_trigger = glue.CfnTrigger(  # noqa: F841
                    scope=self,
                    id=f"data-lake-crawler-trigger-theobald-{job['name']}",
                    name=f"data-lake-crawler-trigger-theobald-{job['name']}",
                    description=f"Triggers the crawler theobald-{job['name']}",
                    type="SCHEDULED",
                    schedule=schedule,
                    start_on_creation=True,
                    actions=[glue.CfnTrigger.ActionProperty(job_name=glue_crawler.ref)],
                )

            else:
                raise ValueError(f"Invalid job type: {job_type}")
