from aws_cdk import Stack as Stack
from aws_cdk import aws_dynamodb as dynamodb
from aws_cdk import aws_ec2 as ec2
from aws_cdk import aws_iam as iam
from constructs import Construct


class DataLakeUtilsStack(Stack):
    def __init__(self, scope: Construct, id: str, environment: str, **kwargs) -> None:
        super().__init__(
            scope=scope, id=id, description="Helping services with the data lake", **kwargs
        )

        deploy_account = self.node.try_get_context(environment)["deploy_account"]
        region = self.node.try_get_context("region")
        sap_c4c_odata = self.node.try_get_context(environment)["sap-c4c-odata"]
        data_lake_adobe_marketo = self.node.try_get_context(environment)["data-lake-adobe-marketo"]
        vpc_id = self.node.try_get_context(environment)["vpc_id"]
        kapost_api_key = self.node.try_get_context(environment)["kapost-api-key"]
        subnet_id = self.node.try_get_context(environment)["subnet_id"]
        supply_chain_apac_gsp = self.node.try_get_context(environment)["supply-chain-apac-gsp"]
        glue_role_name = self.node.try_get_context(environment)["glue_role_name"]
        qualtricsCred = self.node.try_get_context(environment)["QualtricsCred"]
        b73_odata = self.node.try_get_context(environment)["b73-odata"]

        role = iam.Role(
            scope=self,
            id="data-lake-glue-role",
            role_name=glue_role_name,
            assumed_by=iam.ServicePrincipal("glue.amazonaws.com"),
            description="Glue Role for Data Lake",
        )

        role.add_to_policy(
            iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=["dynamodb:PutItem", "dynamodb:GetItem"],
                resources=[
                    f"arn:aws:dynamodb:{region}:{deploy_account}:table/data_lake_delta",
                ],
            )
        )

        role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name("service-role/AWSGlueServiceRole")
        )

        role.add_to_policy(
            iam.PolicyStatement(
                effect=iam.Effect.ALLOW,
                actions=["secretsmanager:GetSecretValue"],
                resources=[
                    f"{sap_c4c_odata}",
                    f"{data_lake_adobe_marketo}",
                    f"{kapost_api_key}",
                    f"{supply_chain_apac_gsp}",
                    f"{qualtricsCred}",
                    f"{b73_odata}",
                ],
            )
        )

        table = dynamodb.Table(
            scope=self,
            id="data-lake-table-delta",
            table_name="data_lake_delta",
            partition_key=dynamodb.Attribute(name="job_name", type=dynamodb.AttributeType.STRING),
        )

        subnet = ec2.Subnet.from_subnet_attributes(
            scope=self, id="glue-subnet", availability_zone="eu-central-1", subnet_id=subnet_id
        )

        sg_cfn = ec2.CfnSecurityGroup(
            scope=self,
            id="etl-glue-security-group",
            vpc_id=vpc_id,
            group_name="etl-glue-security-group",
            group_description="Security group to allow Glue access to the Covestro Network",
            security_group_egress=[],
            security_group_ingress=[],
        )

        ec2.CfnSecurityGroupIngress(
            scope=self,
            id="glue-security-ingress",
            ip_protocol="-1",
            from_port=0,
            to_port=65535,
            source_security_group_id=sg_cfn.ref,
            group_id=sg_cfn.ref,
        )

        sg = ec2.SecurityGroup.from_security_group_id(
            scope=self, id="etl", security_group_id="glue-security-group"
        )

        # connection = glue.CfnConnection(self, "Covestro-Intranet",
        #     catalog_id=deploy_account,
        #     connection_input=glue.CfnConnection.ConnectionInputProperty(
        #         connection_type="NETWORK",
        #         description="Used to connect to the Covestro intranet",
        #         name="Covestro-Intranet",
        #         physical_connection_requirements=glue.CfnConnection.PhysicalConnectionRequirementsProperty(
        #             security_group_id_list=[sg.security_group_id],
        #             subnet_id=str(subnet)
        #         )
        #     )
        # )
