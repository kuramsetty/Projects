"""Data lake bucket stack."""

from aws_cdk import Duration, RemovalPolicy, Stack
from aws_cdk import aws_s3 as s3
from aws_cdk import aws_s3_deployment as s3_deployment
from constructs import Construct


class DataLakeBucketStack(Stack):  # noqa: D101
    def __init__(self, scope: Construct, id: str, environment: str, **kwargs) -> None:  # noqa: D107
        super().__init__(
            scope=scope, id=id, description="Provisions S3 buckets for the data lake", **kwargs
        )

        bucket_name = self.node.try_get_context(environment)["bucket"]

        self.logs_bucket = s3.Bucket(
            self,
            id="data-lake-logs-bucket",
            bucket_name=f"{bucket_name}-logs",
            encryption=s3.BucketEncryption.S3_MANAGED,
            enforce_ssl=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            removal_policy=RemovalPolicy.RETAIN,
            lifecycle_rules=[s3.LifecycleRule(expiration=Duration.days(180))],
        )

        self.athena_bucket = s3.Bucket(
            self,
            id="data-lake-athena-bucket",
            bucket_name=f"{bucket_name}-athena",
            encryption=s3.BucketEncryption.S3_MANAGED,
            enforce_ssl=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            removal_policy=RemovalPolicy.RETAIN,
            lifecycle_rules=[s3.LifecycleRule(expiration=Duration.days(1))],
        )
        #
        # self.sagemaker_bucket = s3.Bucket(
        #     self,
        #     id="data-lake-sagemaker-bucket",
        #     bucket_name=f"sagemaker-{region}-{account}"
        # )

        self.data_lake_bucket = s3.Bucket(
            self,
            id="data-lake-bucket",
            bucket_name=bucket_name,
            encryption=s3.BucketEncryption.S3_MANAGED,
            enforce_ssl=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            removal_policy=RemovalPolicy.RETAIN,
            server_access_logs_bucket=self.logs_bucket,
        )

        self.support_bucket = s3.Bucket(
            scope=self,
            id="data-lake-support-bucket",
            bucket_name=f"{bucket_name}-support",
            encryption=s3.BucketEncryption.S3_MANAGED,
            enforce_ssl=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            removal_policy=RemovalPolicy.RETAIN,
        )

        self.glue_bucket = s3.Bucket(
            scope=self,
            id="data-lake-glue-bucket",
            bucket_name=f"{bucket_name}-glue",
            encryption=s3.BucketEncryption.S3_MANAGED,
            enforce_ssl=True,
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            removal_policy=RemovalPolicy.RETAIN,
        )

        deployment = s3_deployment.BucketDeployment(  # noqa: F841
            scope=self,
            id="bucket-deployment",
            sources=[s3_deployment.Source.asset("support")],
            destination_bucket=self.glue_bucket,
        )

        # role.add_to_policy(
        #     iam.PolicyStatement(
        #         effect=iam.Effect.ALLOW,
        #         actions=[
        #             "kms:GenerateDataKey",
        #         ],
        #         resources=[
        #             athena_bucket.encryption_key.key_arn,
        #             data_lake_bucket.encryption_key.key_arn,
        #             support_bucket.encryption_key.key_arn  test
        #         ]
        #     )
        # )
